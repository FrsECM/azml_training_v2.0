import torch
import numpy as np
from typing import Union
from enum import Enum

class BBOX_TYPE(Enum):
    XYWH_ABS=0
    XYXY_REL=1
    CCWH_REL=2
    XYXY_ABS=3

class BboxHelper:
    def convert(bboxes:Union[torch.Tensor,np.ndarray],src_bbox_type:BBOX_TYPE,dst_bbox_type:BBOX_TYPE,img_height:int=None,img_width:int=None)->Union[torch.Tensor,np.ndarray]:
        """Convert a bbox from one type to another...

        Args:
            src_bbox_type (BBOX_TYPE): source_bbox_type
            dst_bbox_type (BBOX_TYPE): dest_bbox_type
            img_height (int, optional): _description_. Defaults to None.
            img_width (int, optional): _description_. Defaults to None.
        """
        if not isinstance(bboxes,(torch.Tensor,np.ndarray)):
            raise TypeError("bboxes should be a tensor or a numpy array")
        if src_bbox_type==BBOX_TYPE.XYXY_ABS:
            if dst_bbox_type==BBOX_TYPE.CCWH_REL:
                assert img_height is not None and img_width is not None,"Need image size for this conversion..." 
                bbox_xyxy_rel=BboxHelper.bboxes_abs_to_rel(bboxes,img_height,img_width)
                return BboxHelper.bboxes_xyxy_to_ccwh(bbox_xyxy_rel)

        if src_bbox_type==BBOX_TYPE.XYWH_ABS:
            if dst_bbox_type==BBOX_TYPE.CCWH_REL:
                assert img_height is not None and img_width is not None,"Need image size for this conversion..."
                bbox_xywh_rel = BboxHelper.bboxes_abs_to_rel(bboxes,img_height,img_width)
                bbox_xyxy_rel = BboxHelper.bboxes_xywh_to_xyxy(bbox_xywh_rel)
                return BboxHelper.bboxes_xyxy_to_ccwh(bbox_xyxy_rel)

        if src_bbox_type==BBOX_TYPE.XYXY_REL:
            if dst_bbox_type==BBOX_TYPE.CCWH_REL:
                return BboxHelper.bboxes_xyxy_to_ccwh(bboxes)

        if src_bbox_type==BBOX_TYPE.CCWH_REL:
            if dst_bbox_type==BBOX_TYPE.XYXY_ABS:
                assert img_height is not None and img_width is not None,"Need image size for this conversion..."
                bbox_ccwh_rel = BboxHelper.bboxes_rel_to_abs(bboxes,img_height,img_width)
                return BboxHelper.bboxes_ccwh_to_xyxy(bbox_ccwh_rel)

        raise NotImplementedError('This tranformation is not yet implemented...')

    def bboxes_rel_to_abs(bboxes_relative:Union[torch.Tensor,np.ndarray],img_height:int,img_width:int)->Union[torch.Tensor,np.ndarray]:
        """Returns absolute bboxes from relative bboxes

        Args:
            bboxes (Union[torch.Tensor,np.ndarray]): bboxes [...,4]
            img_height (int): height of the image
            img_width (int): width of the image.

        Returns:
            Union[torch.Tensor,np.ndarray]: _description_
        """
        if not isinstance(bboxes_relative,(torch.Tensor,np.ndarray)):
            raise TypeError("bboxes should be a tensor or a numpy array")
        ################ We generate our factor...
        if isinstance(bboxes_relative,torch.Tensor):
            size_factor = torch.Tensor([img_width,img_height]).type_as(bboxes_relative)
        else:
            size_factor = np.array([img_width,img_height])
        if len(bboxes_relative.shape)==1:
            # Case single dimension
            if len(bboxes_relative)!=4:
                raise RuntimeError("bbox last dimension should be 4 (xywc or xyxy)")
            return (bboxes_relative.reshape(-1,2)*size_factor).flatten()
        else:
            if bboxes_relative.shape[-1]!=4:
                raise RuntimeError("bbox last dimension should be 4 (xywc or xyxy)")
            return (bboxes_relative.reshape(-1,2)*size_factor).flatten().reshape(bboxes_relative.shape)

    def bboxes_abs_to_rel(bboxes_absolute:Union[torch.Tensor,np.ndarray],img_height:int,img_width:int)->Union[torch.Tensor,np.ndarray]:
        """Returns absolute bboxes from relative bboxes

        Args:
            bboxes (Union[torch.Tensor,np.ndarray]): bboxes [...,4]
            img_height (int): height of the image
            img_width (int): width of the image.

        Returns:
            Union[torch.Tensor,np.ndarray]: _description_
        """
        if not isinstance(bboxes_absolute,(torch.Tensor,np.ndarray)):
            raise TypeError("bboxes should be a tensor or a numpy array")
        ################ We generate our factor...
        if isinstance(bboxes_absolute,torch.Tensor):
            size_factor = torch.Tensor([1./img_width,1./img_height]).type_as(bboxes_absolute)
        else:
            size_factor = np.array([1./img_width,1./img_height])

        if len(bboxes_absolute.shape)==1:
            # Case single dimension
            if len(bboxes_absolute)!=4:
                raise RuntimeError("bbox last dimension should be 4 (xywc or xyxy)")
            return (bboxes_absolute.reshape(-1,2)*size_factor).flatten().clip(0,1)
        else:
            if bboxes_absolute.shape[-1]!=4:
                raise RuntimeError("bbox last dimension should be 4 (xywc or xyxy)")
            return (bboxes_absolute.reshape(-1,2)*size_factor).flatten().reshape(bboxes_absolute.shape).clip(0,1)

    # XYXY to CCWH => We change the bbox to be referenced by it's center.
    def bboxes_xyxy_to_ccwh(bboxes:Union[torch.Tensor,np.ndarray]):
        """Convert a xyxy bbox to xywh

        Args:
            bboxes (Union[torch.Tensor,np.ndarray]): _description_
        """
        if not isinstance(bboxes,(torch.Tensor,np.ndarray)):
            raise TypeError("bboxes should be a tensor or a numpy array")
        if isinstance(bboxes,torch.Tensor):
            bboxes_result = bboxes.clone()
        else:
            bboxes_result = bboxes.copy()
        ################ We generate our factor...
        if len(bboxes.shape)==1:
            # Case single dimension
            if len(bboxes)!=4:
                raise RuntimeError("bbox last dimension should be 4 (xywc or xyxy)")
            bboxes_result[...,:2]=(bboxes[...,2:]+bboxes[...,:2])/2
            bboxes_result[...,2:]=bboxes[...,2:]-bboxes[...,:2]
            return bboxes_result
        else:
            if bboxes.shape[-1]!=4:
                raise RuntimeError("bbox last dimension should be 4 (xywc or xyxy)")
            bboxes_result[...,:2]=(bboxes[...,2:]+bboxes[...,:2])/2
            bboxes_result[...,2:]=bboxes[...,2:]-bboxes[...,:2]
            return bboxes_result

    def bboxes_ccwh_to_xyxy(bboxes:Union[torch.Tensor,np.ndarray]):
        """Convert a xywh bbox to xyxy

        Args:
            bboxes (Union[torch.Tensor,np.ndarray]): _description_
        """
        if not isinstance(bboxes,(torch.Tensor,np.ndarray)):
            raise TypeError("bboxes should be a tensor or a numpy array")
        if isinstance(bboxes,torch.Tensor):
            bboxes_result = bboxes.clone()
        else:
            bboxes_result = bboxes.copy()
        ################ We generate our factor...
        if len(bboxes.shape)==1:
            # Case single dimension
            if len(bboxes)!=4:
                raise RuntimeError("bbox last dimension should be 4 (xywc or xyxy)")
            bboxes_result[...,2:]=bboxes[...,:2]+bboxes[...,2:]/2
            bboxes_result[...,:2]=bboxes[...,:2]-bboxes[...,2:]/2
            return bboxes_result
        else:
            if bboxes.shape[-1]!=4:
                raise RuntimeError("bbox last dimension should be 4 (xywc or xyxy)")
            bboxes_result[...,2:]=bboxes[...,:2]+bboxes[...,2:]/2
            bboxes_result[...,:2]=bboxes[...,:2]-bboxes[...,2:]/2
            return bboxes_result

    # XYXY to XYWH => We only change 2 last dims.
    def bboxes_xyxy_to_xywh(bboxes:Union[torch.Tensor,np.ndarray]):
        """Convert a xyxy bbox to xywh

        Args:
            bboxes (Union[torch.Tensor,np.ndarray]): _description_
        """
        if not isinstance(bboxes,(torch.Tensor,np.ndarray)):
            raise TypeError("bboxes should be a tensor or a numpy array")
        if isinstance(bboxes,torch.Tensor):
            bboxes_result = bboxes.clone()
        else:
            bboxes_result = bboxes.copy()
        ################ We generate our factor...
        if len(bboxes.shape)==1:
            # Case single dimension
            if len(bboxes)!=4:
                raise RuntimeError("bbox last dimension should be 4 (xywc or xyxy)")
            bboxes_result[...,2:]=bboxes[...,2:]-bboxes[...,:2]
            return bboxes_result
        else:
            if bboxes.shape[-1]!=4:
                raise RuntimeError("bbox last dimension should be 4 (xywc or xyxy)")
            bboxes_result[...,2:]=bboxes[...,2:]-bboxes[...,:2]
            return bboxes_result

    def bboxes_xywh_to_xyxy(bboxes:Union[torch.Tensor,np.ndarray]):
        """Convert a xywh bbox to xyxy

        Args:
            bboxes (Union[torch.Tensor,np.ndarray]): _description_
        """
        if not isinstance(bboxes,(torch.Tensor,np.ndarray)):
            raise TypeError("bboxes should be a tensor or a numpy array")
        if isinstance(bboxes,torch.Tensor):
            bboxes_result = bboxes.clone()
        else:
            bboxes_result = bboxes.copy()
        ################ We generate our factor...
        if len(bboxes.shape)==1:
            # Case single dimension
            if len(bboxes)!=4:
                raise RuntimeError("bbox last dimension should be 4 (xywc or xyxy)")
            bboxes_result[...,2:]=bboxes[...,:2]+bboxes[...,2:]
            return bboxes_result
        else:
            if bboxes.shape[-1]!=4:
                raise RuntimeError("bbox last dimension should be 4 (xywc or xyxy)")
            bboxes_result[...,2:]=bboxes[...,:2]+bboxes[...,2:]
            return bboxes_result
        
    def bboxes_check_yolo(bboxes:Union[torch.Tensor,np.ndarray]):
        """Check if a bbox yolo compatible...
            return False if one value is not in ]0,1]
        Args:
            bboxes (Union[torch.Tensor,np.ndarray]): _description_

        Returns:
            _type_: _description_
        """
        if not bboxes.min()>0:
            return False
        if not bboxes.max()<=1:
            return False
        else:
            return True

    def bboxes_iou(gt_bboxes:torch.Tensor, pred_bboxes:torch.Tensor, xyxy=True):
        """Compute the pairwise IoU between gt_bboxes and the prediction bboxes

        Args:
            gt_bboxes (torch.Tensor): groundTruth for one image [num_gt,4]
            pred_bboxes (torch.Tensor): predictions for one image [num_pred,4]
            xyxy (bool, optional): Defaults to True. The computation is done in xyxy format or in ccwh format.


        Returns:
            iou_s (torch.Tensor): [num_gt,num_pred]
        """
        if gt_bboxes.shape[1] != 4 or pred_bboxes.shape[1] != 4:
            raise IndexError

        if xyxy:
            # In this case, bbox are in XY, XY format...
            # We get :
            # - the top left coordinates of the intersection.
            # - the bottom right coordinate of the intersection.
            tl = torch.max(gt_bboxes[:, None, :2], pred_bboxes[:, :2])
            br = torch.min(gt_bboxes[:, None, 2:], pred_bboxes[:, 2:])
            # We compute area of each bbox individually by supstrating beggining - end.
            area_a = torch.prod(gt_bboxes[:, 2:] - gt_bboxes[:, :2], 1)
            area_b = torch.prod(pred_bboxes[:, 2:] - pred_bboxes[:, :2], 1)
        else:
            # In this case, we are in CC,WH format...
            tl = torch.max(
                (gt_bboxes[:, None, :2] - gt_bboxes[:, None, 2:] / 2), # Top left bbox 1...
                (pred_bboxes[:, :2] - pred_bboxes[:, 2:] / 2), # top left bbox 2
            ) # => We search the top left of the intersection...
            br = torch.min(
                (gt_bboxes[:, None, :2] + gt_bboxes[:, None, 2:] / 2), # bottom right bbox 1
                (pred_bboxes[:, :2] + pred_bboxes[:, 2:] / 2), # bottom right bbox 2
            ) # => We search the botton right of the intersection...
            # The area is WxH then we compute with [2:] coordinates
            area_a = torch.prod(gt_bboxes[:, 2:], 1)
            area_b = torch.prod(pred_bboxes[:, 2:], 1)
        # We compute the area of the intersection.
        en = (tl < br).type(tl.type()).prod(dim=2)
        area_i = torch.prod(br - tl, 2) * en  # * ((tl < br).all())
        return area_i / (area_a[:, None] + area_b - area_i)