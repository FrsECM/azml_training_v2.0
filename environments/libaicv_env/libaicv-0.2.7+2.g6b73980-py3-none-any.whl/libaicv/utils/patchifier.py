from genericpath import isfile
import os
from patchify import patchify
from tqdm import tqdm
from PIL import Image as PILImage
import PIL
import numpy as np
import enum 


EXTENSIONS = ['.TIFF','.TIF','.JPG','.JPEG','.PNG','.BMP']

class IMG_TYPE(enum.Enum):
    IMAGE = 0
    LABEL = 1

class Patchifier:
    """Patchifier Class to patchify your Images

    Call methods in this order :

    1 - set_source_config

    2 - set_dest_config

    3 - set_patch_config

    4 - generate
    """
    # Data Location Properties
    img_src = None
    img_dst = None
    lbl_src = None
    lbl_dst = None
    lbl_suffix = None
    # Data Patchification Properties
    crop_W = None
    crop_H = None
    patch_W = None
    patch_H = None
    step_size = None
    resize = False
    ignore_empty=False

    def __init__(self):
        self._is_src_defined = False
        self._is_dst_defined = False
        self._is_patch_defined = False
    def set_source_config(self,img_src:str,lbl_src:str,lbl_suffix:str="_gt"):
        """Define source directory for your Patchification

        Args:
            img_src (str): Source Directory containing your images
            lbl_src (str): Source Directory containing your labels as images
            lbl_suffix (str): suffix on labels in order to give the same suffix to dst labels.

        Raises:
            OSError: _description_
            OSError: _description_
        """
        if not os.path.exists(img_src) or not os.path.isdir(img_src):
            raise OSError(f'{img_src} should be an existing folder')
        if not os.path.exists(lbl_src) or not os.path.isdir(lbl_src):
            raise OSError(f'{img_src} should be an existing folder')
        self.img_src = img_src
        self.lbl_src = lbl_src
        self.lbl_suffix = lbl_suffix
        self._is_src_defined = True

    def set_dest_config(self,img_dst:str,lbl_dst:str,ignore_empty:bool = False):
        """Define the destination directory for your Patchification

        Args:
            img_dst (str): _description_
            lbl_dst (str): _description_
            ignore_empty(bool): Ignore empty directory (will not override)
        Raises:
            ValueError: _description_
        """
        self.ignore_empty = ignore_empty
        os.makedirs(img_dst,exist_ok=True)
        ######################### Check
        for fname in os.listdir(img_dst):
            fpath = os.path.join(img_dst,fname)
            if os.path.isfile(fpath) and not self.ignore_empty:
                raise ValueError('Image directory should be empty')
        os.makedirs(lbl_dst,exist_ok=True)
        for fname in os.listdir(lbl_dst):
            fpath = os.path.join(lbl_dst,fname)
            if os.path.isfile(fpath) and not self.ignore_empty:
                raise ValueError('Label target directories should be empty')
        self.img_dst = img_dst
        self.lbl_dst = lbl_dst
        self._is_dst_defined = True
    
    def set_patch_config(self,
        crop_W:int,
        crop_H:int,
        step_size:int,
        patch_W:int = None,
        patch_H:int = None):
        """_summary_

        Args:
            crop_W (int): Crop size X axis original Image
            crop_H (int): Crop size Y axis original Image
            step_size (int): step size in X and Y for patching
            patch_W (int, optional): Patch size X axis final Image
            patch_H (int, optional): Patch size Y axis final Image
        """
        self.crop_W = crop_W
        self.crop_H = crop_H
        self.step_size = step_size
        self.patch_W =self.crop_W if patch_W is None else patch_W
        self.patch_H =self.crop_H if patch_H is None else patch_H
        if (crop_W,crop_H) != (patch_W,patch_H):
            self.resize = True
        self._is_patch_defined = True

    def _patch_img(self,src_image_path:str,type:IMG_TYPE=IMG_TYPE.IMAGE):
        """Private method that will patch an image.

        Args:
            src_image_path (str): _description_
            type (IMG_TYPE, optional): _description_. Defaults to IMG_TYPE.IMAGE.
        """
        created = []
        if type == IMG_TYPE.IMAGE:
            dst_root_dir = self.img_dst
            img_name = os.path.basename(src_image_path)
            image_root = os.path.splitext(img_name)[0]
            image_name_end = os.path.splitext(img_name)[1]
        elif type == IMG_TYPE.LABEL:
            dst_root_dir = self.lbl_dst
            # We get the extension...
            img_ext = os.path.splitext(src_image_path)[1]
            img_name = os.path.basename(src_image_path)
            image_without_ext = os.path.splitext(img_name)[0]
            suffix_without_ext = self.lbl_suffix.replace(img_ext,'')
            image_root = image_without_ext.replace(suffix_without_ext,'')
            image_name_end = f"{suffix_without_ext}{img_ext}"
        ######################################################
        with PILImage.open(src_image_path) as pil_img:
            mode = pil_img.mode
            img_array = np.array(pil_img)
        if len(img_array.shape) == 3:
            patch_size=(self.crop_W,self.crop_H,img_array.shape[-1])
        else:
            patch_size=(self.crop_W,self.crop_H)
        patches = patchify(img_array,patch_size=patch_size,step=self.step_size).squeeze()
        for row in range(patches.shape[0]):
            for col in range(patches.shape[1]):
                if type == IMG_TYPE.LABEL:
                    dst_img_path = os.path.join(dst_root_dir,image_root+f"_{row}{col}{image_name_end}")
                    resample = PILImage.Resampling.NEAREST
                elif type == IMG_TYPE.IMAGE:
                    dst_img_path = os.path.join(dst_root_dir,image_root+f"_{row}{col}{image_name_end}")
                    resample = PILImage.Resampling.BICUBIC
                # If the file do not already exist...
                if not os.path.exists(dst_img_path):
                    dst_pil_img=PILImage.fromarray(patches[row,col],mode=mode)
                    if self.resize:
                        # We resize with resampling
                        dst_pil_img = dst_pil_img.resize((self.patch_W,self.patch_H),resample=resample)
                    dst_pil_img.save(dst_img_path)
                    created.append(dst_img_path)
        return created

    def generate(self):
        """Generate new images in the new directory...

        Raises:
            ValueError: When not correctly initialized...
        """
        created = {}
        if not self._is_src_defined:
            raise ValueError('Define source directory with method set_source_config(..) ')
        if not self._is_dst_defined:
            raise ValueError('Define Destination directory with method set_dest_config(..) ')
        if not self._is_patch_defined:
            raise ValueError('Define source directory with method set_patch_config(..) ')
        # Images
        print(f"Generating Patches from images formats {EXTENSIONS} ...")
        created['img']=[]
        for img_name in tqdm(os.listdir(self.img_src)):
            src_image_path = os.path.join(self.img_src,img_name)
            src_image_ext = str(os.path.splitext(src_image_path)[1])
            if os.path.isfile(src_image_path) and src_image_ext.upper() in EXTENSIONS:
                created['img'].extend(self._patch_img(src_image_path,IMG_TYPE.IMAGE))
        # Labels
        created['label']=[]
        for img_name in tqdm(os.listdir(self.lbl_src)):
            src_image_path = os.path.join(self.lbl_src,img_name)
            src_image_ext = str(os.path.splitext(src_image_path)[1])
            if os.path.isfile(src_image_path) and src_image_ext.upper() in EXTENSIONS:
                created['label'].extend(self._patch_img(src_image_path,IMG_TYPE.LABEL))
        return created




