from typing import List,Dict
def stackDict(dict_list:List[Dict])-> dict:
    """ Stack dict items as dict list elements :

    Example :
    [{'foo':'bar1'},{'foo':'bar2'}]
    .....
    =>
    .....
    {'foo':['bar1','bar2']}
    
    Args:
        dict_list (List[Dict]): _description_

    Returns:
        dict: _description_
    """
    assert isinstance(dict_list,list),"dict_list should be a list"
    result={}
    for _dict in dict_list:
        assert isinstance(_dict,dict),"Each element of dict_list should be dictionaries"
        for key in _dict:
            if key in result:
                result[key].append(_dict[key])
            else:
                result[key]=[_dict[key]]
    return result