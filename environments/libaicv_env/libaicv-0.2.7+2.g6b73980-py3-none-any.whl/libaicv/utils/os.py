import os

class Directory:
    def __init__(self,directory_path:str):
        if not os.path.exists(directory_path):
            raise OSError(f"Directory {directory_path} should exist")
        if not os.path.isdir(directory_path):
            raise OSError(f"{directory_path} should be a Directory")
        self._dirpath=directory_path
        self.name = os.path.basename(directory_path)

    def get_filepaths(self):
        file_paths = [
            os.path.join(self._dirpath,f) 
            for f in os.listdir(self._dirpath) 
            if os.path.isfile(os.path.join(self._dirpath,f))]
        return file_paths

    def get_folderpaths(self):
        folder_paths = [
            os.path.join(self._dirpath,f) 
            for f in os.listdir(self._dirpath) 
            if os.path.isdir(os.path.join(self._dirpath,f))]
        return folder_paths
    
    def get_filenames(self):
        return [os.path.basename(f) for f in self.get_filepaths()]

    def get_foldernames(self):
        return [os.path.basename(f) for f in self.get_folderpaths()]

    def get_fileroots(self):
        return [os.path.splitext(os.path.basename(f))[0] for f in self.get_filepaths()]

    def exists(self,item:str):
        return os.path.exists(os.path.join(self._dirpath,item))
    
    def get(self,item:str):
        if not self.exists(item):
            raise OSError(f'File {item} not in this directory')
        return os.path.join(self._dirpath,item)