from abc import ABC, ABCMeta,abstractclassmethod, abstractmethod
from torch.utils.data import Dataset,DataLoader
import torch.distributed as dist
import torch.nn as nn
import torch
import numpy as np
import enum
from typing import Dict,Tuple,List,Union
import matplotlib.pyplot as plt
import copy
import os

@enum.unique
class ACCELERATOR(enum.Enum):
    CPU        = 0
    CUDA       = 1
    CUDA_AMP   = 2

@enum.unique
class REDUCTION(enum.Enum):
    MEAN = 0
    MAX = 1
    MIN = 2

@enum.unique
class SCHEDULER_TYPE(enum.Enum):
    BATCH = 0
    EPOCH = 1

@enum.unique
class PPROCESS(enum.Enum):
    STANDARDIZE = 0
    NORMALIZE   = 1

@enum.unique
class IOU_TYPE(enum.Enum):
    STANDARD = 0
    SQUARED = 1
    GLOBAL = 2
    COMPLETE = 3

class IBaseFigure(ABC):
    @abstractmethod
    def __call__(self,**kwargs)->plt.Figure:pass

class IBaseInput(ABC):
    @property
    @abstractmethod
    def name(self)->str:pass
    @abstractclassmethod
    def get_data(self)->np.ndarray:pass
    @abstractclassmethod
    def get_target(self)->np.ndarray:pass

class IBaseModel(ABC,nn.Module):
    @property
    @abstractmethod
    def name(self)->str:pass

    @abstractmethod
    def save_dict(self,modelpath):pass
    @abstractmethod
    def save_jit(self,modelpath,input):pass

    @abstractmethod
    def forward(self,x):pass

    @abstractmethod
    def predict(self,x):pass

class IFrozable(ABC):
    """Interface in order to manage parameters that shouldn't change in time...

    """
    @property
    @abstractmethod
    def _frozen(self)->Dict:pass

    def freeze(self,source:str,*attributes):
        """We freeze all attributes by their name.

        Args:
            source (str): _description_

        Raises:
            RuntimeError: _description_
        """
        for attr_name in attributes:
            if attr_name not in self.__dict__:
                raise KeyError(f'Attribute {attr_name} does not exist')
            current_attribute = getattr(self,attr_name)
            if attr_name in self._frozen:
                frozen_source = self._frozen[attr_name]['source']
                frozen_attribute = self._frozen[attr_name]['attribute']
                properties = [p for p in dir(self._frozen[attr_name]['attribute']) if not p.startswith('__')]
                for prop_name in properties:
                    frozen_value = getattr(frozen_attribute,prop_name)
                    if not hasattr(current_attribute,prop_name) or getattr(current_attribute,prop_name)!=frozen_value:
                        raise RuntimeError(f"{attr_name} have been frozen by {frozen_source} and modified later... Ensure that you define {attr_name} before calling {frozen_source}...")                        
            else:
                self._frozen[attr_name] = {'attribute':copy.deepcopy(current_attribute),'source':source}

    def unfreeze(self,*attributes):
        """
            We unfreeze some properties
        """
        
        for attr_name in attributes:
            if attr_name in self._frozen:
                del self._frozen[attr_name]

class IDistributed():
    _world_size:int = 1
    _rank:int = 0
    _local_rank:int = 0
    _distributed:bool = None
    _is_init:bool=False
    def __new__(cls, *args,**kwargs):
        """This will inform every instance if we run in distributed mode or not.

        Returns:
            _type_: _description_
        """
        obj = object.__new__(cls)
        if 'WORLD_SIZE' in os.environ:
            obj._world_size = int(os.environ["WORLD_SIZE"])
            obj._distributed = obj._world_size > 1
            obj._rank = int(os.environ["RANK"])
            obj._local_rank = int(os.environ["LOCAL_RANK"])
            # We only init_process_group from child rank 0
            if not IDistributed._is_init:
                if obj._distributed:
                    if torch.cuda.is_available():
                        dist.init_process_group(backend="nccl",world_size=obj._world_size,rank=obj._rank)
                        print(f'[INFO] INITIALIZE NCCL BACKEND rank: {obj._rank}/{obj._world_size-1}')
                    else:
                        dist.init_process_group(backend="gloo",world_size=obj._world_size,rank=obj._rank)
                        print(f'[INFO] INITIALIZE GLOO BACKEND rank: {obj._rank}/{obj._world_size-1}')
                else:
                    obj._distributed = False
                IDistributed._is_init = True
        return obj

    def rank0_only(func):
        """Decorator that will enable the function only if it is on the right rank...

        Args:
            func (_type_): _description_
        """
        def inner(self:IDistributed,*args,**kwargs):
            if self._rank == 0:
                func(self,*args,**kwargs)
            else:
                pass
        return inner

    def dist_reduce(self,tensor:torch.Tensor,reduction:REDUCTION):
        """This method will reduce a tensor on the good device.

        Args:
            tensor (torch.Tensor): _description_
            reduction (DIST_OP): _description_
            dim (_type_, optional): _description_. Defaults to None.

        Returns:
            _type_: _description_
        """
        if self._distributed:
            if reduction == REDUCTION.MEAN:
                dist.all_reduce(tensor,op=dist.ReduceOp.SUM)
                tensor = tensor/self._world_size
            elif reduction == REDUCTION.MAX:
                dist.all_reduce(tensor,op=dist.ReduceOp.MAX)
            elif reduction == REDUCTION.MIN:
                dist.all_reduce(tensor,op=dist.ReduceOp.MIN)
        return tensor
    
    def dist_concat(self,tensor:torch.Tensor,dim:int=0):
        """This method will take all the tensor in worldsize and concat them on a dimension.

        Often, this dimension is the batchsize.

        Args:
            tensor (torch.Tensor): [B,C,H,W] tensor
            dim (int, optional): _description_. Defaults to 0.

        Returns:
            _type_: concatenated tensor [B*World_size,C,H,W]
        """
        tensor_list = [torch.zeros_like(tensor) for _ in range(self._world_size)]
        dist.all_gather(tensor_list,tensor)
        cat = torch.concat(tensor_list,dim=dim)
        return cat

class IBaseTrainer(IFrozable,IDistributed):
    @property
    @abstractmethod
    def attr_hparams(self):pass
    @property
    @abstractmethod
    def attr_logging(self):pass
    ####################################
    ### protected
    ####################################
    @property
    @abstractmethod
    def _current_epoch_id(self)->int:pass
    @property
    @abstractmethod
    def _current_batch_id(self)->int:pass
    @property
    @abstractmethod
    def _current_batch(self):pass
    @property
    @abstractmethod
    def _current_dataset(self)->'IBaseDataset':pass
    @property
    @abstractmethod
    def _model(self):pass
    @property
    @abstractmethod
    def _device(self):pass

    #######################################
    ### Generic implementation in BaseTrainer
    #######################################
    @abstractclassmethod
    def set_optimizer(self):pass
    @abstractclassmethod
    def configure_training(self):pass
    @abstractclassmethod
    def set_device(self,accelerator:ACCELERATOR):pass
    
    @abstractclassmethod
    def dict(self)->Dict:pass
    
    ### Trainer Runtime
    @abstractclassmethod
    def configure_training(self)-> bool:pass
    @abstractclassmethod
    def getLr(self)-> bool:pass
    @abstractclassmethod
    def backward_step(self)-> bool:pass
    
    @abstractclassmethod
    def train_loop(self,**kwargs):pass
    @abstractclassmethod
    def train_loop_end(self,**kwargs):pass
    @abstractclassmethod
    def val_loop(self,**kwargs):pass
    @abstractclassmethod
    def val_loop_end(self,**kwargs):pass
    @abstractclassmethod
    def fit(self,**kwargs):pass

    #######################################
    ### To be implemented by new trainers
    #######################################
    @abstractclassmethod
    def train_step(self,**kwargs)->Dict[str,float]:pass
    @abstractclassmethod
    def val_step(self,**kwargs)->Dict[str,float]:pass
    @abstractclassmethod
    def test_step(self,**kwargs)->Dict[str,float]:pass

class IAccumulator(ABC):
    @abstractmethod
    def update(self,key,**kwargs):pass

    @abstractmethod
    def get(self,key,**kwargs):pass

    @abstractmethod
    def reset(self,key=None,**kwargs):pass

    def __call__(self,key,**kwargs):
        """By default, a call will update...

        Args:
            key (_type_): _description_

        Returns:
            _type_: _description_
        """
        return self.update(key,kwargs)

class IBaseDataset(ABC,IDistributed,Dataset):
    @property
    @abstractmethod
    def train_indices(self)->list:pass
    @property
    @abstractmethod
    def val_indices(self)->list:pass
    @property
    @abstractmethod
    def test_indices(self)->list:pass
    @property
    @abstractmethod
    def data(self)->list:pass
    @property
    @abstractmethod
    def istraining(self)->bool:pass
    @property
    @abstractmethod
    def pprocess(self)->PPROCESS:pass
    
    @abstractclassmethod
    def dict(self)->Dict:pass

    @abstractclassmethod
    def get_indices(self)->Tuple[List[int],List[int],List[int]]:pass
    @abstractclassmethod
    def display(self,idx)->np.ndarray:pass
    @abstractclassmethod
    def get_dataloader(self,name:str,batch_size:int,num_workers:int,epoch:int)->DataLoader:pass
    @abstractclassmethod
    def train(self,train:bool=True):pass
    @abstractclassmethod
    def eval(self,eval:bool=True):pass
    @abstractclassmethod
    def __len__(self):pass
    @abstractclassmethod
    def split(self,train_ratio:float = 0.8,val_ratio:float = 0.1,test_ratio:float = 0.1 ,seed=42):pass
    @abstractclassmethod
    def __getitem__(self,idx):pass
    @abstractclassmethod
    def __init__(self,trainer:IBaseTrainer):pass