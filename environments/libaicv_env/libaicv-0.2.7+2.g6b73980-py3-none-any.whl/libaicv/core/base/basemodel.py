from gc import collect
import torch.nn as nn
from ..factory import IBaseModel, PPROCESS
from torch.optim.lr_scheduler import _LRScheduler,StepLR,MultiStepLR
from torch.cuda.amp.grad_scaler import GradScaler
from typing import List
import torch

class BaseModel(IBaseModel):
    pprocess = None
    def __init__(self):
        nn.Module.__init__(self)
        # Protected Properties...

    def save_dict(self,model_path:str):
        torch.save(self.state_dict(), model_path)

    def save_jit(self,model_path:str,input:torch.Tensor):
        raise NotImplementedError('Not implemented yet')

    def predict(self,x):
        raise NotImplementedError('Not implemented yet')