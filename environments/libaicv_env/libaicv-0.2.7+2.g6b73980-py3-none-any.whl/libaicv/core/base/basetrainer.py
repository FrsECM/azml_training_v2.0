from ..factory import ACCELERATOR, IBaseTrainer,IBaseDataset,IBaseModel,SCHEDULER_TYPE
from ..loggers import AMLTensorboardLogger
from tqdm import tqdm
import torch
from typing import Dict,List
import torch.distributed as dist
import torch.nn as nn
from torch.optim import Adam,RMSprop,SGD
from torch.optim.lr_scheduler import _LRScheduler,StepLR,MultiStepLR,OneCycleLR,CosineAnnealingLR
from torch.cuda.amp.grad_scaler import GradScaler
import os
import json
import gc
import mlflow

class BaseHyperParams:
    Lr0:float =1e-4
    grad_clip_norm:float=None
    grad_clip_value:float=None
    num_workers:int = os.cpu_count()
    ddp_syncbn:bool = False

class BaseLoggingParams:
    logger_rootlogdir:str = 'tb_logdir'
    logger_sublogdir_suffix:str = ''
    logger_freq:int=1
    logger_logbatch:bool=False
    logger_azureml:bool=False

class BaseTrainer(IBaseTrainer):
    # Commented here in order to force Implementer not to forget it in their own implementation
    # => This way, the abstract class will generate error
    # attr_hparams:ClassificationHyperParams
    # attr_logging:ClassificationLoggingParams
    # logger = None
    # mandatory properties
    logger:AMLTensorboardLogger
    _frozen = None
    _model = None
    _current_batch = None
    _current_epoch_id = None
    _current_batch_id = None
    _current_dataset = None
    # protected properties
    _isAMP = False
    _scaler = None
    _scheduler = None
    _scheduler_type = SCHEDULER_TYPE.EPOCH
    _scheduler_config = None
    _optimizer = None
    _optimizer_config = None
    _device = torch.device('cpu')

    def __init__(self,model:IBaseModel):
        assert isinstance(model,IBaseModel),"Model should inherit from BaseModel"
        self._model:IBaseModel # Only for Autocompletion...
        self._model = model
        # We put it here for autocompletion
        self.attr_hparams:BaseHyperParams 
        self.attr_logging:BaseLoggingParams
        self._current_epoch_id = 0
        self._current_batch_id = 0
        # We redeclare frozen state
        # It is to avoid issue when re-instantiation
        self._frozen = {}

    ##########################################
    # Training Config
    ##########################################
    def set_optimizer(self):
        """Set the trainer's optimizer.

        This freeze attr_hparams that contains LearningRate.

        """
        # We freeze attr_hparams since optimizer depend on Lr0 parameter
        self.freeze('set_optimizer','attr_hparams')
        # We get the optimizer class
        # We set it's params...
        if self._optimizer_config is None:
            self.set_AdamOptimizer()
        cls = self._optimizer_config['cls']
        print(f'Optimizer type : {cls.__name__}')
        params = self._optimizer_config['params']
        self._optimizer=cls(self._model.parameters(),**params)
        # We set the scheduler...
        self.set_scheduler()

    def set_AdamOptimizer(self):
        self.freeze('set_AdamOptimizer','attr_hparams')
        self._optimizer_config={'cls':Adam,'params':{'lr':self.attr_hparams.Lr0}}
    
    def set_RMSOptimizer(self):
        self.freeze('set_RMSOptimizer','attr_hparams')
        self._optimizer_config={'cls':RMSprop,'params':{'lr':self.attr_hparams.Lr0}}

    def set_SGDOptimizer(self):
        self.freeze('set_SGDOptimizer','attr_hparams')
        self._optimizer_config={'cls':SGD,'params':{'lr':self.attr_hparams.Lr0}}

    def set_scheduler(self):
        assert self._optimizer is not None,"Optimizer should be defined before the scheduler..."
        if self._scheduler_config is not None:
            cls = self._scheduler_config['cls']
            print(f'Scheduler type : {cls.__name__}')
            params = self._scheduler_config['params']
            # We call the scheduler...
            self._scheduler=cls(self._optimizer,**params)

    def set_StepScheduler(self,step_size:int = 5,gamma:float=0.5):
        """We set a step Scheduler on our model during training...

        Args:
            step_size (int, optional): _description_. Defaults to 5.
            gamma (float, optional): _description_. Defaults to 0.5.
        """
        self._scheduler_config={'cls':StepLR,'params':{'step_size':step_size,'gamma':gamma}}
        self._scheduler_type=SCHEDULER_TYPE.EPOCH

    def set_MultiStepScheduler(self,milestones:List[int],gamma:float=0.5):
        """We set a MultiStep Scheduler on our model during training...

        Args:
            milestones (List[int]): _description_
            gamma (float, optional): _description_. Defaults to 0.5.

        Raises:
            ValueError: _description_
        """
        self._scheduler_config={'cls':MultiStepLR,'params':{'milestones':milestones,'gamma':gamma}}
        self._scheduler_type=SCHEDULER_TYPE.EPOCH

    def set_CosineAnnealingLRScheduler(self,T_max:int=1000,eta_min=1e-6,last_epoch=-1,scheduling_type:SCHEDULER_TYPE=SCHEDULER_TYPE.EPOCH):
        """We can check there :
            https://pytorch.org/docs/stable/generated/torch.optim.lr_scheduler.CosineAnnealingLR.html

        Args:
            T_max (int, optional): Period/2, Defaults to 1000.
            eta_min (int, optional): minimum Learning rate. Defaults to 0.
            last_epoch (int, optional): _description_. Defaults to -1.

        Raises:
            ValueError: _description_
        """
        self._scheduler_config={'cls':CosineAnnealingLR,'params':{'T_max':T_max,'eta_min':eta_min,'last_epoch':last_epoch}}
        self._scheduler_type=scheduling_type
        
    def set_OneCycleLRScheduler(self,total_steps:int,max_Lr:float=3e-4,):
        """We can check there :
        https://pytorch.org/docs/stable/generated/torch.optim.lr_scheduler.OneCycleLR.html

        Args:
            max_Lr (float, optional): _description_. Defaults to 3e-4.

        Raises:
            ValueError: _description_
        """

        self._scheduler_config={'cls':OneCycleLR,'params':{'max_lr':max_Lr,'total_steps':total_steps}}
        self._scheduler_type=SCHEDULER_TYPE.BATCH
         
    def set_device(self,accelerator:ACCELERATOR):
        """This method allows to set the device we'll use for training.

        Args:
            accelerator (ACCELERATOR): _description_

        Raises:
            ValueError: _description_
        """
        if accelerator == ACCELERATOR.CPU:
            print(f'[INFO] Device = CPU...')
            self._device = torch.device('cpu')
        elif accelerator ==ACCELERATOR.CUDA:
            if torch.cuda.is_available():
                print(f'[INFO] CUDA is Available => Device = CUDA...')
                self._device = torch.device('cuda',index=self._local_rank)
            else:
                print(f'[WARNING] CUDA is not Available => Back to CPU...')
                self._device = torch.device('cpu')
        elif accelerator ==ACCELERATOR.CUDA_AMP:
            if torch.cuda.is_available():
                print(f'[INFO] CUDA is Available => Device = CUDA + AMP...')
                self._device = torch.device('cuda',index=self._local_rank)
                # We set the model in AMP...
                self._isAMP = True
                self._scaler = GradScaler()
            else:
                print(f'[WARNING] CUDA is not Available => Back to CPU...')
                self._device = torch.device('cpu')
        else:
            raise ValueError(f'Accelerator {accelerator}, not implemented')

    def dict(self):
        config = {}
        config['optimizer']=self._optimizer_config
        config['scheduler']=self._scheduler_config
        config['attr_hparams']={prop:getattr(self.attr_hparams,prop) for prop in dir(self.attr_hparams) if not prop.startswith('__')}
        config['attr_logging']={prop:getattr(self.attr_logging,prop) for prop in dir(self.attr_logging) if not prop.startswith('__')}
        return config

    def save_config(self):
        config_path = os.path.join(self.logger.logdir,'config.json')
        config_dict={}
        config_dict['dataset']=self._current_dataset.dict()
        config_dict['trainer']=self.dict()
        with open(config_path,'w') as jsf:
            jsf.write(json.dumps(config_dict,indent=4,default=str))

    ##########################################
    # Training Runtime
    ##########################################
    def backward_step(self,loss:nn.Module):
        """Perform loss backpropagation and optimizer step.
        => Manage the scaler for AMP

        Args:
            loss (nn.Module): _description_
        """
        norm = 0.0
        if not self._isAMP:
            # Without AMP
            loss.backward() # We backpropagate the loss..
            if self.attr_hparams.grad_clip_norm is not None and self.attr_hparams.grad_clip_norm>0:
                nn.utils.clip_grad.clip_grad_norm_(self._model.parameters(),max_norm=self.attr_hparams.grad_clip_norm)
            self._optimizer.step()
        else:
            # With AMP
            self._scaler.scale(loss).backward() # We backpropagate the loss..
            self._scaler.unscale_(self._optimizer)
            if self.attr_hparams.grad_clip_value is not None and self.attr_hparams.grad_clip_value>0:
                # Apply grad clipping if necessary.
                # https://pytorch.org/docs/stable/notes/amp_examples.html#gradient-clipping
                norm = nn.utils.clip_grad.clip_grad_value_(self._model.parameters(),clip_value=self.attr_hparams.grad_clip_value)
            if self.attr_hparams.grad_clip_norm is not None and self.attr_hparams.grad_clip_norm>0:
                # Apply grad clipping if necessary.
                # https://pytorch.org/docs/stable/notes/amp_examples.html#gradient-clipping
                norm = nn.utils.clip_grad.clip_grad_norm_(self._model.parameters(),max_norm=self.attr_hparams.grad_clip_norm)
            self._scaler.step(self._optimizer)
            self._scaler.update()
            return norm
        
    def scheduler_step(self,schedule_type:SCHEDULER_TYPE=SCHEDULER_TYPE.EPOCH):
        if self._scheduler:
            if schedule_type==self._scheduler_type:
                self._scheduler:_LRScheduler
                self._scheduler.step()

    def getLr(self):
        """Get current Learning Rate Value...

        Raises:
            ValueError: _description_

        Returns:
            _type_: _description_
        """
        if self._optimizer is not None:
            for param_group in self._optimizer.param_groups:
                return param_group['lr']
        else:
            raise ValueError('Optimizer should be set before getting Learning Rate')
    
    ##########################################
    # Training Loops
    ##########################################
    def train_loop(self,dataset:IBaseDataset,batch_size,device:torch.device=torch.device('cpu')):
        """Training loop that iterate over the dataset during training.

        Args:
            dataset (IBaseDataset): _description_
            batch_size (_type_): _description_
            device (torch.device, optional): _description_. Defaults to torch.device('cpu').
        """
        # We switch everybody to train
        dataset.train()
        self._model.train()
        loader=dataset.get_dataloader(name='train',batch_size=batch_size,num_workers=self.attr_hparams.num_workers,epoch=self._current_epoch_id)
        pbar = tqdm(enumerate(loader),total=len(loader))
        self._model = self._model.to(device)
        # Loop
        for idx,self._current_batch in pbar:
            self._current_batch_id = idx+self._current_epoch_id*len(loader)
            outputs=self.train_step(self._current_batch,device)
            pbar.set_postfix(**outputs)
            if self._distributed:
                # We synchronize every GPUs
                dist.barrier()
            torch.cuda.empty_cache()
            self.scheduler_step(schedule_type=SCHEDULER_TYPE.BATCH)
        self.train_loop_end()
        gc.collect()
        torch.cuda.empty_cache()
        return

    def train_loop_end(self):
        pass

    def val_loop(self,dataset:IBaseDataset,batch_size,device:torch.device=torch.device('cpu')):
        # We switch everybody to eval
        dataset.eval()
        self._model.eval()
        # Loop
        loader=dataset.get_dataloader(name='val',batch_size=batch_size,num_workers=self.attr_hparams.num_workers)
        pbar = tqdm(enumerate(loader),total=len(loader))
        self._model = self._model.to(device)
        # Loop
        for idx,self._current_batch in pbar:
            self._current_batch_id = idx+self._current_epoch_id*len(loader)
            outputs=self.val_step(self._current_batch,device)
            pbar.set_postfix(**outputs)
            if self._distributed:
                # We synchronize every GPUs
                dist.barrier()
            torch.cuda.empty_cache()
        self.val_loop_end()
        gc.collect()
        torch.cuda.empty_cache()
        return

    def val_loop_end(self):
        pass

    def fit(self,dataset:IBaseDataset,batch_size:int=4,epochs:int=10,accelerator:ACCELERATOR=ACCELERATOR.CPU,**kwargs):
        # We start mlflow if we are in Azure...
        if self.attr_logging.logger_azureml:
            mlflow.start_run()
        assert isinstance(dataset,IBaseDataset),"Dataset should inherit from BaseDataset"
        # We put the dataset as an accessible property.
        self._current_dataset = dataset
        self.set_device(accelerator=accelerator)
        # We move the model to the device.
        self._model = self._model.to(self._device)
        # If we are in distributed mode...
        if self._distributed:
            # We convert BatchNorm to syncBatchNorm them accross GPUs...
            if self.attr_hparams.ddp_syncbn:
                self._model = torch.nn.SyncBatchNorm.convert_sync_batchnorm(self._model)
            self._model = nn.parallel.DistributedDataParallel(self._model,device_ids=[self._local_rank],output_device=self._local_rank)
        # We set optimizer if it is not alread set...
        self.configure_training()
        self.save_config()
        for self._current_epoch_id in range(epochs):
            print(f"Epochs {self._current_epoch_id+1}/{epochs}")
            self.train_loop(dataset,batch_size,self._device)
            self.scheduler_step(schedule_type=SCHEDULER_TYPE.EPOCH)
            if self._distributed:
                # We synchronize every GPUs
                dist.barrier()
            self.val_loop(dataset,batch_size,self._device)
            if self._distributed:
                # We synchronize every GPUs
                dist.barrier()
        # We end MLFlow run if we are in azure...
        if self.attr_logging.logger_azureml:
            mlflow.end_run()