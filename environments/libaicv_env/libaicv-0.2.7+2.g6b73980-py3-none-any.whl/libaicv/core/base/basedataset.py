from ..factory import PPROCESS,IBaseDataset,IBaseInput
import albumentations as A
from albumentations.pytorch import ToTensorV2
from torch.utils.data import Dataset,DataLoader,Subset,default_collate
from torch.utils.data.distributed import DistributedSampler
from ...utils.image import ImageHelper
from ...utils.split import split

from functools import partial
import numpy as np
import os
import re
from PIL import Image as PILImage
import torch
from typing import Dict, List, Tuple, Union
from tqdm import tqdm
import random

class BaseDataset(IBaseDataset):
    train_indices = None
    val_indices = None
    test_indices = None
    # Properties for balancing and stratifying..
    indices4classes = None
    classes4indices = None
    classes4indices_unique = None
    indices4classes_unique = None

    train_balanced_indices = None
    val_balanced_indices = None
    test_balanced_indices = None
    # Necessary to shuffle ids when reloading dataloader ###################
    _isbalanced = False
    _balanced_splits = None
    _balanced_nmax = None
    _balanced_nmin = None
    _balanced_reduce = None
    _balanced_ignorebg = None
    ########################################################################
    # Augmentations
    train_transform = None
    val_transform = None
    transform = None
    size = None
    data = None
    # Properties
    istraining = True
    pprocess = None
    _seed=42
    _issplited = None
    _isindexed = None

    def __init__(self,pprocess:PPROCESS=PPROCESS.NORMALIZE,size = (128,128)):
        # public attributes
        self.train_indices= []
        self.val_indices = []
        self.test_indices = []
        self.data=[]
        # private attributes
        self.pprocess = pprocess
        self.size = size
        #### Define transforms
        self.pprocess_transform = partial(ImageHelper.transform_apply,norm=pprocess)
        # Train Transform
        self.train_transform=A.Compose([
            A.Resize(size[0],size[1]),
            A.Lambda(name='pprocess',image=self.pprocess_transform),
            ToTensorV2(),
        ],
        is_check_shapes=False)
        # Val Transform
        self.val_transform=A.Compose([
            A.Resize(size[0],size[1]),
            A.Lambda(name='pprocess',image=self.pprocess_transform),
            ToTensorV2()
        ],is_check_shapes=False)
        # By default, we use train_transform
        self.transform = self.train_transform

    def dict(self):
        config = {}
        config['seed']=self._seed
        config['pprocess']=self.pprocess
        config['train_indices']=self.train_indices
        config['val_indices']=self.val_indices
        config['test_indices']=self.test_indices
        config['size']=self.size
        return config

    def train(self,train:bool = True):
        self.istraining = train
        self.transform = self.train_transform

    def eval(self,eval:bool = True):
        self.istraining = not eval
        self.transform = self.val_transform

    # IDataset ###########
    def get_indices(self):
        return self.train_indices,self.val_indices,self.test_indices

    def get_dataloader(self,name:str,batch_size:int=4,num_workers:int=4,shuffle:bool=True,epoch:int=0,collate_fn=default_collate)->DataLoader:
        """Set a dataloader

        Args:
            name (str): 'train' | 'val' | 'test'
            batch_size (int, optional): _description_. Defaults to 4.
            num_worker (int, optional): _description_. Defaults to 4.

        Returns:
            Tuple[DataLoader,int] : Dataloader, Len(Dataloader)
        """
        assert self._issplited,"Dataset should be split before getting dataloader..."
        assert name.upper() in ['TRAIN','VAL','TEST']
        # If balanced, we'll re-generate indices...
        if self._isbalanced:
            # For that we use our precedent parameters, in order to rebalance the dataset at each epoch
            self.balance(self._balanced_splits,self._balanced_nmax,self._balanced_nmin,self._balanced_reduce,self._balanced_ignorebg,verbose=False)
        ###################################################
        if name.upper() == 'TRAIN':
            dataset = Subset(self,self.train_indices if self.train_balanced_indices is None else self.train_balanced_indices)
            if self._distributed:
                sampler = DistributedSampler(dataset,shuffle=shuffle,rank=self._rank,num_replicas=self._world_size)
                sampler.set_epoch(epoch)
            else:
                sampler = None
            dataset:BaseDataset
            dataset.transform = self.train_transform
            return DataLoader(dataset,batch_size,num_workers=num_workers,drop_last=True,sampler=sampler,collate_fn=collate_fn)
        if name.upper() =='VAL':
            dataset = Subset(self,self.val_indices if self.val_balanced_indices is None else self.val_balanced_indices)
            if self._distributed:
                sampler = DistributedSampler(dataset,shuffle=shuffle,rank=self._rank,num_replicas=self._world_size)
                sampler.set_epoch(epoch)
            else:
                sampler = None
            dataset:BaseDataset
            dataset.transform = self.val_transform
            return DataLoader(dataset,batch_size,num_workers=num_workers,drop_last=True,sampler=sampler,collate_fn=collate_fn)
        if name.upper() == 'TEST':
            dataset = Subset(self,self.test_indices if self.test_balanced_indices is None else self.test_balanced_indices)
            if self._distributed:
                sampler = DistributedSampler(dataset,shuffle=shuffle,rank=self._rank,num_replicas=self._world_size)
                sampler.set_epoch(epoch)
            else:
                sampler = None
            dataset:BaseDataset
            dataset.transform = self.val_transform
            return DataLoader(dataset,batch_size,num_workers=num_workers,drop_last=True,sampler=sampler,collate_fn=collate_fn)

    def __len__(self):
        return len(self.data)

    def seed(self,seed:int=42):
        """Initialise the seed

        Args:
            seed (int, optional): _description_. Defaults to 42.
        """
        self._seed=seed
        random.seed(self._seed)
        np.random.seed(self._seed)
        torch.manual_seed(self._seed)

    def split(self,train_ratio:float = 0.8,val_ratio:float = 0.1,test_ratio:float = 0.1):
        """Return splits for the current dataset.
        
        If indices are already in a split before calling the split function, it is not affected.

        Args:
            train_ratio (float, optional): _description_. Defaults to 0.8.
            val_ratio (float, optional): _description_. Defaults to 0.1.
            test_ratio (float, optional): _description_. Defaults to 0.1.

        Returns:
            _type_: _description_
        """
        assert not self._issplited,"Dataset shouldn't be already splitted"
        np.random.seed(self._seed)
        if train_ratio+val_ratio+test_ratio != 1:
            total_ratio = (train_ratio+val_ratio+test_ratio)
            train_ratio = train_ratio/total_ratio
            val_ratio = val_ratio/total_ratio
            test_ratio = test_ratio/total_ratio
        indices = list(range(len(self)))
        # On commence par virer les indices qui sont pré-selectionnés...
        if len(self.train_indices)>0:
            [indices.remove(i) for i in self.train_indices]
        if len(self.val_indices)>0:
            [indices.remove(i) for i in self.val_indices]
        if len(self.test_indices)>0:
            [indices.remove(i) for i in self.test_indices]
        if len(indices)>0:
            train_indices,val_indices,test_indices = split(indices,train_ratio,val_ratio,test_ratio)
            self.train_indices.extend(train_indices)
            self.val_indices.extend(val_indices)
            self.test_indices.extend(test_indices)
        self._issplited = True
        print('####################### SPLIT')
        print(f'Train_indices : {len(self.train_indices)}')
        print(f'Val_indices : {len(self.val_indices)}')
        print(f'Test_indices : {len(self.test_indices)}')
        return self.train_indices,self.val_indices,self.test_indices   

    def split_stratified(self,train_ratio:float = 0.8,val_ratio:float = 0.1,test_ratio:float = 0.1):
        """Perform a stratified split by indexing datarows per classes and then splitting every classes with the ratio.

        Args:
            train_ratio (float, optional): _description_. Defaults to 0.8.
            val_ratio (float, optional): _description_. Defaults to 0.1.
            test_ratio (float, optional): _description_. Defaults to 0.1.
        """
        assert not self._issplited,"Dataset shouldn't be already splitted"
        np.random.seed(self._seed)
        if train_ratio+val_ratio+test_ratio != 1:
            total_ratio = (train_ratio+val_ratio+test_ratio)
            train_ratio = train_ratio/total_ratio
            val_ratio = val_ratio/total_ratio
            test_ratio = test_ratio/total_ratio
        # We start by indexing our dataset...
        self._indexAll()
        # We create : 
        # - A unique indice <=> cls association
        # - A list of already selected indices.
        already_selected =  self.train_indices+self.val_indices+self.test_indices
        for _,indices in self.indices4classes_unique.items():
            # We remove already selected indices...
            indices = [i for i in indices if i not in already_selected]
            train_indices,val_indices,test_indices = split(indices,train_ratio,val_ratio,test_ratio)
            self.train_indices.extend(train_indices)
            self.val_indices.extend(val_indices)
            self.test_indices.extend(test_indices)
        self._issplited = True
        print('####################### SPLIT STRATIFIED')
        print(f'Train_indices : {len(self.train_indices)}')
        print(f'Val_indices : {len(self.val_indices)}')
        print(f'Test_indices : {len(self.test_indices)}')
        return self.train_indices,self.val_indices,self.test_indices

    def split_patches(self,
        train_ratio:float = 0.8,
        val_ratio:float = 0.1, 
        test_ratio:float = 0.1,
        pattern:str="(?P<ROOT>.*)_[0-9]{1,2}"):
        """
        This method create a dictionnary containing data with the same 'ROOT' name.
        dict = {'ROOT1':[1,2,3,..,n],'ROOT2':[...],...,'ROOTN':[...]}
        
        Instead of spliting data based on their indices, we'll split them based on their 'ROOT' name

        UnRecognize data will go in "UNDEFINED" group...
        This group is splited as usual...
        
        Args:
            train_ratio (float, optional): _description_. Defaults to 0.8.
            val_ratio (float, optional): _description_. Defaults to 0.1.
            test_ratio (float, optional): _description_. Defaults to 0.1.
            seed (int, optional): _description_. Defaults to 42.
            pattern (str, optional): _description_. Defaults to "(?P<ROOT>.*)_[0-9]{1,2}".

        Raises:
            TypeError: _description_
        """
        if not isinstance(self.data,list):
            raise TypeError("data should be a dictionnary to be able to split patches")
        data_dict = {}
        undefined = []
        for i,data in enumerate(self.data):
            match = re.match(pattern,data.name)
            if match:
                # We have a match, we'll add this to data_dict
                root = match.group('ROOT')
                if root in data_dict:
                    data_dict[root].append(i)
                else:
                    data_dict[root]=[i]
            else:
                undefined.append(i)
        # We start by spliting dictionnary...
        indices = list(range(len(data_dict)))
        train_roots,val_roots,test_roots = split(indices,train_ratio,val_ratio,test_ratio)
        for i,root in enumerate(data_dict):
            if i in train_roots:
                self.train_indices.extend(data_dict[root])
            elif i in val_roots:
                self.val_indices.extend(data_dict[root])
            else:
                self.test_indices.extend(data_dict[root])
        if len(undefined)>0:
            indices = list(range(len(undefined)))
            train_undef,val_undef,test_undef = split(indices,train_ratio,val_ratio,test_ratio)
            self.train_indices.extend(train_undef)
            self.val_indices.extend(val_undef)
            self.test_indices.extend(test_undef)
        self._issplited = True
        return self.train_indices,self.val_indices,self.test_indices

    def balance(self,splits:List[str]=['train','val','test'],nmax:Union[int,None]=10000,nmin:Union[int,None]=None,reduce:bool=True,ignore_bg:bool=False,verbose:bool=True):
        """Generate balanced indices
        This method replicates minor class indices for each splits...

        Args:
            nmax (int, optional): the maximum number of indices that will be returned...
            reduce(bool,False) : reduce the size of splits to initial size...
        """
        assert self._issplited,"Dataset should be split before getting dataloader..."
        if nmax is not None and nmin is not None:
            assert nmin<nmax,"nmin should be <= nmax"
        splits = [s.upper() for s in splits]
        if not self._isindexed:
            self._indexAll()
        if 'TRAIN' in splits:
            self.train_balanced_indices = self._balance_split(self.train_indices,nmax,nmin,reduce,ignore_bg)
        if 'VAL' in splits:
            self.val_balanced_indices = self._balance_split(self.val_indices,nmax,nmin,reduce,ignore_bg)
        if 'TEST' in splits:
            self.test_balanced_indices = self._balance_split(self.test_indices,nmax,nmin,reduce,ignore_bg)
        # we log that we are balanced
        self._balanced_splits = splits
        self._balanced_nmax = nmax
        self._balanced_reduce = reduce
        self._balanced_ignorebg=ignore_bg
        self._balanced_nmin = nmin
        self._isbalanced = True
        if verbose:
            print('Balanced...')

    def _balance_split(self,current_split:List[int],nmax:Union[int,None]=100000,nmin:Union[int,None]=None,reduce:bool=True,ignore_bg:bool=False):
        """Balance a split

        Args:
            split (List[int]): _description_
            nmax (int, optional): Max count in the split. Defaults to 100000.
            reduce (bool, optional): reduce the final split to actual size. Defaults to True.

        Returns:
            New Split
        """

        indices4classes_split,_ = self._indexSubset(current_split)
        if ignore_bg:
            if 0 in indices4classes_split:
                del indices4classes_split[0]
            if 'Background' in indices4classes_split:
                del indices4classes_split['Background']
        # We get the max number of image for a class...
        class_count = {k:len(v) for (k,v) in indices4classes_split.items()}
        max_class_count = max(list(class_count.values()))
        # For every class, we'll replicate while we don't have the same amount of images....
        for cls in indices4classes_split:
            # We get the current split...
            split = indices4classes_split[cls]
            if len(split)>0 and len(split)<max_class_count:
                n_repeat        = max_class_count//len(split)
                n_complement    = max_class_count%len(split)
                # We replicate !
                result = split*n_repeat+split[:n_complement]
                indices4classes_split[cls]=result
        # We fuse results
        new_split = []
        [new_split.extend(i) for i in indices4classes_split.values()]
        np.random.shuffle(new_split)
        # Depending on the reduction strategy, we'll keep or not data.
        if reduce:
            new_split=new_split[:len(current_split)]
        if isinstance(nmax,int):
            if nmax<len(new_split):
                new_split=new_split[:nmax]
        if isinstance(nmin,int):
            if len(new_split)<nmin:
                # We create a new subset containing nmin samples...
                new_split = np.random.choice(new_split,nmin)
        return new_split

    def _indexSubset(self,current_subset:List[int])->Tuple[Dict,Dict]:
        """Generate two dicts :
        - classes:[ids] - indices4classes
        - ids:[classes] - classes4indices

        Args:
            current_subset (List[int]): subset of indices

        Returns:
            (Tuple[Dict,Dict]): indices4classes,classes4indices
        """
        if not self._isindexed:
            self._indexAll()
        
        indices4classes_subset = {k:[] for k,_ in self.indices4classes_unique.items()}
        classes4indices_subset = {}
        # We index classes for the subset
        for indice in current_subset:
            classes4indices_subset[indice]=self.classes4indices_unique[indice]
            if self.classes4indices_unique[indice] is not None:
                indices4classes_subset[self.classes4indices_unique[indice]].append(indice)
            else:
                if 'Background' not in indices4classes_subset:
                    indices4classes_subset['Background']=[]
                indices4classes_subset['Background'].append(indice)
        return indices4classes_subset,classes4indices_subset
        
    def _indexAll(self):
        """Create Two dict :
        - classes:[ids]
        - ids:[classes]
        For all Datarows in dataset...
        """
        ibar = tqdm(range(self.__len__()))
        ibar.set_description_str('Indexing classes/indices...')
        assert hasattr(self, '__getitem__'),"__getitem__ should be implemented to index classes"
        self.indices4classes = {0:[],1:[]} # We set classes indices with 2 classes by default
        self.classes4indices = {}
        for i in ibar:
            if hasattr(self,'get_classes'):
                classes = self.get_classes(i)
            else:
                _,y,_ = self.__getitem__(i)
                if isinstance(y,torch.Tensor):
                    classes = torch.unique(y).tolist()
                elif isinstance(y,int):
                    classes = [y]
                else:
                    raise TypeError("Output Type should be in [torch.Tensor,int]")
            # Continue
            self.classes4indices[i] = classes
            for cls in classes:
                if cls in self.indices4classes:
                    self.indices4classes[cls].append(i)
                else:
                    self.indices4classes[cls]=[i]
        self._isindexed = True
        # We copy classes4indices to avoid problem with indices without labels...
        self.indices4classes_unique={}
        self.classes4indices_unique={i:None for i in range(len(self))}
        # We create a list of unavailable indices...
        indice_available = {i:True for i in range(len(self))}
        # We iterate over indices list and start by the rare class...
        cbar = tqdm(sorted(self.indices4classes.items(),key=lambda item:len(item[1])),desc='Unique Association Class/indice...')
        for cls,indices_list in cbar:
            if hasattr(self,'clsNames'):
                cbar.set_postfix({'cls_name':getattr(self,'clsNames')[cls],'nIndices':len(indices_list)})
            else:
                cbar.set_postfix({'cls_id':cls,'nIndices':len(indices_list)})
            # For each calass, we create a lit of indice.
            self.indices4classes_unique[cls]=[]
            for indice in indices_list:
                if indice_available[indice]:
                    self.indices4classes_unique[cls].append(indice)
                    self.classes4indices_unique[indice]=cls
                    # We set the indice as unavailable of next classes.
                    indice_available[indice]=False

    def display(self,idx):
        raise NotImplementedError(f'This method is not implemented for this class {self.__class__}')


class BaseImage(IBaseInput):
    img_path = None
    lbl_path = None
    name = None

    def __init__(self,img_path:str):
        if not os.path.exists(img_path):
             raise OSError(f"Image Path do not exists \n{img_path}")
        # We get the name from image name.
        self.name = os.path.splitext(os.path.basename(img_path))[0]
        self.img_path = img_path

    def get_data(self):
        with PILImage.open(self.img_path) as pil_img:
            np_array = np.array(pil_img)
        return np_array