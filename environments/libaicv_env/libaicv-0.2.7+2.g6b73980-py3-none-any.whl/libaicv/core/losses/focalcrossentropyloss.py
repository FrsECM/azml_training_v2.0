import torch
import torch.nn as nn

class FocalCrossEntropyLoss(nn.Module):
    """Focal Loss
    https://medium.com/visionwizard/centernet-objects-as-points-a-comprehensive-guide-2ed9993c48bc#716d
    Args:
        nn ([type]): [description]
    """
    def __init__(self,gamma=0,weights=None,reduction='mean'):
        super().__init__() # Focal Loss is stacked by mean
        self.gamma = gamma
        self.weights=weights
        self.isweighed=weights is not None
        self._epsilon=1e-15
        self.reduce=reduction

    def forward(self, pred:torch.Tensor, target:torch.Tensor):
        """Focal Loss that works like CrossEntropyLoss...
        Args:
            pred (torch.Tensor): [B,C,*], type = float()
            target (torch.Tensor): [B,*], type = long()
        Returns:
            _type_: _description_
        """
        assert len(pred.shape)>=3,"prediction shape should be at least len 3"
        assert pred.shape[0]==target.shape[0],"prediction, and target should have the same batch size"
        assert target.dtype.is_floating_point==False,"target should be a int/long."
        assert pred.dtype.is_floating_point==True,"target should be a int/long."
        assert len(pred.shape)==len(target.shape)+1,"target and prediction should be [B,*], and [B,C,*]"
        if self.isweighed:
            assert len(self.weights)==pred.shape[1],"weights len should be equal to class count..."
        _loss=0
        soft_pred_view=torch.softmax(pred,dim=1).view(pred.shape[0],pred.shape[1],-1)
        target_view=target.view(target.shape[0],-1)
        for cls_i,pred_cls in enumerate(soft_pred_view.permute(1,0,2)):
            # On récupère les indices positifs et négatifs...    
            pos_inds=target_view.eq(cls_i).bool()
            # On calcule les "sous loss"
            if self.isweighed:
                weight=self.weights[cls_i].float()
            else:
                weight=1.0
            pos_loss=-weight*torch.log(pred_cls+self._epsilon)*torch.pow(1-pred_cls,self.gamma)*pos_inds
            # On calcule la loss
            _loss+=pos_loss
        if self.reduce:
            if self.reduce=='sum':
                _loss = _loss.sum()
            else:
                _loss = _loss.mean()
        return _loss