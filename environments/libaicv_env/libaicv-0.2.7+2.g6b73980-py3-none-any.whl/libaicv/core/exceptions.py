class SizeError(Exception):
    pass

class EmptyList(Exception):
    pass