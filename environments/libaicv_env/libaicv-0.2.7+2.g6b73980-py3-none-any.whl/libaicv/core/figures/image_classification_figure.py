from ..factory import PPROCESS
from ...utils.image import colorize_classification,transform,reverse
from ..factory import IBaseFigure

import matplotlib.pyplot as plt
import numpy as np
from torch import nn
import torch
import matplotlib
from typing import List


def plot_ClassificationImages(X:torch.Tensor,y:torch.Tensor,y_pred:torch.Tensor,norm:PPROCESS=PPROCESS.STANDARDIZE,display_dim:int=0,bg_class:int=0,clsNames:List[str]=None,border:int=3):
    """Plot image matrix
    Args:
        X (torch.tensor): Tensor [B,3,H,W] or [B,H,W]  containing Original Images [C = 3 or C ==1]
        y (torch.tensor): Tensor [B] containing prediction as a shape B matrix
        y_hat (torch.tensor): Tensor [B] containing target as a shape B matrix
    Returns:
        figure : Matplotlib figure
    """
    # We check that image is in the correct format...
    if len(y.shape)!=1 or len(y_pred.shape)!=1:
        raise ValueError('y and y_hat should be [B] tensors')
    if y.shape != y_pred.shape:
        raise ValueError('y and y_hat should share the same shape')
    if len(X.shape) not in [4,3]:
        raise ValueError('Tensor should be [B,N,H,W],[B,3,H,W],[B,1,H,W] or [B,H,W]')
    if len(X.shape)==3:
        # We unsqueeze dim 1 to be able to go through reverse process..
        X=X.unsqueeze(1)
    else:
        if X.shape[1] not in [1,3]:
            X = X[:,display_dim,:,:].unsqueeze(1)
    # We check that target is in correct format
    assert X.shape[1] in [1,3],"Image should have 1 or 3 channels"        
    image = reverse(X,norm)
    if image.shape[-1]==1:
        image = image.squeeze(-1)
    # We compute the border size :
    size_min = min(X.shape[-2:])
    border_px = int(border*size_min/2)
    nBatch=X.shape[0]
    fig,ax=plt.subplots(1,nBatch,figsize=(16,9))
    # We plots :
    # - Original Image
    # - Target
    # - Prediction
    for i in range(nBatch):
        title = None
        if clsNames is not None:
            prediction = clsNames[y_pred[i]]
            target = clsNames[y[i]]
            title = f"T : {target}\nP : {prediction}"
        img = colorize_classification(image[i],y[i],y_pred[i],bg_class=bg_class,border=border_px)
        if nBatch==1:
            ax.imshow(img,cmap='gray', vmin = 0, vmax = 255)
            if title:
                ax.set_title(title)
            ax.set_axis_off()
        else:
            ax[i].imshow(img,cmap='gray', vmin = 0, vmax = 255)
            if title:
                ax[i].set_title(title)
            ax[i].set_axis_off()
    return fig

class ImageClassificationFigure(IBaseFigure):
    def __init__(self,
        pprocess:PPROCESS=PPROCESS.STANDARDIZE,
        display_dim:int=0,
        bg_class:int=0,
        clsNames:List[str]=None,
        max_count:int=4,
        border:float=0.1):
        """Plot image segmentation prediction and groundtruth.

        Args:
            freq (int, optional): _description_. Defaults to 100.
            pprocess (PPROCESS,optional): Preprocessing applyed in the dataset. Default PPROCESS.STANDARDIZE
            display_dim (int, optional): _description_. Defaults to 0.
        """
        assert border>0 and border<1,"Border should be in [0-1]"
        self.pprocess = pprocess
        self.display_dim = display_dim
        self.bg_class = bg_class
        self.clsNames = clsNames
        self.max_count=max_count
        self.border=border
        matplotlib.use('agg')

    
    def __call__(self,X:torch.Tensor,y:torch.Tensor,y_hat:torch.Tensor,apply_softmax:bool = True):
        assert X is not None
        assert y is not None
        assert y_hat is not None
        if apply_softmax:
            y_hat_max = y_hat.softmax(dim=1).max(dim=1)[1]
        else:
            y_hat_max = y_hat.max(dim=1)[1]
        batch_size = X.shape[0]
        if self.max_count<batch_size:
            X=X[:self.max_count]
            y=y[:self.max_count]
            y_hat_max = y_hat_max[:self.max_count]
        else:
            X = X
            y = y
        fig=plot_ClassificationImages(X,
            y,
            y_hat_max,
            self.pprocess,
            display_dim = self.display_dim,
            bg_class=self.bg_class,
            clsNames=self.clsNames,
            border=self.border)
        return fig