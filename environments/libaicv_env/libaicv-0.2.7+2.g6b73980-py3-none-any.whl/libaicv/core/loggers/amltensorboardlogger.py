from datetime import datetime
from torch.utils.tensorboard.writer import SummaryWriter
import os
import torch
import torch.nn as nn
import matplotlib.pyplot as plt
import copy
import torch.distributed as dist
from typing import Union
from ..accumulator import MetricsAccumulator
from ..factory import REDUCTION,IDistributed
import math
import importlib.util
global MLFLOW
MLFLOW = importlib.util.find_spec('mlflow')
if MLFLOW:
    import mlflow

STRATEGY = {
            'min':min,
            'max':max
            }

class AMLTensorboardLogger(IDistributed):
    """The logger will be use to interact with tensorboard and azureML.
    The logger will only log one node, rank 0.

    Args:
        IDistributed (_type_): _description_
    """
    def __init__(self,rootLogDir='tb_results',LogDir_suffix='',logbatch:bool=False,log_freq:int=1,log_azure:bool=False):
        self.logname = datetime.now().strftime("%y%m%d_%H%M")+f"_{LogDir_suffix}"
        logdir=os.path.join(rootLogDir,self.logname)
        os.makedirs(logdir,exist_ok=True)
        self.logdir=logdir
        self.logbatch = logbatch
        self.logwriter=SummaryWriter(logdir)
        self.log_azure=log_azure
        ###################################################################################
        ### We add this part in order to checkpoint models with our logger
        ###################################################################################
        self.current_checkpoint_path = None
        self.current_checkpoint_loss = None
        self.accumulator = MetricsAccumulator()
        self.log_freq=log_freq
        #### Enable tracing...
        self._traces = False
        self._tracesList = []

    @IDistributed.rank0_only
    def savemodel(self,model:nn.Module,loss_value:torch.Tensor,iteration:int):
        """Save a model to the path...

        Args:
            model (IBaseModel): _description_
            path (str): _description_
        """
        if isinstance(loss_value,torch.Tensor):
            loss_value=loss_value.item()
        model_name = f"model_it_{iteration}_loss_{round(loss_value,4)}.pth"
        # We manage the case we trained with DDP to remove extra "modules" in dict keys.
        model_ = copy.deepcopy(model)
        model_type="model"
        # We check if we are in the case of a DDP Model
        if isinstance(model_,(torch.nn.parallel.DistributedDataParallel,torch.nn.parallel.DataParallel)):
            model_=model_.module
            model_type="ddpmodel"
        # we get the state dit and save the it...
        state_dict = model_.state_dict()
        # We only save the model on rank 0
        self.current_checkpoint_path = os.path.join(self.logdir,model_name)
        self.current_checkpoint_loss = loss_value
        torch.save(state_dict, self.current_checkpoint_path)
        if self._traces:
            self._tracesList.append(('CHECKPOINT',self.current_checkpoint_path,model_type,iteration))

    @IDistributed.rank0_only
    def checkpoint(self,model:nn.Module,loss_value:Union[torch.Tensor,float,int],iteration:int,strategy='min'):
        assert strategy in STRATEGY,'Strategy should be min or max'
        best_func=STRATEGY[strategy]
        if self.current_checkpoint_loss is None:
            # We save for the first time...
            self.savemodel(model,loss_value,iteration)
        else:
            if loss_value == best_func(loss_value,self.current_checkpoint_loss):
                os.remove(self.current_checkpoint_path) # We remove old model
                self.savemodel(model,loss_value,iteration) # We keep best model...

    @IDistributed.rank0_only
    def checkpoint_acc(self,model:nn.Module,key:str,iteration:int,strategy='min'):
        """add a checkpoint but on accumulation value of a loss.

        Args:
            key (str): _description_
            iteration (int): _description_
            strategy (str, optional): _description_. Defaults to 'min'.
        """
        if key not in self.accumulator.keys():
            raise KeyError(f'Key not in accumulator keys {list(self.accumulator.keys())}')
        agg_value = self.accumulator.get(key=key)
        # We save our checkpoint by the agg value
        self.checkpoint(model,agg_value,iteration=iteration,strategy=strategy)

    @IDistributed.rank0_only
    def log_scalar(self,key:str,value:Union[torch.Tensor,float],global_step:int,ignore_freq:bool=False,ignore_aml:bool=False):
        """This method is used in order to log either in AzureML if necessary, either in tensorboard.
        Args:
            key (_type_): _description_
            value (_type_): _description_
            global_step (_type_): _description_
            ignore_freq (bool) : Ignore logfreq
            ignore_aml (bool) : Ignore AML Logging
        """
        assert isinstance(value,(torch.Tensor,float,int)),"value should be a float or a tensor"
        if isinstance(value,torch.Tensor):
            value=value.item()
        if not math.isnan(value) and not math.isinf(value):
            if ignore_freq or not global_step%self.log_freq:
                self.logwriter.add_scalar(key,value,global_step)
                if self._traces:
                        self._tracesList.append(('TENSORBOARD',key,value,global_step))
                if self.log_azure and not ignore_aml:
                    # If there is an AZ Run, we log there also.
                    mlflow.log_metric(key,float(value),step=global_step)
                    if self._traces:
                        self._tracesList.append(('AZML',key,value,global_step))

    @IDistributed.rank0_only
    def log_scalar_acc(self,key:str,value:float,global_step:int,reduction:REDUCTION):
        """This method accumulate a scalar.
        If logbatch is enabled, it log the scalar, else, it accumulate it.
        Args:
            key (str): _description_
            value (float): _description_
            global_step (int): _description_
            reduction(REDUCTION)
        """
        assert isinstance(reduction,REDUCTION),'Reduction should be from REDUCTION enum (factory)'
        assert isinstance(value,float),'value should be a float'
        assert isinstance(global_step,int),'Global step should be an integer'
        if not math.isnan(value) and not math.isinf(value):
            if self.logbatch:
                self.log_scalar(key,value,global_step)
            self.accumulator.update(f'{key}_{reduction.name.lower()}',value,reduction)
    
    @IDistributed.rank0_only
    def log_aggregate(self,global_step:int,reset:bool=True):
        """We log what have been accumulated...

        Args:
            global_step (int): _description_
            reset (bool, optional): _description_. Defaults to True.
        """
        for key in self.accumulator.keys():
            agg_value = self.accumulator.get(key=key)
            # We force scalar logging
            self.log_scalar(key,agg_value,global_step,ignore_freq=True)

        # If necessary we reset.
        if reset:
            self.accumulator.reset()
    
    @IDistributed.rank0_only
    def __log_figure(self,key:str,fig,global_step:int):
        self.logwriter.add_figure(key,fig,global_step)
        if self._traces:
            self._tracesList.append(('TENSORBOARD',key,fig,global_step))
        
    def log_figure(self,key:str,fig,global_step:int):
        """This method is used in order to log in tensorboard.
        Args:
            key (_type_): _description_
            value (_type_): _description_
            global_step (_type_): _description_
        """
        self.__log_figure(key,fig,global_step)
        # Dans tous les cas.. on close la figure.
        plt.close(fig)
    
    @IDistributed.rank0_only
    def log_hist(self,key:str,data:torch.Tensor,global_step:int):
        """This method log an histogram in tensorboard.

        Args:
            key (str): _description_
            data (torch.Tensor): _description_
            global_step (int): _description_
        """
        self.logwriter.add_histogram(key,data,global_step)
        if self._traces:
            self._tracesList.append(('TENSORBOARD',key,data,global_step))
    
    ############################################################################
    ## Only for testing
    ############################################################################
    def enable_traces(self,istracing:bool=True):
        """This method enable tracing for test purpose in order to debug Logger

        Args:
            istracing (bool, optional): _description_. Defaults to True.
        """
        self._traces = istracing

    def get_traces(self)-> dict:
        """This method allows to get traces for test purpose

        Returns:
            dict: _description_
        """
        traces_dict = {}
        for trace in self._tracesList:
            logger,key,item,step = trace
            if logger not in traces_dict:
                traces_dict[logger]={}
            if key not in traces_dict[logger]:
                traces_dict[logger][key]={}
            if step not in traces_dict[logger][key]:
                traces_dict[logger][key][step]=item
        return traces_dict