from ..factory import IAccumulator
from typing import Union,List
import numpy as np
from ..factory import REDUCTION


REDUCTIONS = {
    REDUCTION.MEAN:np.mean,
    REDUCTION.MAX:np.max,
    REDUCTION.MIN:np.min
    }

class MetricsAccumulator(IAccumulator):
    _stack = {}

    def __init__(self):
        self._stack = {}

    ##########################################
    ####### IACCUMULATOR
    ##########################################
    def update(self,key:str,value:float,reduction:REDUCTION=REDUCTION.MEAN):
        """Accumulate values in order to perform the reduction when getting it.

        Args:
            key (str): _description_
            value (float): _description_
            reduction(str): reduction in 'mean','max','min'

        Returns:
            value
        """
        if not isinstance(value,float):
            raise ValueError('value should be a python float, not a tensor')
        if not isinstance(reduction,REDUCTION):
            raise KeyError(f"Reduction should be in REDUCTION")
        assert isinstance(value,float),"Values to accumulate should be float values."
        if key not in self._stack:
                self._stack[key]={'values':[value],'reduction':reduction}
        else:
            stack = self._stack[key]
            if stack['reduction'] != reduction:
                raise KeyError(f"values already exists for key {key} with reduction {stack['reduction']} != {REDUCTIONS.keys()}")
            self._stack[key]['values'].append(value)
        return value

    def keys(self):
        """Get available keys
        """
        return list(self._stack.keys())
    
    def get(self,key:str):
        """Get the aggregated key

        Args:
            key (str): _description_

        Returns:
            float: mean value
        """
        if key not in self._stack:
            raise KeyError(f"Key {key} should be in stack")
        stack = self._stack[key]
        return REDUCTIONS[stack['reduction']](stack['values'])
        
    def reset(self,key=None):
        """We reset the accumulator

        Args:
            key (str, optional): Defaults to None.
        """
        if key is None:
            # we remove every keys
            self._stack={}
        else:
            del self._stack[key]