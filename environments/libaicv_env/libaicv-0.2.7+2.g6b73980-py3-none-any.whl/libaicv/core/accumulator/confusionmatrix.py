import torch
import numpy as np
import matplotlib.pyplot as plt
from typing import List
from ..factory import IAccumulator
import matplotlib
from sklearn.metrics import confusion_matrix
import seaborn as sns

def make_confusion_matrix(cf,
                          group_names=None,
                          categories='auto',
                          count=True,
                          percent=True,
                          cbar=True,
                          xyticks=True,
                          xyplotlabels=True,
                          sum_stats=True,
                          cmap='Blues',
                          title=None):
    '''
    This function will make a pretty plot of an sklearn Confusion Matrix cm using a Seaborn heatmap visualization.
    https://github.com/DTrimarchi10/confusion_matrix/blob/master/cf_matrix.py

    Arguments
    ---------
    cf:            confusion matrix to be passed in
    group_names:   List of strings that represent the labels row by row to be shown in each square.
    categories:    List of strings containing the categories to be displayed on the x,y axis. Default is 'auto'
    count:         If True, show the raw number in the confusion matrix. Default is True.
    normalize:     If True, show the proportions for each category. Default is True.
    cbar:          If True, show the color bar. The cbar values are based off the values in the confusion matrix.
                   Default is True.
    xyticks:       If True, show x and y ticks. Default is True.
    xyplotlabels:  If True, show 'True Label' and 'Predicted Label' on the figure. Default is True.
    sum_stats:     If True, display summary statistics below the figure. Default is True.
    cmap:          Colormap of the values displayed from matplotlib.pyplot.cm. Default is 'Blues'
                   See http://matplotlib.org/examples/color/colormaps_reference.html
                   
    title:         Title for the heatmap. Default is None.
    '''


    # CODE TO GENERATE TEXT INSIDE EACH SQUARE
    blanks = ['' for i in range(cf.size)]
    if group_names and len(group_names)==cf.size:
        group_labels = ["{}\n".format(value) for value in group_names]
    else:
        group_labels = blanks
    if count:
        group_counts = ["{0:0.0f}\n".format(value) for value in cf.flatten()]
    else:
        group_counts = blanks
    percent_mat = None
    if percent:
        # We compute percentage per class instead of global.
        group_percentages = ["{0:.1%}".format(value) for value in cf.flatten()/(np.sum(cf,axis=0).repeat(cf.shape[1]))]
        percent_mat = cf/(1e-5+np.sum(cf,axis=1))
    else:
        group_percentages = blanks
    box_labels = [f"{v1}{v2}{v3}".strip() for v1, v2, v3 in zip(group_labels,group_counts,group_percentages)]
    box_labels = np.asarray(box_labels).reshape(cf.shape[0],cf.shape[1])
    # CODE TO GENERATE SUMMARY STATISTICS & TEXT FOR SUMMARY STATS
    if sum_stats:
        #Accuracy is sum of diagonal divided by total observations
        accuracy  = np.trace(cf) / (float(np.sum(cf))+1e-5)
        #if it is a binary confusion matrix, show some more stats
        if len(cf)==2:
            #Metrics for Binary Confusion Matrices
            precision = cf[1,1] / (sum(cf[:,1])+1e-5)
            recall    = cf[1,1] / (sum(cf[1,:])+1e-5)
            f1_score  = 2*precision*recall / (precision + recall+1e-5)
            stats_text = "\n\nAccuracy={:0.3f}\nPrecision={:0.3f}\nRecall={:0.3f}\nF1 Score={:0.3f}".format(
                accuracy,precision,recall,f1_score)
        else:
            stats_text = "\n\nAccuracy={:0.3f}".format(accuracy)
    else:
        stats_text = ""

    # SET FIGURE PARAMETERS ACCORDING TO OTHER ARGUMENTS
    if xyticks==False:
        #Do not show categories if xyticks is False
        categories=False
    # MAKE THE HEATMAP VISUALIZATION
    plt.rc('font', size=5*(10/cf.shape[1]))
    fig, ax = plt.subplots(figsize=(7,6),dpi=155)
    matrix = cf if percent_mat is None else percent_mat
    sns.heatmap(matrix,annot=box_labels,fmt="",cmap=cmap,cbar=cbar,xticklabels=categories,yticklabels=categories,ax=ax)
    ax.tick_params(axis='both', which='major', labelsize=10)
    if xyplotlabels:
        plt.ylabel('True label')
        plt.xlabel('Predicted label' + stats_text)
    else:
        plt.xlabel(stats_text)
    if title:
        plt.title(title)
    return fig

class ConfusionMatrixAccumulator(IAccumulator):
    def __init__(self,clsIDs:List[int],clsNames:List[str]):
        if not isinstance(clsIDs,(list,range)):
            raise TypeError('cls_ids should be a list')
        assert max(clsIDs)<=len(clsNames),"ClassNames should contain at least maxId items..."
        # We create properties
        self.clsIDs = clsIDs
        self.clsNames = clsNames
        self.groundtruths=[]
        self.predictions=[]
        matplotlib.use('agg')
        self.reset()

    def reset(self):
        self.groundtruths = []
        self.predictions = []

    def __call__(self,y_hat:torch.Tensor,y:torch.Tensor,apply_softmax:bool = True):
        return self.update(y_hat,y,apply_softmax)
    
    def update(self,y_hat:torch.Tensor,y:torch.Tensor,apply_softmax:bool = True):
        if apply_softmax:
            y_hat_softmax = y_hat.softmax(dim=1)
        else:
            y_hat_softmax = y_hat
        y_pred_flat = y_hat_softmax.max(dim=1)[1].reshape(-1).detach().cpu()
        y_flat = y.reshape(-1).detach().cpu()
        # We append to groundtruth and predictions our values.
        assert y_pred_flat.shape==y_flat.shape,"y_flat and y_pred_flat should have the same shape...."
        self.groundtruths.append(y_flat)
        self.predictions.append(y_pred_flat)
        return None

    def get(self):
        groundtruths = torch.concat(self.groundtruths).numpy()
        predictions = torch.concat(self.predictions).numpy()
        cmat = confusion_matrix(groundtruths,predictions)
        cmat_fig = make_confusion_matrix(cmat,categories=self.clsNames)
        return cmat_fig

