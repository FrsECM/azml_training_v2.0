import torch
import enum
import numpy as np
import matplotlib.pyplot as plt
from typing import List,Dict
import matplotlib
from ..factory import IAccumulator

def getVerdicts(prediction:torch.Tensor,target:torch.Tensor,threshold:float):
    """ prediction and target should be the same shape

    Args:
        prediction (torch.Tensor): [B,*] matrix
        target (torch.Tensor): [B,*] matrix
    """
    if prediction.shape!=target.shape:
        raise ValueError(
            f"""
            prediction {prediction.shape[0]} and target {target.shape[0]} batchsize
            should be equals
            """
        )
    tp = torch.logical_and(prediction>=threshold,target==1).sum().detach().cpu()
    tn = torch.logical_and(prediction<threshold,target!=1).sum().detach().cpu()
    fp = torch.logical_and(prediction>=threshold,target!=1).sum().detach().cpu()
    fn = torch.logical_and(prediction<threshold,target==1).sum().detach().cpu()
    return tp,tn,fp,fn

def PlotViDiCurve(TP,TN,FP,FN,Thresholds,Label):
    """Returns a ViDi like figure to plot in tensorboard
    Args:
        Verdicts (torch.Tensor): [nThresholds,4] => TP,TN,FP,FN
        Thresholds ([type]): [nThresholds]
    Returns:
        [fig]: [description]
    """
    fig,ax=plt.subplots(1,1,figsize=(10,8))
    plt.rc('font', size=10)
    distC=FP/(TN+FP+1e-5) # FP/(TN+FP)
    distNC=FN/(TP+FN+1e-5) # FN/(TP+FN)
    ax.plot(Thresholds,distC,color='g',label='OK')
    ax.fill_between(Thresholds,distC,color='g',alpha=0.5)
    ax.plot(Thresholds,distNC,color='r',label='NOK')
    ax.fill_between(Thresholds,distNC,color='r',alpha=0.5)
    ax.set_xlabel('Thresholds')
    ax.set_ylabel(f'Distribution {Label}')
    ax.legend()
    return fig

def PlotPRCurve(TP,TN,FP,FN,Thresholds,Label,plotIoU:bool=False):
    """Returns a PRCurve figure to plot in tensorboard
    Args:
        Verdicts (torch.Tensor): [nThresholds,4] => TP,TN,FP,FN
        Thresholds ([type]): [nThresholds]
        plotIoU (bool) : False
    Returns:
        [fig]: [description]
    """
    Recalls=TP/(TP+FN+1e-5)
    Precisions=TP/(TP+FP+1e-5)
    IoU = TP/(TP+FP+FN+1e-5)
    # We plot the curve
    Colors=['r','g','b']
    fig,ax=plt.subplots(1,1,figsize=(6,6),dpi=155)
    plt.rc('font', size=10)
    curve=['precision','recall','IoU']
    data=[Precisions,Recalls,IoU]
    if not plotIoU:
        # We remove the last element of the curve list...
        curve=curve[:-1]
    for m,mtype in enumerate(curve):
        color=Colors[m]
        lb=f"{mtype}_{Label}"
        ax.plot(Thresholds,
            data[m],label=lb,
            color=color,linestyle='-',linewidth=4)
    minor_ticks=np.arange(0,1.01,0.05)
    major_ticks=np.arange(0,1.01,0.1)
    ax.set_xticks(minor_ticks,minor=True)
    ax.set_yticks(minor_ticks,minor=True)
    ax.set_xticks(major_ticks)
    ax.set_yticks(major_ticks)
    ax.grid(which='major',color='#DDDDDD',linestyle='-')
    ax.grid(which='minor',color='#EEEEEE',linestyle='--')
    ax.set_xlabel('threshold')
    ax.set_ylabel(f"{Label} value")
    ax.legend()
    return fig



class VMODE(enum.Enum):
    PRCURVE     = 0
    VIDICURVE   = 1

class VerdictsAccumulator(IAccumulator):
    def __init__(self,clsIDs:List[int],clsNames:List[str],n_thresholds:int=25,plotIoU:bool=False):
        """Create a Verdict Figure based on thresholds...

        Args:
            n_thresholds (int, optional): _description_. Defaults to 25.
        """
        if not isinstance(clsIDs,(list,range)):
            raise TypeError('cls_ids should be a list')
        assert max(clsIDs)<=len(clsNames),"ClassNames should contain at least maxId items..."
        # We create properties
        self.thresholds = torch.linspace(0,1,n_thresholds)
        self.cls_ids = clsIDs
        self.clsNames = clsNames
        self.plotIoU=plotIoU
        # We create accumulators...
        self.reset()
        matplotlib.use('agg')

    def reset(self):
        # We add 4 accumulators by thresholds...
        for cls_id in self.cls_ids:
            # We add 4 accumulators for maximum predicted threshold.
            setattr(self,f"true_positive_MAX_c{cls_id}",torch.tensor(0))
            setattr(self,f"false_positive_MAX_c{cls_id}",torch.tensor(0))
            setattr(self,f"true_negative_MAX_c{cls_id}",torch.tensor(0))
            setattr(self,f"false_negative_MAX_c{cls_id}",torch.tensor(0))
            for t in self.thresholds:
                # We add 4 accumulators by thresholds...
                setattr(self,f"true_positive_t{t}_c{cls_id}",torch.tensor(0))
                setattr(self,f"false_positive_t{t}_c{cls_id}",torch.tensor(0))
                setattr(self,f"true_negative_t{t}_c{cls_id}",torch.tensor(0))
                setattr(self,f"false_negative_t{t}_c{cls_id}",torch.tensor(0))

    def get_all_figure(self,mode:VMODE=VMODE.PRCURVE)->Dict[str,plt.Figure]:
        result = {}
        mode_str = 'PRCURVE' if mode == VMODE.PRCURVE else 'ViDiCURVE'
        for cls_id in self.cls_ids:
            cls_name = self.clsNames[cls_id]
            label = f"{mode_str}_{cls_name}"
            result[label]=self.get(mode,cls_name,cls_id)
        return result

    def __call__(self,y_hat:torch.Tensor,y:torch.Tensor,apply_softmax:bool = True):
        """We call the figure verdict

        Args:
            y_hat (torch.Tensor): _description_
            y (torch.Tensor): _description_
            apply_softmax (bool, optional): _description_. Defaults to True.

        Returns:
            _type_: _description_
        """
        return self.update(y_hat,y,apply_softmax)

    def update(self,y_hat:torch.Tensor,y:torch.Tensor,apply_softmax:bool = True):
        if apply_softmax:
            y_hat_softmax = y_hat.softmax(dim=1)
        else:
            y_hat_softmax = y_hat
        # We compute the max
        y_hat_max = y_hat_softmax[:].max(dim=1)[1]
        for cls_id in self.cls_ids:
            # We put value to one for the most probable class
            tp,tn,fp,fn = getVerdicts(y_hat_max == cls_id,y == cls_id,threshold=0.1)
            TP_attr = getattr(self,f'true_positive_MAX_c{cls_id}')
            TN_attr = getattr(self,f'true_negative_MAX_c{cls_id}')
            FP_attr = getattr(self,f'false_positive_MAX_c{cls_id}')
            FN_attr = getattr(self,f'false_negative_MAX_c{cls_id}')
            TP_attr += tp
            TN_attr += tn
            FP_attr += fp
            FN_attr += fn
            for t in self.thresholds:
                # We get corresponding states attributes
                TP_attr = getattr(self,f'true_positive_t{t}_c{cls_id}')
                TN_attr = getattr(self,f'true_negative_t{t}_c{cls_id}')
                FP_attr = getattr(self,f'false_positive_t{t}_c{cls_id}')
                FN_attr = getattr(self,f'false_negative_t{t}_c{cls_id}')
                # We get values and add to states
                tp,tn,fp,fn = getVerdicts(y_hat_softmax[:,cls_id],y == cls_id,threshold=t)
                TP_attr += tp
                TN_attr += tn
                FP_attr += fp
                FN_attr += fn
    
    def get(self,mode:VMODE=VMODE.PRCURVE,label='',cls_id:int=1)->plt.Figure:
        """Compute the PRCurve or ViDiCurve
        Args:
            mode (VFMODE, optional): _description_. Defaults to VFMODE.PRCURVE.
            label (str, optional): _description_. Defaults to ''.

        Returns:
            _type_: _description_
        """
        if cls_id not in self.cls_ids:
            raise ValueError(f'cls_id {cls_id} should be in self.cls_ids {self.cls_ids}')
        TP = torch.tensor([getattr(self,f'true_positive_t{t}_c{cls_id}') for t in self.thresholds])
        TN = torch.tensor([getattr(self,f'true_negative_t{t}_c{cls_id}') for t in self.thresholds])
        FP = torch.tensor([getattr(self,f'false_positive_t{t}_c{cls_id}') for t in self.thresholds])
        FN = torch.tensor([getattr(self,f'false_negative_t{t}_c{cls_id}') for t in self.thresholds])
        if mode == VMODE.PRCURVE:
            return PlotPRCurve(TP,TN,FP,FN,self.thresholds,Label=label)
        else:
            return PlotViDiCurve(TP,TN,FP,FN,self.thresholds,Label=label)

    ####################################################   
    # We can get some metrics from the accumulator.
    ####################################################   
    def get_metric_IoU(self,cls_id:int=1):
        """Compute IoU For  cls_id

        This metric is based on the most probable detected class
        Args:
            cls_id (int, optional): _description_. Defaults to 1.

        Raises:
            ValueError: _description_

        Returns:
            _type_: _description_
        """
        if cls_id not in self.cls_ids:
            raise ValueError(f'cls_id {cls_id} should be in self.cls_ids {self.cls_ids}')
        TP = getattr(self,f'true_positive_MAX_c{cls_id}')
        FN = getattr(self,f'false_negative_MAX_c{cls_id}')
        FP = getattr(self,f'false_positive_MAX_c{cls_id}')
        IoU = TP/(TP+FP+FN+1e-5)
        return IoU
    
    def get_metric_Recall(self,cls_id:int=1):
        """Compute Recall for cls_id

        This metric is based on the most probable detected class

        Args:
            cls_id (int, optional): _description_. Defaults to 1.

        Raises:
            ValueError: _description_

        Returns:
            _type_: _description_
        """
        if cls_id not in self.cls_ids:
            raise ValueError(f'cls_id {cls_id} should be in self.cls_ids {self.cls_ids}')
        TP = getattr(self,f'true_positive_MAX_c{cls_id}')
        FN = getattr(self,f'false_negative_MAX_c{cls_id}')
        FP = getattr(self,f'false_positive_MAX_c{cls_id}')
        recall=TP/(TP+FN+1e-5)
        return recall
    
    def get_metric_Precision(self,cls_id:int=1):
        """Compute Precision for cls_id

        This metric is based on the most probable detected class

        Args:
            cls_id (int, optional): _description_. Defaults to 1.

        Raises:
            ValueError: _description_

        Returns:
            _type_: _description_
        """
        if cls_id not in self.cls_ids:
            raise ValueError(f'cls_id {cls_id} should be in self.cls_ids {self.cls_ids}')
        TP = getattr(self,f'true_positive_MAX_c{cls_id}')
        FN = getattr(self,f'false_negative_MAX_c{cls_id}')
        FP = getattr(self,f'false_positive_MAX_c{cls_id}')
        Precision=TP/(TP+FP+1e-5)
        return Precision