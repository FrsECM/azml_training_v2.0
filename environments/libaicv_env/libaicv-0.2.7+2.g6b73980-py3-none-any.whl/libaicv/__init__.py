from . import _version
from .core import ACCELERATOR,PPROCESS

__version__ = _version.get_versions()['version']
