from ..core.base import BaseModel
from typing import List

class SegmentationModel(BaseModel):
    name="SegmentationModel"
