import torch.nn as nn
import torch
import torch.nn.functional as F

class GDiceLoss(nn.Module):
    def __init__(self,reduction='mean',weight_batch:bool=True,M:torch.Tensor=None):
        """Generalised Dice Loss
            https://arxiv.org/pdf/1707.00478.pdf

        Args:
            reduction (str, optional): _description_. Defaults to 'mean'.
            weight_classes (bool, optional): Will compute a coefficient based on the volume of each classes in the batch. Defaults to True.
            M (torch.Tensor, optional): Matrix in order to finetune penalisation for specific Class Associations.
            M_rows = GT => reducing value on 1st row will penalise less Leak...
            M_cols = Prediction
            

        """
        super().__init__()
        if M is not None:
            assert isinstance(M,torch.Tensor),'M should be a tensor...'
            assert len(M.shape)==2,"M should be a [C,C] matrix"
            assert M.shape[0]==M.shape[1],"M should be a squared matrix"
            # We normalize matrix
            M = M/M.max()
        assert reduction in ['mean','sum']
        self._epsilon=1e-15
        self._reduction=reduction
        self.weight_batch = weight_batch
        self.M:torch.Tensor=M

    def _compute_alpha(self,target_flat:torch.Tensor,nClasses:int)->torch.Tensor:
        """Compute a coefficient for each pixel depending on it's relative volume in each image...
        The more the class is rare, the more the weight will be high.

        Args:
            target_flat_one_hot : [B,N] matrix containing classes
            nClasses : int corresponding to the C number of classes...

        Returns:
            torch.Tensor: alpha : [B,C]
        """
        if self.weight_batch:
            # In case we weight the batch...
            target_one_hot=F.one_hot(target_flat,num_classes=nClasses).permute(0,2,1)
            b,c,n=target_one_hot.shape
            volumes = target_one_hot.sum(dim=2) # We sum over all pixels (b,c)
            alpha = 1./(volumes+1.) # b,c
            # Now, we'll create a verctor B,N that match the target_flat size...
            alpha = alpha.unsqueeze(-1).expand(b,c,n) # b,c,1
            flat_target_extended = torch.unsqueeze(target_flat,dim=1) # b,1,N
            alpha = torch.gather(alpha,dim=1,index=flat_target_extended) # We pick the value in alpha corresponding to the value of the flat target.
        else:
            # In the other case
            alpha = torch.ones_like(target_flat)
        return alpha # b,N

    def _compute_wasserstein_distance(self,prob_flat:torch.Tensor,target_flat:torch.Tensor):
        """We compute the wasserstein distance map by penalising each errors by a coefficient in [0-1]
        The maximum penalisation for an error is 1 but it can be decreased if some classes can be a little correlated / confused.

        Args:
            pred_flat (torch.Tensor): [B,C,N]
            target_flat (torch.Tensor): [B,N]
        """
        B,C,N = prob_flat.shape
        if self.M is not None:
            M = self.M.clone().type_as(prob_flat)[None,...,None] # 1,C,C,1
        else:
            # If there is no Matrix preset, we'll use a matrix with 0 on the diagonal to compute the error matrix.
            # M =   |0 1 1|
            #       |1 0 1|
            #       |1 1 0|
            # That mean non matching value will have a weight == 1 in the Loss computation.
            M = (torch.ones((C,C))-torch.eye(C)).type_as(prob_flat)[None,...,None] # 1,C,C,1
        # We expand M to B,C,C,N
        M = M.expand((B,C,C,N))
        # We expand flat_target to B,C,N
        target_flat_extended = target_flat.unsqueeze(dim=1).expand((B,C,N))
        # We compute the (B,C,N) groundTruth with coefficient for each type of class errors
        # It means if 1 was predicted for the wrong class, it ll count as "coef" in the error
        # Coeff are coming from M matrix.
        M = M.gather(dim=1,index=target_flat_extended.unsqueeze(dim=1)).squeeze() # => B,C,C,N => B,1,C,N => B,C,N
        wasserstein_dist = M*prob_flat # B,C,N x B,C,N
        return wasserstein_dist.sum(dim=1) # => B,N

    def forward(self, pred, target)->torch.Tensor:
        assert len(pred.shape)>=3,"prediction shape should be at least len 3"
        assert pred.shape[0]==target.shape[0],"prediction, and target should have the same batch size"
        assert target.dtype in [torch.long],"target should be a long."
        assert len(pred.shape)==len(target.shape)+1,"target and prediction should be [B,*], and [B,C,*]"
        # On récupère les indices positifs et négatifs...
        b=pred.shape[0]
        c=pred.shape[1]
        # We flatten predictions and target...
        pred_flat = pred.view(b,c,-1) # b,c,n
        prob_flat = torch.softmax(pred_flat,dim=1) # b,c,n
        target_flat = target.view(b,-1) # b,n

        # We compute the dist_map (error map)
        wasserstein_dist_map = self._compute_wasserstein_distance(prob_flat,target_flat)
        # We are in the case of normal
        alpha = self._compute_alpha(target_flat,c)
        all_errors = wasserstein_dist_map #  errors = 1 - truepos
        numerator = 2.*torch.sum(alpha*(1.-wasserstein_dist_map),dim=1) # size b
        denom = torch.sum(alpha*(2.*(1.-wasserstein_dist_map)+all_errors),dim=1) # size b

        wass_dice = numerator/(denom+self._epsilon)
        _loss=1-wass_dice
        if self._reduction:
            if self._reduction=='sum':
                _loss = _loss.sum()
            else:
                _loss = _loss.mean()
        return _loss
    


if __name__=='__main__':
    target = torch.zeros((4,10,10)).long()
    target[:2,:,5:]=1
    prediction = torch.zeros((4,3,10,10)).float()
    prediction[:2,:,:,:] = 1 # half of pixels are one, the other half is 0
    # We compute IoULoss
    m = torch.tensor([
        [0,1,1],
        [1,0,1],
        [1,1,0]
    ])
    loss = GDiceLoss()(prediction,target)
    print('terminé')