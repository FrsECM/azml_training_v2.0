from ..core.factory import IBaseModel,REDUCTION
from ..core.base.basetrainer import BaseTrainer,BaseHyperParams,BaseLoggingParams
from ..core.loggers import AMLTensorboardLogger
from .losses import IoULoss,GDiceLoss
from ..core.losses import FocalCrossEntropyLoss as FCELoss
from ..core.accumulator import VerdictsAccumulator,VMODE
from ..core.figures import GradFlowFigure,grad_norm
from .figures import ImageSemanticSegmentationFigure as ImageFigure
from .import SegmentationDataset,SegmentationModel
import torch

class SegmentationHyperParams(BaseHyperParams):
    alpha_fce:float = 0.5
    alpha_iou:float = 0.5
    alpha_dice:float = 0

class SegmentationLoggingParams(BaseLoggingParams):
    curve_nThresholds:int=25
    curve_plotIoU:bool=True
    gradflow_frequency:int = 100
    # Image figures
    imagefig_frequency_train:int=50
    imagefig_frequency_val:int=50
    imagefig_maxcount:int = 4
    imagefig_displaydim:int = 0

class SegmentationTrainer(BaseTrainer):
    attr_hparams:SegmentationHyperParams = None
    attr_logging:SegmentationLoggingParams = None
    logger = None
    # num_worker = 0

    def __init__(self,model:IBaseModel,root_logdir:str='tb_logdir',sub_logdir_suffix:str=''):
        super().__init__(model)
        assert isinstance(model,SegmentationModel),"Model should be a segmentation Model"
        self._current_dataset:SegmentationDataset
        self.attr_hparams:SegmentationHyperParams = SegmentationHyperParams()
        self.attr_logging:SegmentationLoggingParams = SegmentationLoggingParams()
        self.attr_logging.logger_rootlogdir=root_logdir
        self.attr_logging.logger_sublogdir_suffix = sub_logdir_suffix

    def configure_training(self) -> bool:
        self.freeze('configure_training','attr_hparams','attr_logging')
        self.set_optimizer()
        self.logger = AMLTensorboardLogger(
            rootLogDir=self.attr_logging.logger_rootlogdir,
            LogDir_suffix=self.attr_logging.logger_sublogdir_suffix,
            logbatch=self.attr_logging.logger_logbatch,
            log_freq=self.attr_logging.logger_freq,
            log_azure=self.attr_logging.logger_azureml)
        # Only for testing purpose...
        self.logger.enable_traces(hasattr(self,'traces'))
        ##### We set losses
        self.fceloss = FCELoss()
        self.iouloss = IoULoss()
        self.diceloss = GDiceLoss()
        self.gradflow = GradFlowFigure()
        self.imageplot = ImageFigure(
            pprocess=self._current_dataset.pprocess,
            display_dim=self.attr_logging.imagefig_displaydim,
            max_count=self.attr_logging.imagefig_maxcount)
        self.verdicts = VerdictsAccumulator(
            clsIDs=range(self._current_dataset.clsCount),
            clsNames=self._current_dataset.clsNames,
            n_thresholds=self.attr_logging.curve_nThresholds,
            plotIoU=self.attr_logging.curve_plotIoU
        )

    @torch.enable_grad()
    def train_step(self,batch, device = 'cpu')->dict:
        self.current_dataset:SegmentationDataset
        self._optimizer.zero_grad()
        X,y,_ = batch
        X = X.to(device).float()
        y = y.to(device)
        nBatch = X.shape[0]
        with torch.cuda.amp.autocast(enabled=self._isAMP):
            pred = self._model.forward(X)
            # We compute Losses
            losses_dict = {}
            total_loss = 0.
            if self.attr_hparams.alpha_fce>0:
                losses_dict['FCELoss'] = self.fceloss.forward(pred,y.long())
                total_loss += self.attr_hparams.alpha_fce*losses_dict['FCELoss']
            if self.attr_hparams.alpha_iou>0:
                losses_dict['IoULoss'] = self.iouloss.forward(pred,y.long())
                total_loss += self.attr_hparams.alpha_iou*losses_dict['IoULoss']
            if self.attr_hparams.alpha_dice>0:
                losses_dict['DiceLoss'] = self.iouloss.forward(pred,y.long())
                total_loss += self.attr_hparams.alpha_dice*losses_dict['DiceLoss']
            # We compute the total loss...
            losses_dict['TotalLoss'] = total_loss
            ########################################### Backward loss
            self.backward_step(total_loss)
            gradnorm = grad_norm(self._model)
            if self._distributed:
                for loss_name in list(losses_dict.keys()):
                    losses_dict[loss_name] = self.dist_reduce(losses_dict[loss_name],REDUCTION.MEAN)
                gradnorm = self.dist_reduce(gradnorm,REDUCTION.MEAN)
            # We log losses
            for loss_name in list(losses_dict.keys()):
                self.logger.log_scalar_acc(f"Train/{loss_name}",losses_dict[loss_name].item(),global_step=self._current_batch_id,reduction=REDUCTION.MEAN)
            self.logger.log_scalar_acc("Train/GradNorm",gradnorm.item(),global_step=self._current_batch_id,reduction=REDUCTION.MEAN)
            if not self._current_batch_id%self.attr_logging.gradflow_frequency:
                self.logger.log_figure("Train/GradFlow",self.gradflow(self._model),self._current_batch_id)
            if not self._current_batch_id%self.attr_logging.imagefig_frequency_train:
                self.logger.log_figure("Train/Images",self.imageplot(X,y,pred),global_step=self._current_batch_id) 
            # We convert the result in order to return a dictionnary for the progress bar.
            result = {k:v.item() for (k,v) in losses_dict.items()}
            result['grad_norm']=gradnorm.item()
        return result

    def train_loop_end(self):
        # We logg the learning rate.
        self.logger.log_scalar('Train/Lr',self.getLr(),self._current_epoch_id,ignore_freq=True)
        # We logg what have been aggregated...
        self.logger.log_aggregate(self._current_epoch_id)
        return

    @torch.no_grad()
    def val_step(self,batch,device = 'cpu')->dict:
        self.current_dataset:SegmentationDataset
        X,y,_ = batch
        nBatch=X.shape[0]
        X=X.to(device)
        y=y.to(device)
        with torch.cuda.amp.autocast(enabled=self._isAMP):
            pred=self._model.forward(X)
            # We compute Losses
            losses_dict = {}
            total_loss = 0.
            if self.attr_hparams.alpha_fce>0:
                losses_dict['FCELoss'] = self.fceloss.forward(pred,y.long())
                total_loss += self.attr_hparams.alpha_fce*losses_dict['FCELoss']
            if self.attr_hparams.alpha_iou>0:
                losses_dict['IoULoss'] = self.iouloss.forward(pred,y.long())
                total_loss += self.attr_hparams.alpha_iou*losses_dict['IoULoss']
            if self.attr_hparams.alpha_dice>0:
                losses_dict['DiceLoss'] = self.iouloss.forward(pred,y.long())
                total_loss += self.attr_hparams.alpha_dice*losses_dict['DiceLoss']
            # We compute the total loss...
            losses_dict['TotalLoss'] = total_loss
            # Then, we need to compute softmax on prediction...
            pred_softmaxed=torch.softmax(pred,dim=1) # We softmax on the first dim and put it in the end for further masking
            # We plots images...
            if not self._current_batch_id%self.attr_logging.imagefig_frequency_val:
                self.logger.log_figure("Val/Images",self.imageplot(X,y,pred),global_step=self._current_batch_id)
            ############################################################
            # MultiGPU Aggregation
            ###########################################################            
            if self._distributed:
                for loss_name in list(losses_dict.keys()):
                    losses_dict[loss_name] = self.dist_reduce(losses_dict[loss_name],REDUCTION.MEAN)
                pred_softmaxed = self.dist_concat(pred_softmaxed,dim=0)
                y = self.dist_concat(y,dim=0)
            #############################################################
            #### We compute Metrics
            #############################################################
            # We feed accumulators
            self.verdicts(pred_softmaxed,y,apply_softmax=False)
            #############################################################
            #### Logging
            #############################################################
            # We log losses
            for loss_name in list(losses_dict.keys()):
                self.logger.log_scalar_acc(f"Val/{loss_name}",losses_dict[loss_name].item(),global_step=self._current_batch_id,reduction=REDUCTION.MEAN)
 
        return {k:v.item() for (k,v) in losses_dict.items()}

    def val_loop_end(self):
        # We log figures...
        self.verdicts:VerdictsAccumulator
        for fig_name,figure in self.verdicts.get_all_figure(mode=VMODE.PRCURVE).items():
            self.logger.log_figure(f"Val/{fig_name}",figure,self._current_epoch_id)
        for fig_name,figure in self.verdicts.get_all_figure(mode=VMODE.VIDICURVE).items():
            self.logger.log_figure(f"Val/{fig_name}",figure,self._current_epoch_id)
        # We log metrics from accumulator...
        for cls_id in self.verdicts.cls_ids:
            cls_name = self.verdicts.clsNames[cls_id]
            IoU_cls_id = self.verdicts.get_metric_IoU(cls_id)
            self.logger.log_scalar(f'Val/IoU_{cls_name}',IoU_cls_id.item(),self._current_epoch_id,ignore_freq=True)
        # We reset our accumulators
        self.verdicts.reset()
        # We log losses/metrics
        self.logger.checkpoint_acc(self._model,key='Val/TotalLoss_mean',iteration=self._current_epoch_id,strategy='min')
        self.logger.log_aggregate(self._current_epoch_id)
        return

    def test_step(self,batch,device = 'cpu')->dict:
        return NotImplemented