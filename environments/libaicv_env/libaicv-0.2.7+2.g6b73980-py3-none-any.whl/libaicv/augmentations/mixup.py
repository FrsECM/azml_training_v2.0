import albumentations as A
import albumentations.augmentations.functional as F
from albumentations.core.bbox_utils import BboxProcessor
import numpy as np

from typing import List,Dict,Any
from ..detection.yolodataset import YoloDataset,YoloImage
from .rgb_conversions import force_rgb
import random
import cv2

class MixUp(A.DualTransform):
    def __init__(self,alpha:float=2,always_apply: bool = False, p: float = 0.5):
        super().__init__(always_apply, p)
        self.alpha=alpha
        
    def get_params(self,image:np.ndarray,dataset:YoloDataset,indices:list):
        # we randomly select an indice and gets it's image and target...
        height,width = image.shape[:2]
        bbox_converter = BboxProcessor(A.BboxParams(format='yolo',label_fields=['class_labels']))
        indice = np.random.choice(indices,1)[0]
        mixRate = np.random.beta(self.alpha,self.alpha,1)[0]
        instance = dataset.data[indice]
        instance:YoloImage
        image = force_rgb(instance.get_data())
        image = cv2.resize(image,(width,height),interpolation=cv2.INTER_LINEAR)
        bboxes,clsIds = instance.get_target(dataset.clsNames)
        # We'll combine bboxes and class as tuple like albumentation do...
        other_boxes = bbox_converter.convert_to_albumentations([(*bbox,cls) for bbox,cls in zip(bboxes,clsIds)],height,width)
        return {'other_image':image,'other_bboxes':other_boxes,'mixRate':mixRate}

    def __call__(self, *args, force_apply: bool = False, **kwargs) -> Dict[str, Any]:
        if (random.random() < self.p) or self.always_apply or force_apply:
            assert 'dataset' in kwargs,'dataset should be in kwargs for MixUp'
            assert 'indices' in kwargs,'indices should be in kwargs for MixUp'
            assert isinstance(kwargs['indices'],list),"Indices must be a list of indices"
            assert isinstance(kwargs['dataset'],YoloDataset),"dataset must be a YoloDataset to use MixUp"
            if kwargs['dataset'].mixup_enabled:
                # If mixup is enabled in the dataset, we'll do MixUp transform...
                params = self.get_params(kwargs['image'],kwargs['dataset'],kwargs['indices'])
                return self.apply_with_params(params, **kwargs)
        return kwargs

    def apply_to_bboxes(self, bboxes, **params):
        # We'll append bboxes together...
        return bboxes + params['other_bboxes']

    def apply(self, img, **kwargs):
        img2 = kwargs['other_image']
        mix_rate = kwargs['mixRate']
        # We'll mix both images...
        return (mix_rate*img+(1-mix_rate)*img2).astype(np.uint8).clip(0,255)

if __name__=="__main__":
    transfo=MixUp(p=1)
    image=np.zeros((512,256))
    imagejpg=transfo(image=image,dataset='test_dataset',indices='test_indices')
