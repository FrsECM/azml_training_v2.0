import albumentations as A
import albumentations.augmentations.functional as F
import albumentations.augmentations.crops.functional as CF
import albumentations.augmentations.geometric.functional as GF
from albumentations.core.bbox_utils import BboxProcessor
import numpy as np

from typing import List,Dict,Any,Tuple
from ..detection.yolodataset import YoloDataset,YoloImage
from .rgb_conversions import force_rgb
import random
import cv2
from typing import Union,Tuple
from enum import Enum

A.HorizontalFlip()
class MosaicHelper:
    def __init__(self,img_height,img_width):
        self.img_height=img_height
        self.img_width=img_width
        self.image=None
        self._ZI = {
            0:self.__fill_top_left,
            1:self.__fill_top_right,
            2:self.__fill_bottom_left,
            3:self.__fill_bottom_right,
        }
        self._ZB = {
            0:self.__bboxes_top_left,
            1:self.__bboxes_top_right,
            2:self.__bboxes_bottom_left,
            3:self.__bboxes_bottom_right,
        }
        # We create a new image empty...
        self.image=np.zeros((2*self.img_height,2*self.img_width,3),dtype=np.uint8)
        self.bboxes=[]

    #PRIVATE 
    def __fill_top_left(self,image):
        assert image.shape==(self.img_height,self.img_width,3),f"{image.shape} given, ({self.img_height},{self.img_width},3) expected"
        self.image[0:self.img_height,0:self.img_width,:]=image
    def __fill_top_right(self,image):
        assert image.shape==(self.img_height,self.img_width,3),f"{image.shape} given, ({self.img_height},{self.img_width},3) expected"
        self.image[0:self.img_height,self.img_width:,:]=image
    def __fill_bottom_left(self,image):
        assert image.shape==(self.img_height,self.img_width,3),f"{image.shape} given, ({self.img_height},{self.img_width},3) expected"
        self.image[self.img_height:,0:self.img_width,:]=image
    def __fill_bottom_right(self,image):
        assert image.shape==(self.img_height,self.img_width,3),f"{image.shape} given, ({self.img_height},{self.img_width},3) expected"
        self.image[self.img_height:,self.img_width:,:]=image
    def __bboxes_top_left(self,bboxes):
        bboxes = np.array(bboxes).reshape(-1,5)
        bboxes[:,:4]=bboxes[:,:4]/2+np.array([0,0,0,0])
        self.bboxes.extend(bboxes.tolist())
    def __bboxes_top_right(self,bboxes):
        bboxes = np.array(bboxes).reshape(-1,5)
        bboxes[:,:4]=bboxes[:,:4]/2+np.array([0.5,0,0.5,0])
        self.bboxes.extend(bboxes.tolist())
    def __bboxes_bottom_left(self,bboxes):
        bboxes = np.array(bboxes).reshape(-1,5)
        bboxes[:,:4]=bboxes[:,:4]/2+np.array([0,0.5,0,0.5])
        self.bboxes.extend(bboxes.tolist())
    def __bboxes_bottom_right(self,bboxes):
        bboxes = np.array(bboxes).reshape(-1,5)
        bboxes[:,:4]=bboxes[:,:4]/2+np.array([0.5,0.5,0.5,0.5])
        self.bboxes.extend(bboxes.tolist())

    # PUBLIC
    def fill_image(self,zone:int,image):
        self._ZI[zone](image)

    def fill_bboxes(self,zone:int,bboxes):
        self._ZB[zone](bboxes)

class Mosaic(A.DualTransform):
    def __init__(self,min_start=0.25,max_start=0.75,always_apply: bool = False, p: float = 0.5):
        super().__init__(always_apply, p)
        self.min_start=min_start
        self.max_start=max_start

    def get_params(self,image:np.ndarray,bboxes:List[Tuple[float]],dataset:YoloDataset,indices:list):
        # we randomly select an indice and gets it's image and target...
        self.height,self.width = image.shape[:2]
        bbox_converter = BboxProcessor(A.BboxParams(format='yolo',label_fields=['class_labels']))
        # We fill a list containing images and bboxes
        images_list = [image]
        bboxes_list = [bboxes]
        indices = np.random.choice(indices,3)
        for indice in indices:
            instance = dataset.data[indice]
            instance:YoloImage
            image = force_rgb(instance.get_data())
            image = cv2.resize(image,(self.width,self.height),interpolation=cv2.INTER_LINEAR)
            bboxes,clsIds = instance.get_target(dataset.clsNames)
            # We'll combine bboxes and class as tuple like albumentation do...
            other_boxes = bbox_converter.convert_to_albumentations([(*bbox,cls) for bbox,cls in zip(bboxes,clsIds)],self.height,self.width)
            images_list.append(image)
            bboxes_list.append(other_boxes)
        # We randomly select the mosaic id of each image/bboxes
        im_pos = np.arange(4)
        np.random.shuffle(im_pos)
        mosaic = MosaicHelper(self.height,self.width)
        for pos in im_pos:
            flip = random.random()>0.5
            if flip:
                image = GF.hflip_cv2(images_list[pos])
                bboxes=[GF.bbox_hflip(tuple(bbox[:4]),self.height,self.width)+tuple(bbox[4:]) for bbox in bboxes_list[pos]]
            else:
                image = images_list[pos]
                bboxes = bboxes_list[pos]
            mosaic.fill_image(pos,image)
            mosaic.fill_bboxes(pos,bboxes)
        h_start =random.random()* (self.max_start - self.min_start) + self.min_start
        w_start =random.random()* (self.max_start - self.min_start) + self.min_start
        return {'mosaic':mosaic,"h_start": h_start, "w_start": w_start}


    def __call__(self, *args, force_apply: bool = False, **kwargs) -> Dict[str, Any]:
        if (random.random() < self.p) or self.always_apply or force_apply:
            assert 'dataset' in kwargs,'dataset should be in kwargs for Mosaic'
            assert 'indices' in kwargs,'indices should be in kwargs for Mosaic'
            assert isinstance(kwargs['indices'],list),"Indices must be a list of indices"
            assert isinstance(kwargs['dataset'],YoloDataset),"dataset must be a YoloDataset to use Mosaic"
            if kwargs['dataset'].mosaic_enabled:
                # If mixup is enabled in the dataset, we'll do MixUp transform...
                params = self.get_params(kwargs['image'],kwargs['bboxes'],kwargs['dataset'],kwargs['indices'])
                return self.apply_with_params(params, **kwargs)
        return kwargs
    
    def apply_to_bboxes(self, bboxes, **params):
        # We replace bboxes by newly generated ones...
        bboxes=params['mosaic'].bboxes
        return [self.apply_to_bbox(tuple(bbox[:4]), **params) + tuple(map(int,bbox[4:])) for bbox in bboxes]  # type: ignore
    
    def apply_to_bbox(self, bbox,h_start=0, w_start=0,**params):
        # We'll append bboxes together..
        return CF.bbox_random_crop(bbox,self.height,self.width,h_start,w_start,rows=self.height*2,cols=self.width*2)

    def apply(self, img, h_start=0, w_start=0,**kwargs):
        return CF.random_crop(kwargs['mosaic'].image, self.height, self.width, h_start, w_start)



        


if __name__=="__main__":
    transfo=Mosaic(p=1)
    image=np.zeros((512,256))
    imagejpg=transfo(image=image,dataset='test_dataset',indices='test_indices')
