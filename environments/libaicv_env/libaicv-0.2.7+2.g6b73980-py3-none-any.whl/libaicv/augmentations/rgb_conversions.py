import albumentations as A
import albumentations.augmentations.functional as F
import numpy as np

class RGBA2RGB(A.ImageOnlyTransform):
    def __init__(self, always_apply: bool = True, p: float = 1):
        super().__init__(always_apply, p)
    def apply(self, img, **params):
        return img[:,:,:3]

def force_rgb(img):
    if len(img.shape)==3:
        if img.shape[2]>3:
            return img[:,:,:3]
        elif img.shape[2]<3:
            return np.expand_dims(img[:,:,0],-1).repeat(3,axis=-1)
        else:
            return img
    elif len(img.shape)==2:
        return np.expand_dims(img,-1).repeat(3,axis=-1)
    
class ForceRGB(A.ImageOnlyTransform):
    def __init__(self, always_apply: bool = True, p: float = 1):
        super().__init__(always_apply, p)
    def apply(self, img, **params):
        return force_rgb(img)
        
if __name__ =='__main__':
    img_rgb=np.zeros([20,20,3])
    img_rgba=np.zeros([20,20,4])
    img_gray=np.zeros([20,20,1])
    img_gray1=np.zeros([20,20])

    force_rgb=ForceRGB()
    for img in [img_rgba,img_gray,img_gray1]:
        assert np.isclose(img_rgb,force_rgb.apply(img)).min() ==True 