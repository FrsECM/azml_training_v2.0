import albumentations as A
import albumentations.augmentations.functional as F
import numpy as np

class ShearoInvertImg(A.ImageOnlyTransform):
    def apply(self, img, **params):
        assert len(img.shape)==3 and img.shape[-1]==2,f"InvertShearoImg : img.shape should be [H,W,2], {img.shape} given"
        shearoImg=img[:,:,0]
        videoImg=img[:,:,1]
        inverted=F.invert(shearoImg)
        return np.array([inverted,videoImg]).transpose(1,2,0)

    def get_transform_init_args_names(self):
        return ()


if __name__=="__main__":
    A.InvertImg()
    pass