class RGBA2RGB(A.ImageOnlyTransform):
    def apply(self, img, **params):
        return img[:,:,:3]