from ..core.base import BaseDataset,BaseImage
from ..core.factory import PPROCESS
from ..core.exceptions import SizeError
from ..utils.os import Directory
from PIL import Image as PILImage
import os
import numpy as np
from typing import List,Union
from yarrow import YarrowDataset,Annotation
import cv2
from tqdm.auto import tqdm
import torch
import json
from enum import Enum
from .utils.coco2017 import CocoAnnotationFile
from ..utils.bboxes import BboxHelper,BBOX_TYPE
from ..utils.image import ImageHelper
import albumentations as A
from albumentations.pytorch import ToTensorV2
from torch.utils.data import DataLoader

class YoloDataset(BaseDataset):
    """ Dataset in order to train a Yolo Detection Model.

    This dataset has some specificities, it returns :
    - Images
    - Target [B,max_bbox_per_image,5] => [cls_id,xc,yc,w,h]
    - Images_names

    This dataset has it's own collate function that pad target and stack images.

    Args:
        BaseDataset (_type_): _description_

    """
    max_bbox_per_image = 50
    clsNames = None
    mixup_enabled=True
    mosaic_enabled=True
    
    def __init__(self,pprocess:PPROCESS=PPROCESS.NORMALIZE,size:tuple=(128,128)):
        BaseDataset.__init__(self,pprocess,size)
        self.clsNames = []
        for s in size:
            if s%32:
                raise SizeError('Each size should be a multiple of 32')
        self.max_bbox_per_image = 50
        # We override transformation because detection is specific.
        self.train_transform=A.Compose([
            A.Resize(size[0],size[1]),
            A.Lambda(name='pprocess',image=self.pprocess_transform),
            ToTensorV2()
        ],
        bbox_params=A.BboxParams(format='yolo',label_fields=['class_labels']))
        # Val Transform
        self.val_transform=A.Compose([
            A.Resize(size[0],size[1]),
            A.Lambda(name='pprocess',image=self.pprocess_transform),
            ToTensorV2()
        ],
        bbox_params=A.BboxParams(format='yolo',label_fields=['class_labels']))
        self.transform = self.train_transform

    def dict(self):
        config = super().dict()
        config['clsNames']=self.clsNames
        return config

    @property
    def clsCount(self):
        return len(self.clsNames) # We remove the Background class
    
    def __getitem__(self,idx):
        indice = idx%self.__len__()
        ImageInstance = self.data[indice]
        ImageInstance:YoloImage
        X = ImageInstance.get_data()
        bboxes,class_labels = ImageInstance.get_target(self.clsNames)
        if self.transform:
            # We add datasets and train indices for data_aug.
            indices = self.train_balanced_indices if self._isbalanced else self.train_indices
            output = self.transform(image=X,bboxes=bboxes,class_labels=class_labels,dataset=self,indices=list(indices))
            X = output['image']
            bboxes = output['bboxes']
            class_labels = output['class_labels']
        X:torch.Tensor
        return X.float(),bboxes,class_labels,ImageInstance.name

    def get_classes(self,idx):
        """Returns the class ID for the instance idx

        Args:
            idx (_type_): _description_

        Returns:
            _type_: _description_
        """
        indice = idx%self.__len__()
        ImageInstance = self.data[indice]
        ImageInstance:YoloImage
        return [self.clsNames.index(clsName) for clsName in ImageInstance.clsNames]

    def get_dataloader(self, name: str, batch_size: int = 4, num_workers: int = 4, shuffle: bool = True, epoch: int = 0) -> DataLoader:
        # override the get_dataloader to use the right collate_fn
        def yolo_collate_fn(batch,nmax:int=self.max_bbox_per_image):
            """Collate function that returns the image and target for yolo dataset.

            Args:
                batch (_type_): _description_
                nmax (int, optional): _description_. Defaults to 50.

            Returns:
                _type_: _description_
            """
            images=[]
            targets=[]
            img_ids=[]
            for image,bboxes,class_ids,img_id in batch:
                # We stack image
                target = torch.zeros((nmax,5))
                for i,(bbox,cls_id) in enumerate(zip(bboxes,class_ids)):
                    if i<nmax:
                        target[i,:]=torch.tensor((cls_id,*bbox)) # We create a tensor from [class,xc,yc,w,h]
                    else:
                        break
                targets.append(target.unsqueeze(0))
                images.append(image.unsqueeze(0))
                img_ids.append(img_id)
            images = torch.concat(images,dim=0) # We concatenate on the batch dimension.
            targets=torch.concat(targets,dim=0)
            return images,targets,img_ids
        return super().get_dataloader(name, batch_size, num_workers, shuffle, epoch, yolo_collate_fn)

    def display(self, idx):
        X_torch,bboxes,classes,_ = self[idx]
        # We unsqueeze to fit with transform reverse...
        X_np = ImageHelper.transform_reverse(X_torch.unsqueeze(0),self.pprocess).squeeze(0)
        return ImageHelper.draw_bboxes(X_np,bboxes,classes,bboxes_type=BBOX_TYPE.CCWH_REL)

    def fromCoco(image_dir:str,
                 train_annotation_json:str,
                 val_annotation_json:str,
                 pprocess:PPROCESS=PPROCESS.NORMALIZE,
                 size:tuple=(128,128),
                 nmax:int = None)->'YoloDataset':
        assert os.path.exists(image_dir),f"image_directory {image_dir} should exist"
        assert os.path.exists(train_annotation_json),f"train_annotation_json {train_annotation_json} should exist"
        assert os.path.exists(val_annotation_json),f"val_annotation_json {val_annotation_json} should exist"
        dataset = YoloDataset(pprocess,size)
        dataset.data = []
        
        #######################
        ## Reference set of data...
        #######################
        def reference_set(coco_set,name:str='set'):
            """This method reference a set of data and break to nmax.

            Args:
                coco_set (_type_): _description_
                name (str, optional): _description_. Defaults to 'set'.

            Returns:
                _type_: _description_
            """
            start = len(dataset)
            for i,instance in tqdm(enumerate(coco_set),total=len(coco_set),desc=f'Referencing {name}...'):
                image_path = os.path.join(image_dir,instance['file_name'])
                ######################################
                ##  Debug only
                if name=='train' and 0:
                    indice = list(coco_set.images_dict.keys()).index(int('000000200365'))
                    instance=coco_set[indice]
                    image_path = os.path.join(image_dir,instance['file_name'])
                ###########################################
                instance_yolo = YoloImage(os.path.basename(image_path),image_path,instance['annotations'],bbox_type = BBOX_TYPE.XYWH_ABS)
                # bug with image size sometime...
                instance_yolo.size=(instance['height'],instance['width'])
                # For every classes, add it to the dataset if if do not exists...
                for cls in instance_yolo.get_classes():
                    if cls not in dataset.clsNames:
                        dataset.clsNames.append(cls)
                dataset.data.append(instance_yolo)  
                if nmax is not None:
                    if i>nmax:
                        break
            # we return indices corresponding to the set.
            return np.arange(start,start + i)
    
        ## Processing referencing...
        train_set = CocoAnnotationFile(train_annotation_json,progress_bar=True)
        dataset.train_indices=reference_set(train_set,'train')
        val_set = CocoAnnotationFile(val_annotation_json,progress_bar=True)
        dataset.val_indices=reference_set(val_set,'validation')
        dataset._issplited=True
        return dataset

    def fromYarrows(data_root_dir:str,
                   label_dir:str,
                   pprocess:PPROCESS=PPROCESS.NORMALIZE,
                   size:tuple=(128,128),
                   nmax:int=None)->'YoloDataset':
        assert os.path.exists(data_root_dir),f'data_root_dir {data_root_dir} should be an existing directory'
        assert os.path.exists(label_dir),f'data_root_dir {label_dir} should be an existing directory'
        dataset = YoloDataset(pprocess,size)
        dataset.data=[]
        yarrow_paths = [os.path.join(label_dir,y) for y in os.listdir(label_dir)]
        if nmax is not None:
            yarrow_paths=yarrow_paths[:nmax]
        for yarrow_path in tqdm(yarrow_paths):
            yar_obj = YarrowDataset.parse_file(yarrow_path)
            image_paths = [os.path.join(data_root_dir,i.file_name) for i in yar_obj.images]
            instance_yolo = YoloImage(
                name=os.path.basename(yarrow_path),
                img_paths=image_paths,
                annotations=yar_obj.annotations,
                bbox_type = BBOX_TYPE.XYXY_REL)
            for cls in instance_yolo.get_classes():
                    if cls not in dataset.clsNames:
                        dataset.clsNames.append(cls)
            dataset.data.append(instance_yolo)
        return dataset



class YoloImage(BaseImage):
    def __init__(self,name:str,img_paths:Union[str,List[str]],annotations:List[Annotation],bbox_type:BBOX_TYPE=BBOX_TYPE.XYXY_REL):
        assert isinstance(bbox_type,BBOX_TYPE),"bbox_type should be a BBOX_TYPE Enum"
        # We get the name from image name.
        self.name = name
        self.annotations = annotations
        self.img_paths = img_paths
        self.bbox_type=bbox_type
        self.clsNames = list(set([a.name for a in annotations]))
        self.size = None # size HxW

    def get_size(self):
        """It the size is not set get it.
        """
        if self.size is None:
            with ImageHelper.open_image(self.img_paths) as np_img:
                self.size = np_img.shape[:2]
        return self.size

    def get_data(self):
        np_image = ImageHelper.open_image(self.img_paths)
        if self.size is None:
            self.size = np_image.shape[:2] # We get the 2 first dim of the np_image
        return np_image

    def get_classes(self):
        return self.clsNames

    def get_target(self,clsNames:List[str]):
        """Get the target for the image, it will return a matrix [max_labels,5]

        Each label consists of [xc,yc,w,h] and class_id
        class (float) : class index
        xc,yc (float) : center of the bbox [0-1]
        w,h   (float) : size of the bbox, value between 0 and 1
        Args:
            clsNames(List[str]) : list of class labels...
        Returns:
            bboxes: List[[xc,yc,w,h]]
            class_labels: List[cls_id]
        """
        bboxes = []
        class_labels = []
        for i,annotation in enumerate(self.annotations):
            annotation:Annotation
            cls_id=clsNames.index(annotation.name)
            # We transform the datarow to ccwh.
            src_bboxes = np.array(annotation.bbox)
            if self.bbox_type==BBOX_TYPE.XYXY_REL:
                bbox_ccwh_rel = BboxHelper.convert(src_bboxes,BBOX_TYPE.XYXY_REL,BBOX_TYPE.CCWH_REL)
                bbox_ccwh_rel:np.ndarray
            elif self.bbox_type==BBOX_TYPE.XYWH_ABS:
                size = self.get_size()
                bbox_ccwh_rel = BboxHelper.convert(src_bboxes,BBOX_TYPE.XYWH_ABS,BBOX_TYPE.CCWH_REL,size[0],size[1])
                bbox_ccwh_rel:np.ndarray
            if BboxHelper.bboxes_check_yolo(bbox_ccwh_rel):
                # We check if the YoloFormat is respected (bbox_coords >0 and <=1)
                bboxes.append(bbox_ccwh_rel.tolist())
                class_labels.append(cls_id)
        return bboxes,class_labels