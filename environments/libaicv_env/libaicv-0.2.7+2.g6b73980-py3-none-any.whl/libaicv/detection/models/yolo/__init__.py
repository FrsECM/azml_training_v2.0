# This implementation have been taken from here 19/02/2023
# https://github.com/Megvii-BaseDetection/
# the license, at this time, is Apache 2 LICENSE

