#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# Copyright (c) Megvii Inc. All rights reserved.
# Modified by francois.ponchon@michelin.com


import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from logging import Logger
from ...losses import IoUlossBBox
from .network_blocks import BaseConv, DWConv
from ...utils.yolo_utils import decode_outputs,get_yolo_losses
from typing import List

#!/usr/bin/env python3
# -*- coding:utf-8 -*-




class YOLOXHead(nn.Module):
    """The YoloXHead is just after the YoloBackbone.
    The backbone has multiple outputs with differents strides
    The strides are corresponding to the reduction of resolution compared to the original image...
    eg : stride 32 => spatial resolution /32.

    For each of theses stride we have :
    - A different in_channel count
    - 1 cls_preds head => Predict C classes for each "cell"
    - 1 reg_preds head => Predict 4 coordinates for the bbox in this "cell"
    - 1 obj_preds head => Predict 1 value 
    Args:
        nn (_type_): _description_
    """
    def __init__(
        self,
        num_classes,
        width=1.0, # Necessary to be able to init the right Yolo...
        strides=[8, 16, 32],
        in_channels=[256, 512, 1024],
        act="silu",
        depthwise=False,
    ):
        """
        Args:
            act (str): activation type of conv. Defalut value: "silu".
            depthwise (bool): whether apply depthwise conv in conv branch. Defalut value: False.
        """
        super().__init__()
        self.num_head=len(in_channels) # In order to access it from trainer.
        self.num_classes = num_classes
        self.decode_in_inference = True  # for deploy, set to False

        self.cls_convs = nn.ModuleList()
        self.reg_convs = nn.ModuleList()
        self.cls_preds = nn.ModuleList()
        self.reg_preds = nn.ModuleList()
        self.obj_preds = nn.ModuleList()
        self.stems = nn.ModuleList()
        Conv = DWConv if depthwise else BaseConv

        for i in range(self.num_head):
            self.stems.append(
                BaseConv(
                    in_channels=int(in_channels[i] * width),
                    out_channels=int(256 * width),
                    ksize=1,
                    stride=1,
                    act=act,
                )
            )
            self.cls_convs.append(
                nn.Sequential(
                    *[
                        Conv(
                            in_channels=int(256 * width),
                            out_channels=int(256 * width),
                            ksize=3,
                            stride=1,
                            act=act,
                        ),
                        Conv(
                            in_channels=int(256 * width),
                            out_channels=int(256 * width),
                            ksize=3,
                            stride=1,
                            act=act,
                        ),
                    ]
                )
            )
            self.reg_convs.append(
                nn.Sequential(
                    *[
                        Conv(
                            in_channels=int(256 * width),
                            out_channels=int(256 * width),
                            ksize=3,
                            stride=1,
                            act=act,
                        ),
                        Conv(
                            in_channels=int(256 * width),
                            out_channels=int(256 * width),
                            ksize=3,
                            stride=1,
                            act=act,
                        ),
                    ]
                )
            )
            self.cls_preds.append(
                nn.Conv2d(
                    in_channels=int(256 * width),
                    out_channels=self.num_classes,
                    kernel_size=1,
                    stride=1,
                    padding=0,
                )
            )
            self.reg_preds.append(
                nn.Conv2d(
                    in_channels=int(256 * width),
                    out_channels=4,
                    kernel_size=1,
                    stride=1,
                    padding=0,
                )
            )
            self.obj_preds.append(
                nn.Conv2d(
                    in_channels=int(256 * width),
                    out_channels=1,
                    kernel_size=1,
                    stride=1,
                    padding=0,
                )
            )

        self.use_l1 = True
        self.strides = strides

    def initialize_HeadWeights(self, prior_prob_obj=1e-2,prior_prob_cls=1e-2): 
        # Like here :
        # https://pytorch.org/docs/stable/nn.init.html
        for conv in self.cls_preds:
            conv:nn.Conv2d
            b = conv.bias.view(1, -1)
            b.data.fill_(-math.log((1 - prior_prob_cls) / prior_prob_cls))
            conv.bias = torch.nn.Parameter(b.view(-1), requires_grad=True)
            # We initialize like that :
            torch.nn.init.xavier_uniform_(conv.weight.data)

        for conv in self.obj_preds:
            b = conv.bias.view(1, -1)
            b.data.fill_(-math.log((1 - prior_prob_obj) / prior_prob_obj))
            conv.bias = torch.nn.Parameter(b.view(-1), requires_grad=True)
            torch.nn.init.xavier_uniform_(conv.weight.data)

    def forward_inference(self,xin):
        outputs=self.forward(xin) 
        if self.decode_in_inference:
            outputs,_,_,_=decode_outputs(outputs,model_strides=self.strides)
            return outputs
        else:
            return outputs

    def forward_training(self,xin,labels):   
        outputs=self.forward(xin)
        loss = get_yolo_losses(outputs,self.strides,labels,use_l1=self.use_l1)
        return loss

    def forward(self, xin):
        outputs = []
        for k, x in enumerate(xin):
            # We iterate over the different strides (resolutions) of the FPN.
            ################################
            ## We forward into our head...
            ################################
            x = self.stems[k](x)
            cls_x = x
            reg_x = x
            cls_feat = self.cls_convs[k](cls_x)
            cls_output = self.cls_preds[k](cls_feat)
            reg_feat = self.reg_convs[k](reg_x)
            reg_output = self.reg_preds[k](reg_feat)
            obj_output = self.obj_preds[k](reg_feat)
            # If in inference, we concat output but perform sigmoid operation on obj and cls
            output = torch.cat([reg_output, obj_output, cls_output], 1)
            outputs.append(output)
        return outputs