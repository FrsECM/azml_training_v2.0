#!/usr/bin/env python3
# -*- coding:utf-8 -*-
# Copyright (c) Megvii Inc. All rights reserved.
# Modified by francois.ponchon@michelin.com
# => Add comment to explain the behavior
# => Uniformize the notation in forward to reduce the zip size...
# => Remove the view for output in get_output_and_grid
# => Remove the imgs in "get_losses" function because not used...
# => Rename mode => Device in get assignment...
# => Remove the slices in get_geometry_constraint as there are useless
# => Precise if stride/shifts are concatenated or not in naming
# => Create a num_head attribute
# => Remove cpu assignments
# => rename gt_class_per_image in get_assigment

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from logging import Logger
from ...losses import IoUlossBBox
from .network_blocks import BaseConv, DWConv
from ...utils.yolo_utils import decode_outputs,get_yolo_losses
from typing import List

#!/usr/bin/env python3
# -*- coding:utf-8 -*-

_TORCH_VER = [int(x) for x in torch.__version__.split(".")[:2]]
def meshgrid(*tensors):
    if _TORCH_VER >= [1, 10]:
        return torch.meshgrid(*tensors, indexing="ij")
    else:
        return torch.meshgrid(*tensors)


class YOLOXHead(nn.Module):
    """The YoloXHead is just after the YoloBackbone.
    The backbone has multiple outputs with differents strides
    The strides are corresponding to the reduction of resolution compared to the original image...
    eg : stride 32 => spatial resolution /32.

    For each of theses stride we have :
    - A different in_channel count
    - 1 cls_preds head => Predict C classes for each "cell"
    - 1 reg_preds head => Predict 4 coordinates for the bbox in this "cell"
    - 1 obj_preds head => Predict 1 value 
    Args:
        nn (_type_): _description_
    """
    def __init__(
        self,
        num_classes,
        width=1.0, # Necessary to be able to init the right Yolo...
        strides=[8, 16, 32],
        in_channels=[256, 512, 1024],
        act="silu",
        depthwise=False,
    ):
        """
        Args:
            act (str): activation type of conv. Defalut value: "silu".
            depthwise (bool): whether apply depthwise conv in conv branch. Defalut value: False.
        """
        super().__init__()
        self.num_head=len(in_channels) # In order to access it from trainer.
        self.num_classes = num_classes
        self.decode_in_inference = True  # for deploy, set to False

        self.cls_convs = nn.ModuleList()
        self.reg_convs = nn.ModuleList()
        self.cls_preds = nn.ModuleList()
        self.reg_preds = nn.ModuleList()
        self.obj_preds = nn.ModuleList()
        self.stems = nn.ModuleList()
        Conv = DWConv if depthwise else BaseConv

        for i in range(self.num_head):
            self.stems.append(
                BaseConv(
                    in_channels=int(in_channels[i] * width),
                    out_channels=int(256 * width),
                    ksize=1,
                    stride=1,
                    act=act,
                )
            )
            self.cls_convs.append(
                nn.Sequential(
                    *[
                        Conv(
                            in_channels=int(256 * width),
                            out_channels=int(256 * width),
                            ksize=3,
                            stride=1,
                            act=act,
                        ),
                        Conv(
                            in_channels=int(256 * width),
                            out_channels=int(256 * width),
                            ksize=3,
                            stride=1,
                            act=act,
                        ),
                    ]
                )
            )
            self.reg_convs.append(
                nn.Sequential(
                    *[
                        Conv(
                            in_channels=int(256 * width),
                            out_channels=int(256 * width),
                            ksize=3,
                            stride=1,
                            act=act,
                        ),
                        Conv(
                            in_channels=int(256 * width),
                            out_channels=int(256 * width),
                            ksize=3,
                            stride=1,
                            act=act,
                        ),
                    ]
                )
            )
            self.cls_preds.append(
                nn.Conv2d(
                    in_channels=int(256 * width),
                    out_channels=self.num_classes,
                    kernel_size=1,
                    stride=1,
                    padding=0,
                )
            )
            self.reg_preds.append(
                nn.Conv2d(
                    in_channels=int(256 * width),
                    out_channels=4,
                    kernel_size=1,
                    stride=1,
                    padding=0,
                )
            )
            self.obj_preds.append(
                nn.Conv2d(
                    in_channels=int(256 * width),
                    out_channels=1,
                    kernel_size=1,
                    stride=1,
                    padding=0,
                )
            )

        self.use_l1 = True
        self.l1_loss = nn.L1Loss(reduction="none")
        self.bcewithlog_loss = nn.BCEWithLogitsLoss(reduction="none")
        self.iou_loss = IoUlossBBox(reduction="none")
        self.strides = strides
        self.grids = [torch.zeros(1)] * self.num_head

    def initialize_biases(self, prior_prob):
        for conv in self.cls_preds:
            b = conv.bias.view(1, -1)
            b.data.fill_(-math.log((1 - prior_prob) / prior_prob))
            conv.bias = torch.nn.Parameter(b.view(-1), requires_grad=True)

        for conv in self.obj_preds:
            b = conv.bias.view(1, -1)
            b.data.fill_(-math.log((1 - prior_prob) / prior_prob))
            conv.bias = torch.nn.Parameter(b.view(-1), requires_grad=True)

    def forward_training(self,xin,labels):
        outputs = []
        origin_preds = [] # L1 loss only
        x_shifts = []
        y_shifts = []
        expanded_strides = []
        for k, (stride_this_level, x) in enumerate(zip(self.strides, xin)):
            # We iterate over the different strides (resolutions) of the FPN.
            ################################
            ## We forward into our head...
            ################################
            x = self.stems[k](x)
            cls_x = x
            reg_x = x

            cls_feat = self.cls_convs[k](cls_x)
            cls_output = self.cls_preds[k](cls_feat)
            reg_feat = self.reg_convs[k](reg_x)
            reg_output = self.reg_preds[k](reg_feat)
            obj_output = self.obj_preds[k](reg_feat)
            #################################
            ### Training only
            #################################
            # We concatenate the result on axis 1, on order to have a [B,4+1+C,H,W] output on axis 1
            output = torch.cat([reg_output, obj_output, cls_output], 1)
            output, grid = self.get_output_and_grid(
                output, k, stride_this_level, xin[0].type()
            )
            # We aggregates Xs,Ys and Stride for all of our items.
            # We create matrix size [1,Hs*Ws,2] to store stride coefficient....
            x_shifts.append(grid[:, :, 0])
            y_shifts.append(grid[:, :, 1])
            expanded_strides.append(
                torch.zeros(1, grid.shape[1])
                .fill_(stride_this_level)
                .type_as(xin[0])
            )
            if self.use_l1:
                # If we use the L1 loss
                # => We keep track of the original regression output for this stride...
                batch_size = reg_output.shape[0]
                reg_output = reg_output.permute(0, 2, 3, 1).reshape(batch_size, -1, 4) # => [B,Hs*Ws,4]
                origin_preds.append(reg_output.clone())
            outputs.append(output)
        ##### ENDLOOP
        loss = self.get_losses(
            x_shifts,
            y_shifts,
            expanded_strides,
            labels,
            torch.cat(outputs, 1),  # We concatenate output on dimension 1 !
            origin_preds,
            dtype=xin[0].dtype,
        )
        return loss

    def forward_inference(self,xin):
        outputs = []
        for k, x in enumerate(xin):
            # We iterate over the different strides (resolutions) of the FPN.
            ################################
            ## We forward into our head...
            ################################
            x = self.stems[k](x)
            cls_x = x
            reg_x = x
            cls_feat = self.cls_convs[k](cls_x)
            cls_output = self.cls_preds[k](cls_feat)
            reg_feat = self.reg_convs[k](reg_x)
            reg_output = self.reg_preds[k](reg_feat)
            obj_output = self.obj_preds[k](reg_feat)
            # If in inference, we concat output but perform sigmoid operation on obj and cls
            output = torch.cat([reg_output, obj_output, cls_output], 1)
            outputs.append(output)     
        if self.decode_in_inference:
            return self.decode_outputs(outputs,model_strides=self.strides,dtype=xin[0].type())
        else:
            return outputs

    def forward(self, xin, labels=None):
        if self.training:
            return self.forward_training(xin,labels)
        else:
            return self.forward_inference(xin)

    ##########################################################################################################
    ### Methods for decoding...
    ##########################################################################################################

    def get_output_and_grid(self, output:torch.Tensor, k:int, stride:int, dtype):
        """ Get the output and the gird alligned on a share meshgrid.
        
        Args:
            output (torch.Tensor): [B,5+C,Hs,Ws] tensor
            k (int): indice of the head
            stride (int): stride (resolution reduction since original image - s in Hs)
            dtype (_type_): type of x_in

        Returns:
            output(torch.Tensor): [B,Hs*Ws,5+C] with 4 first of last dimension corresponding to y_c,x_c,W_org,H_org
            grid(torch.Tensor): [1,Hs*Ws,2]  corresponding to the y,x indices in  [0-Hs], [0-Ws]
        """
        # We get the grid for the stride/resolution.
        # This grid was initialized in our constructor.
        grid = self.grids[k]

        batch_size = output.shape[0]
        n_ch = 5 + self.num_classes
        hsize, wsize = output.shape[-2:]
        # We check size of the meshgrid, if it's coherent, we keep it, else we recreate it.
        if grid.shape[-3:-1] != output.shape[-2:]: # if grid is not the same shape than output, recompute it...
            # Meshgrid create matrix with coordinates for each cells on Y and X axis
            # we stack it and name it "grid"...
            yv, xv = meshgrid([torch.arange(hsize), torch.arange(wsize)])
            grid = torch.stack((xv, yv), 2).type(dtype) # [Hs,Ws,2]
            self.grids[k] = grid

        # We reshape/permute the output, with the channel in last and flatten it for each batch
        output = output.permute(0, 2, 3, 1).reshape(batch_size, hsize * wsize, -1) # [B,5+C,Hs,Ws] => [B,Hs,Ws,5+C] => [B,Hs*Ws,5+C]
        # we flatten the grid... We keep y and x coordinate as 2 values in the end.
        grid = grid.view(1, -1, 2) # [1,Hs*Ws,2]
        # We modify the predicted y_c,x_c coordinates to fit the real image size.
        # For that we add the grid coordinate and multiply by the stride
        # the output is a value between 0-1 to adjust the center of the bbox inside the "cell"
        output[..., :2] = (output[..., :2] + grid) * stride
        # Note : It could be interesting to try the behavior this way :
        # output[..., :2] = output[..., :2] + (grid * stride)
        # This way, the output wouldn't be translated allong it's axis with a stride factor.
        # for the moment, the same object on the left and on the right of the image don't have the same output.
        # with spacial invariance of convolution it can cause problem
        
        # We multiply the exponential(predicted bbox w/h) size by the stride.
        # it's coherent with yolo implementation.
        output[..., 2:4] = torch.exp(output[..., 2:4]) * stride
        return output, grid

    def decode_outputs(self,outputs:List[torch.Tensor], model_strides:List[int],dtype):
        """Decode outputs of the Yolo model during inference.

        Args:
            outputs (List[torch.Tensor]): [B,Depth,Hs,Ws] tensor
            model_strides (List[int]): default = [8,16,32]
            dtype (_type_): dtype of the input

        Returns:
            outputs: [N,n_total_cells,5+C] All predictions from the model.
        """
        grids = []
        strides = []
        hw =  [x.shape[-2:] for x in outputs]
        for (hsize, wsize), stride in zip(hw, model_strides):
            yv, xv = torch.meshgrid([torch.arange(hsize), torch.arange(wsize)],indexing='ij')
            grid = torch.stack((xv, yv), 2).view(1, -1, 2)
            grids.append(grid)
            shape = grid.shape[:2]
            strides.append(torch.full((*shape, 1), stride))
        # Now, we'll flatten everything in order to be [B,n_total_cells,5+C]
        outputs = torch.cat(
                    [x.flatten(start_dim=2) for x in outputs], dim=2
                ).permute(0, 2, 1)
        grids = torch.cat(grids, dim=1).type(dtype)
        strides = torch.cat(strides, dim=1).type(dtype)
        # We finally compute real outputs coordinates on the grid.
        outputs = torch.cat([
            (outputs[..., 0:2] + grids) * strides,
            torch.exp(outputs[..., 2:4]) * strides,
            torch.sigmoid(outputs[..., 4:]) # [FPO] We compute here the sigmoid for classes and objectness...
        ], dim=-1)
        # Then we return outputs
        return outputs

    def get_losses(
        self,
        x_shifts,
        y_shifts,
        expanded_strides,
        labels,
        outputs,
        origin_preds,
        dtype,
    ):
        """_summary_

        Args:
            x_shifts (List[torch.Tensor]): indexes on the X axis (Meshgrid for each stride) Each [B,Hs*Ws]
            y_shifts (List[torch.Tensor]): indexes on the Y axis (Meshgrid for each stride) Each [B,Hs*Ws]
            expanded_strides (List[torch.Tensor]): strides values default=[8,16,32] Each [B,Hs*Ws]
            labels (_type_): Annotations matrix [B,n_max,5] 5 => cls_id,xc,yc,w,h
            outputs (torch.Tensor): Model outputs [B,sum(Hs*Ws) for strides],5+C]
            origin_preds (list): [[B,Hs*Ws,4]*n_stride]
            dtype (_type_): type of the input/output...

        Returns:
            TotalLoss   : torch.tensor
            IoULoss     : torch.tensor
            loss_obj    : torch.tensor
            loss_cls    : torch.tensor
            loss_l1     : torch.tensor
            num_fg / max(num_gts, 1), num_detection / num_gts (or 1)
        """
        # We get different outputs types...
        bbox_preds = outputs[:, :, :4]  # [batch, n_anchors_all, 4]
        obj_preds = outputs[:, :, 4:5]  # [batch, n_anchors_all, 1]
        cls_preds = outputs[:, :, 5:]  # [batch, n_anchors_all, n_cls]
        # calculate targets
        # Les labels sont sous forme de matrices [B,nMax,5] = [cls_id,xc,yc,w,h]* nMax labels
        # sum(dim=2) > 0    => Est ce qu'on a un label sur la ligne...
        # sum(dim=1)        => Combien il y'a de labels...
        # nlabel = [B] (int)
        nlabel = (labels.sum(dim=2) > 0).sum(dim=1)  # number of objects per batch

        # It's not really necessary in the case of YoloX as we no longer have anchors...
        # We'll keep for the moment in order to be sure there is no impact...
        total_num_anchors = outputs.shape[1]
        x_shifts_concat = torch.cat(x_shifts, 1)  # [1, n_anchors_all]
        y_shifts_concat = torch.cat(y_shifts, 1)  # [1, n_anchors_all]
        expanded_strides_concat = torch.cat(expanded_strides, 1)
        if self.use_l1:
            origin_preds = torch.cat(origin_preds, 1)

        # We initialize a lot of parameters....
        cls_targets = []
        reg_targets = []
        l1_targets = []
        obj_targets = []
        fg_masks = []

        num_fg = 0.0
        num_gts = 0.0

        for batch_idx in range(outputs.shape[0]):
            # We process every batch separately...
            num_gt = int(nlabel[batch_idx]) # We get the number of labels for this batch_id...
            num_gts += num_gt
            if num_gt == 0:
                # We don't have gt then we say the model => Predicts Zeros everywhere !
                cls_target = outputs.new_zeros((0, self.num_classes))
                reg_target = outputs.new_zeros((0, 4))
                l1_target = outputs.new_zeros((0, 4))
                obj_target = outputs.new_zeros((total_num_anchors, 1))
                fg_mask = outputs.new_zeros(total_num_anchors).bool()
            else:
                # We have a groundtruth available.
                gt_bboxes_per_image = labels[batch_idx, :num_gt, 1:5]   # we get bboxes 
                gt_classes_per_image = labels[batch_idx, :num_gt, 0]              # we get class ids
                bboxes_preds_per_image = bbox_preds[batch_idx]          # We get bboxes predicted for this image...
                (
                    gt_matched_classes,
                    fg_mask,
                    pred_ious_this_matching,
                    matched_gt_inds,
                    num_fg_img,
                ) = self.get_assignments(  # noqa
                    batch_idx,
                    num_gt,
                    gt_bboxes_per_image,
                    gt_classes_per_image,
                    bboxes_preds_per_image,
                    x_shifts_concat,
                    y_shifts_concat,
                    expanded_strides_concat,
                    cls_preds,
                    obj_preds,
                )
                torch.cuda.empty_cache()
                num_fg += num_fg_img
                cls_target = F.one_hot(
                    gt_matched_classes.to(torch.int64), self.num_classes
                ) * pred_ious_this_matching.unsqueeze(-1)
                obj_target = fg_mask.unsqueeze(-1)
                reg_target = gt_bboxes_per_image[matched_gt_inds]
                if self.use_l1:
                    l1_target = self.get_l1_target(
                        outputs.new_zeros((num_fg_img, 4)),
                        gt_bboxes_per_image[matched_gt_inds],
                        expanded_strides_concat=expanded_strides_concat[0][fg_mask],
                        x_shifts_concat=x_shifts_concat[0][fg_mask],
                        y_shifts_concat=y_shifts_concat[0][fg_mask],
                    )

            cls_targets.append(cls_target)
            reg_targets.append(reg_target)
            obj_targets.append(obj_target.to(dtype))
            fg_masks.append(fg_mask)
            if self.use_l1:
                l1_targets.append(l1_target)

        cls_targets = torch.cat(cls_targets, 0)
        reg_targets = torch.cat(reg_targets, 0)
        obj_targets = torch.cat(obj_targets, 0)
        fg_masks = torch.cat(fg_masks, 0)
        if self.use_l1:
            l1_targets = torch.cat(l1_targets, 0)

        num_fg = max(num_fg, 1)
        ###################################################################
        #### Compute IoU Loss
        ###################################################################
        loss_iou = (
            self.iou_loss(bbox_preds.view(-1, 4)[fg_masks], reg_targets)
        ).sum() / num_fg
        ###################################################################
        #### Compute Objectness Loss
        ###################################################################
        loss_obj = (
            self.bcewithlog_loss(obj_preds.view(-1, 1), obj_targets)
        ).sum() / num_fg
        ###################################################################
        #### Compute Classiification Loss
        ###################################################################

        loss_cls = (
            self.bcewithlog_loss(
                cls_preds.view(-1, self.num_classes)[fg_masks], cls_targets
            )
        ).sum() / num_fg
        ###################################################################
        #### Compute Regression Loss
        ###################################################################
        if self.use_l1:
            loss_l1 = (
                self.l1_loss(origin_preds.view(-1, 4)[fg_masks], l1_targets)
            ).sum() / num_fg
        else:
            loss_l1 = 0.0

        reg_weight = 5.0
        loss = reg_weight * loss_iou + loss_obj + loss_cls + loss_l1

        return (
            loss,
            reg_weight * loss_iou,
            loss_obj,
            loss_cls,
            loss_l1,
            num_fg / max(num_gts, 1),
        )

    def get_l1_target(self, l1_target, gt, expanded_strides_concat, x_shifts_concat, y_shifts_concat, eps=1e-8):
        l1_target[:, 0] = gt[:, 0] / expanded_strides_concat - x_shifts_concat
        l1_target[:, 1] = gt[:, 1] / expanded_strides_concat - y_shifts_concat
        l1_target[:, 2] = torch.log(gt[:, 2] / expanded_strides_concat + eps)
        l1_target[:, 3] = torch.log(gt[:, 3] / expanded_strides_concat + eps)
        return l1_target

    @torch.no_grad()
    def get_assignments(
        self,
        batch_idx,
        num_gt,
        gt_bboxes_per_image,
        gt_classes_per_image,
        bboxes_preds_per_image,
        x_shifts_concat,
        y_shifts_concat,
        expanded_strides_concat,
        cls_preds,
        obj_preds
    ):
        """Get the assignment for each labels to the output of the model...

        Args:
            batch_idx (_type_): the current batch id...
            num_gt (_type_): the number of bboxes in the ground truth
            gt_bboxes_per_image (torch.Tensor - [num_gt,4]): bboxes for the image 'batch_id'
            gt_classes_per_image (torch.Tensor - [num_gt]): classes for image 'batch_id'
            bboxes_preds_per_image (torch.Tensor): bboxes predictions [sum(Hs*Ws) for strides,4]
            x_shifts_concat (torch.Tensor): indexes on the X axis (Meshgrid for each stride) Each [B,Hs*Ws,2]
            y_shifts_concat (torch.Tensor): indexes on the Y axis (Meshgrid for each stride) Each [B,Hs*Ws,2]
            expanded_strides_concat (torch.Tensor): strides values default=[8,16,32] Each [B,Hs*Ws]
            cls_preds (torch.Tensor): Cls predictions [B,sum(Hs*Ws) for strides,C]
            obj_preds (torch.Tensor): obj predictions of the model [B,sum(Hs*Ws) for strides,1]
            device (str, optional): _description_. Defaults to "gpu".

        Returns:
            gt_matched_classes      : 
            fg_mask                 :
            pred_ious_this_matching :
            matched_gt_inds         :
            num_fg                  : number of prediction keep for prediction.
        """
        #### We get geometry constraints.
        fg_mask, geometry_relation = self.get_geometry_constraint(
            gt_bboxes_per_image,
            x_shifts_concat,
            y_shifts_concat,
            expanded_strides_concat,
        )
        # We get the prediction that matches with at least one bbox for the image.
        bboxes_preds_per_image = bboxes_preds_per_image[fg_mask]
        cls_preds_ = cls_preds[batch_idx][fg_mask]
        obj_preds_ = obj_preds[batch_idx][fg_mask]
        num_in_boxes_anchor = bboxes_preds_per_image.shape[0]

        # We compute pair_wise IoU between bboxes (groundtruth, predicted...)
        pair_wise_ious = self.get_bboxes_iou(gt_bboxes_per_image, bboxes_preds_per_image, False) # size [num_gt,num_in_boxes_anchor]
        pair_wise_ious_loss = -torch.log(pair_wise_ious + 1e-8)
        # We oneHot the groundtruth classes to fit class count.
        gt_cls_per_image = (
            F.one_hot(gt_classes_per_image.to(torch.int64), self.num_classes) # size [num_gt,num_classes]
            .float()
        )
        with torch.cuda.amp.autocast(enabled=False):
            # We compute the predicted class :
            # - we multiply this class prediction by a sigmoid of objectness score.
            cls_preds_ = (
                cls_preds_.float().sigmoid_() * obj_preds_.float().sigmoid_()
            ).sqrt() # size [num_in_boxe_anchor,num_classes]
            # We compute the binary cross entropy between prediction and gt and sum it.
            pair_wise_cls_loss = F.binary_cross_entropy(
                cls_preds_.unsqueeze(0).repeat(num_gt, 1, 1),
                gt_cls_per_image.unsqueeze(1).repeat(1, num_in_boxes_anchor, 1),
                reduction="none"
            ).sum(-1) # size [num_gt,num_in_boxe_anchor]
        del cls_preds_
        # We compute a cost function for each items.
        cost = (
            pair_wise_cls_loss # Cross Entropy Loss
            + 3.0 * pair_wise_ious_loss # IoU Loss
            + float(1e6) * (~geometry_relation) # Penalize where we shouldn't get anything
        )  # size [num_gt,num_in_boxe_anchor]

        (
            num_fg,
            gt_matched_classes,
            pred_ious_this_matching,
            matched_gt_inds,
        ) = self.simota_matching(cost, pair_wise_ious, gt_classes_per_image, num_gt, fg_mask)
        del pair_wise_cls_loss, cost, pair_wise_ious, pair_wise_ious_loss

        return (
            gt_matched_classes,
            fg_mask,
            pred_ious_this_matching,
            matched_gt_inds,
            num_fg,
        )

    def get_geometry_constraint(
        self,
        gt_bboxes_per_image,
        x_shifts_concat,
        y_shifts_concat,
        expanded_strides_concat,
    ):
        """_summary_

        Calculate whether the center of an object is located in a fixed range of
        cells. 
        
        This is used to avert inappropriate matching. It can also reduce
        the number of candidate anchors so that the GPU memory is saved.


        Args:
            gt_bboxes_per_image (torch.Tensor - [num_gt,4]): bboxes for the image 'batch_id'
            x_shifts_concat (torch.Tensor): indexes on the X axis (Meshgrid for each stride) Each [B,Hs*Ws]
            y_shifts_concat (torch.Tensor): indexes on the Y axis (Meshgrid for each stride) Each [B,Hs*Ws]
            expanded_strides_concat (List[torch.Tensor]): strides values default=[8,16,32] Each [B,Hs*Ws]

        Returns:
            fg_mask => [sum(Hs*Ws)], cells that are matching with at least one bbox
            geometry_relation => [num_gt,num_matching], which gt matches with which cell
        """
        # We get centers for each cells
        # {coord}_centers_per_image => [1,sum(Hs*Ws)]
        expanded_strides_per_image = expanded_strides_concat[0]
        x_centers_per_image = ((x_shifts_concat[0] + 0.5) * expanded_strides_per_image).unsqueeze(0)
        y_centers_per_image = ((y_shifts_concat[0] + 0.5) * expanded_strides_per_image).unsqueeze(0)

        # in fixed center
        center_radius = 1.5
        center_dist = expanded_strides_per_image.unsqueeze(0) * center_radius
        # We get the distances to the circle depending on the stride.
        # gt_bboxes_per_image_i => [num_gt,1]
        gt_bboxes_per_image_l = (gt_bboxes_per_image[:, 0]).unsqueeze(-1) - center_dist
        gt_bboxes_per_image_r = (gt_bboxes_per_image[:, 0]).unsqueeze(-1) + center_dist
        gt_bboxes_per_image_t = (gt_bboxes_per_image[:, 1]).unsqueeze(-1) - center_dist
        gt_bboxes_per_image_b = (gt_bboxes_per_image[:, 1]).unsqueeze(-1) + center_dist

        # We get the distance for each center to each bbox limits...
        # c_{i} = [num_gt,sum(Hs*Ws)]
        # if a center is in the circle limits ((approximated to a rect...))
        # it's distance to the rect border is positive !
        c_l = x_centers_per_image - gt_bboxes_per_image_l
        c_r = gt_bboxes_per_image_r - x_centers_per_image
        c_t = y_centers_per_image - gt_bboxes_per_image_t
        c_b = gt_bboxes_per_image_b - y_centers_per_image
        # We stack this in a single matrix
        # center_deltas => [num_gt,sum(Hs*ws),4]
        center_deltas = torch.stack([c_l, c_t, c_r, c_b], 2)
        # We keep centers that match with the bbox...
        # is_in_centers => [num_gt,sum(Hs*Ws)]
        is_in_centers = center_deltas.min(dim=-1).values > 0.0
        # We create a filter to keep only the centers that matches with at least one bbox...
        # fg_mask => [sum(Hs*Ws)]
        fg_mask = is_in_centers.sum(dim=0) > 0
        # We create a matrix that gives for each gt matching centers
        # geometry_relation => [num_gt,num_matching]
        geometry_relation = is_in_centers[:, fg_mask]
        return fg_mask, geometry_relation

    def get_bboxes_iou(self,gt_bboxes, pred_bboxes, xyxy=True):
        """Compute the pairwise IoU between gt_bboxes and the prediction bboxes

        Args:
            gt_bboxes (_type_): groundTruth for one image [num_gt,4]
            pred_bboxes (_type_): predictions for one image []
            xyxy (bool, optional): _description_. Defaults to True.


        Returns:
            _type_: _description_
        """
        if gt_bboxes.shape[1] != 4 or pred_bboxes.shape[1] != 4:
            raise IndexError

        if xyxy:
            # In this case, bbox are in XY, XY format...
            # We get :
            # - the top left coordinates of the intersection.
            # - the bottom right coordinate of the intersection.
            tl = torch.max(gt_bboxes[:, None, :2], pred_bboxes[:, :2])
            br = torch.min(gt_bboxes[:, None, 2:], pred_bboxes[:, 2:])
            # We compute area of each bbox individually by supstrating beggining - end.
            area_a = torch.prod(gt_bboxes[:, 2:] - gt_bboxes[:, :2], 1)
            area_b = torch.prod(pred_bboxes[:, 2:] - pred_bboxes[:, :2], 1)
        else:
            # In this case, we are in CC,WH format...
            tl = torch.max(
                (gt_bboxes[:, None, :2] - gt_bboxes[:, None, 2:] / 2), # Top left bbox 1
                (pred_bboxes[:, :2] - pred_bboxes[:, 2:] / 2), # top left bbox 2
            )
            br = torch.min(
                (gt_bboxes[:, None, :2] + gt_bboxes[:, None, 2:] / 2), # bottom right bbox 1
                (pred_bboxes[:, :2] + pred_bboxes[:, 2:] / 2), # bottom right bbox 2
            )
            # The area is WxH then we compute with [2:] coordinates
            area_a = torch.prod(gt_bboxes[:, 2:], 1)
            area_b = torch.prod(pred_bboxes[:, 2:], 1)
        # We compute the area of the intersection.
        en = (tl < br).type(tl.type()).prod(dim=2)
        area_i = torch.prod(br - tl, 2) * en  # * ((tl < br).all())
        return area_i / (area_a[:, None] + area_b - area_i)

    def simota_matching(self, cost:torch.Tensor, pair_wise_ious:torch.Tensor, gt_classes_per_image, num_gt, fg_mask):
        """SimOTA matching function
        This methods returns the matches that we'll keep in order to compute the loss of our model.

        Args:
            cost (torch.Tensor): _description_
            pair_wise_ious (torch.Tensor): _description_
            gt_classes_per_image (_type_): _description_
            num_gt (_type_): _description_
            fg_mask (_type_): _description_

        Returns:
            num_fg (int): Number of anchors that are matched with one bbox \n
            gt_matched_classes [torch.tensor]: Size([num_fg]) classes of bboxes that have been matched \n
            pred_ious_this_matching [torch.tensor]: Size([num_fg]) IoU of matched anchor/bboxes \n
            matched_gt_inds [torch.tensor]: Size([num_fg]) indices of bboxes that have been matched.
        """
        # Dynamic K
        # ---------------------------------------------------------------
        # We create a matrix that has the same size than the cost matrix.
        matching_matrix = torch.zeros_like(cost, dtype=torch.uint8) # size [num_gt,num_bboxes]

        n_candidate_k = min(10, pair_wise_ious.size(1)) # we keep 10 or num_bboxes candidates.
        topk_ious, _ = torch.topk(pair_wise_ious, n_candidate_k, dim=1) # We keep the "best" candidates IoU => size [num_gt,num_candidate]
        # We sum IoU for each gt, if the sum is smaller than one, we keep only one.
        # the result is....
        # if we have no good IoU Bbox: 
        #  - we'll select only one for this gt bbox for this gt
        # else:
        #  - we'll select k bboxes for this gt
        dynamic_ks = torch.clamp(topk_ious.sum(1).int(), min=1) 
        for gt_idx in range(num_gt):
            # for each groundtruth, we'll keep k bboxes "pos_idx". We'll keep thoses with the lightest cost.
            _, pos_idx = torch.topk(
                cost[gt_idx], k=dynamic_ks[gt_idx], largest=False
            )
            matching_matrix[gt_idx][pos_idx] = 1

        del topk_ious, dynamic_ks, pos_idx

        anchor_matching_gt = matching_matrix.sum(0)
        # deal with the case that one anchor matches multiple ground-truths
        if anchor_matching_gt.max() > 1:
            # we select where we have multiple matches...
            multiple_match_mask = anchor_matching_gt > 1
            # We select the gt where the cost is "minimal"
            _, cost_argmin = torch.min(cost[:, multiple_match_mask], dim=0)
            # We remove all assignations...
            matching_matrix[:, multiple_match_mask] *= 0
            # Except the one with the minimal cost...
            matching_matrix[cost_argmin, multiple_match_mask] = 1
        # We create a mask in order to know the anchors that matches a goundtruth
        # we also count it.
        fg_mask_inboxes = anchor_matching_gt > 0
        num_fg = fg_mask_inboxes.sum().item()
        # We update te fg_mask in order to keep only anchors that matched with a bbox.
        fg_mask[fg_mask.clone()] = fg_mask_inboxes
        # we get the indices of bboxes that have been matched to a gt
        matched_gt_inds = matching_matrix[:, fg_mask_inboxes].argmax(0)
        gt_matched_classes = gt_classes_per_image[matched_gt_inds]
        # We keep only the IoUs of what have been selected.
        pred_ious_this_matching = (matching_matrix * pair_wise_ious).sum(0)[
            fg_mask_inboxes
        ]
        return num_fg, gt_matched_classes, pred_ious_this_matching, matched_gt_inds