#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# Copyright (c) Megvii Inc. All rights reserved.
# => Add ability to override Input/Output Shape...
# => Remove the x in yolohead...
import torch
import torch.nn as nn
from .yolo.yolo_pafpn import YOLOPAFPN
from .yolo.darknet import CSPDarknet
from .yolo.network_blocks import Focus
from .yolo.yolo_head import YOLOXHead
from ...core.base import BaseModel
from ..utils.yolo_utils import non_max_suppression
import copy


BACKBONES = {
    'yolox-tiny':{'width':0.375,'depth':0.33,'weights':'https://github.com/Megvii-BaseDetection/YOLOX/releases/download/0.1.1rc0/yolox_tiny.pth'},
    'yolox-s':{'width':0.50,'depth':0.33,'weights':'https://github.com/Megvii-BaseDetection/YOLOX/releases/download/0.1.1rc0/yolox_s.pth'},
    'yolox-m':{'width':0.75,'depth':0.67,'weights':'https://github.com/Megvii-BaseDetection/YOLOX/releases/download/0.1.1rc0/yolox_m.pth'},
    'yolox-l':{'width':1.00,'depth':1.00,'weights':'https://github.com/Megvii-BaseDetection/YOLOX/releases/download/0.1.1rc0/yolox_l.pth'},
    'yolox-x':{'width':1.25,'depth':1.33,'weights':'https://github.com/Megvii-BaseDetection/YOLOX/releases/download/0.1.1rc0/yolox_x.pth'}
}


class YOLOXModel(BaseModel):
    """
    YOLOX model module. The module list is defined by create_yolov3_modules function.
    The network returns loss values from three YOLO layers during training
    and detection results during test.
    """
    name="YOLOXModel"
    def __init__(self, inChannels:int=3,clsCount:int=80,backbone:str='yolox-l',pretrained:bool=False):
        super().__init__()
        assert backbone in BACKBONES,f"{backbone} not in {list(BACKBONES.keys())}"
        BConfig = BACKBONES[backbone]
        self.depth = BConfig['depth']
        self.width = BConfig['width']
        backbone = YOLOPAFPN(self.depth,self.width)
        head = YOLOXHead(80)
        self.backbone = backbone
        self.head = head
        reset=True
        if pretrained:
            reset=False
            self.load_state_dict(torch.hub.load_state_dict_from_url(BConfig['weights'],progress=True,map_location=torch.device('cpu'))["model"])
            #raise NotImplementedError('Pretrained Yolo not implemented yet => Need to download in cache.')
        ####### Change input channels if needed...
        if inChannels!=3:
            reset=True
            self.set_inChannels(inChannels)
        if clsCount!=80:
            reset=True
            self.set_clsCount(clsCount)
        self.clsCount = clsCount
        self.inChannels = inChannels
        self.strides = self.head.strides
        if reset:
            if isinstance(self.head,YOLOXHead):
                self.head.initialize_HeadWeights()
            if isinstance(self.backbone,YOLOPAFPN):
                self.backbone.init_BatchNorms()


    def set_clsCount(self,clsCount:int):
        """Replace the default clsCount with the desired one.

        This replace the last convolution of the model in order to fit the new number of classes.

        Args:
            clsCount (int): _description_
        """
        self.head:YOLOXHead
        self.head.num_classes=clsCount
        self.head.cls_preds=nn.ModuleList()
        for k in range(self.head.num_head):
            # We add an cls_preds head for each head...
            self.head.cls_preds.append(
                nn.Conv2d(
                        in_channels=int(256 * self.width),
                        out_channels=clsCount,
                        kernel_size=1,
                        stride=1,
                        padding=0
                    )
            )

    def set_inChannels(self,inChannels:int):
        """Replace the default input channels with the desired one.

        This replace the backbone input layer and repeat the green channels weights (in order to comply with pretraining when it will be implemented).

        Args:
            inChannels (int): _description_
        """
        self.backbone:YOLOPAFPN
        self.backbone.backbone:CSPDarknet
        self.backbone.backbone.stem:Focus
        # We get the weights for the green channel...
        weights_conv1=copy.deepcopy(self.backbone.backbone.stem.conv.conv.weight.data[:,1,:,:])
        # We change the convolution of the Focus of the CSP to fit with input shape.
        self.backbone.backbone.stem.conv.conv = nn.Conv2d(inChannels*4, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        for i in range(inChannels*4):
            self.backbone.backbone.stem.conv.conv.weight.data[:,i,:,:]=weights_conv1

    def forward(self, x):
        """_summary_

        Args:
            x (Tensor): Input tensor [B,C,H,W]

        Returns:
            Outputs: List[Tensor] [ [B,5+C,Hc,Wc] for each strides]
        """
        # fpn output content features of [dark3, dark4, dark5]
        fpn_outs = self.backbone(x)
        return self.head.forward(fpn_outs)

    def forward_training(self,x,targets=None):
        assert targets is not None
        fpn_outs = self.backbone(x)
        loss, iou_loss, conf_loss, cls_loss, l1_loss, num_fg = self.head.forward_training(
                fpn_outs, targets
            )
        outputs = {
                "total_loss": loss,
                "iou_loss": iou_loss,
                "l1_loss": l1_loss,
                "conf_loss": conf_loss,
                "cls_loss": cls_loss,
                "num_fg": num_fg,
            }
        return outputs
    
    def predict(self,x:torch.Tensor,nms_conf_threshold:float=0.05,nms_iou_threshold:float=0.5,nms_class_wise:bool=False):
        """Predict method is used for inference. It will perform the inference of the model + NMS

        Args:
            x (torch.Tensor): _description_
            nms_conf_threshold (float, optional): _description_. Defaults to 0.05.
            nms_iou_threshold (float, optional): _description_. Defaults to 0.5.
            nms_class_wise (bool, optional): _description_. Defaults to False.

        Returns:
            _type_: _description_
        """
        fpn_outs = self.backbone(x)
        decoded_outputs = self.head.forward_inference(fpn_outs)
        outputs = non_max_suppression(decoded_outputs,nms_conf_threshold,nms_iou_threshold,nms_class_wise)
        return outputs
        
    def forward_inference(self,x):
        fpn_outs = self.backbone(x)
        return self.head.forward_inference(fpn_outs)

class YOLOXModelOLD(BaseModel):
    """
    YOLOX model module. The module list is defined by create_yolov3_modules function.
    The network returns loss values from three YOLO layers during training
    and detection results during test.
    """
    name="YOLOXModel"

    def __init__(self, inChannels:int=3,clsCount:int=80,backbone:str='yolox-l',pretrained:bool=False):
        super().__init__()
        assert backbone in BACKBONES,f"{backbone} not in {list(BACKBONES.keys())}"
        BConfig = BACKBONES[backbone]
        self.depth = BConfig['depth']
        self.width = BConfig['width']
        backbone = YOLOPAFPN(self.depth,self.width)
        head = YOLOXHeadOld(80)
        self.backbone = backbone
        self.head = head
        if pretrained:
            self.load_state_dict(torch.hub.load_state_dict_from_url(BConfig['weights'],progress=True,map_location=torch.device('cpu'))["model"])
            #raise NotImplementedError('Pretrained Yolo not implemented yet => Need to download in cache.')
        ####### Change input channels if needed...
        if inChannels!=3:
            self.set_inChannels(inChannels)
        if clsCount!=80:
            self.set_clsCount(clsCount)
        self.clsCount = clsCount
        self.inChannels = inChannels

    def set_clsCount(self,clsCount:int):
        """Replace the default clsCount with the desired one.

        This replace the last convolution of the model in order to fit the new number of classes.

        Args:
            clsCount (int): _description_
        """
        self.head:YOLOXHeadOld
        self.head.num_classes=clsCount
        self.head.cls_preds=nn.ModuleList()
        for k in range(self.head.num_head):
            # We add an cls_preds head for each head...
            self.head.cls_preds.append(
                nn.Conv2d(
                        in_channels=int(256 * self.width),
                        out_channels=clsCount,
                        kernel_size=1,
                        stride=1,
                        padding=0,
                    )
            )

    def set_inChannels(self,inChannels:int):
        """Replace the default input channels with the desired one.

        This replace the backbone input layer and repeat the green channels weights (in order to comply with pretraining when it will be implemented).

        Args:
            inChannels (int): _description_
        """
        self.backbone:YOLOPAFPN
        self.backbone.backbone:CSPDarknet
        self.backbone.backbone.stem:Focus
        # We get the weights for the green channel...
        weights_conv1=copy.deepcopy(self.backbone.backbone.stem.conv.conv.weight.data[:,1,:,:])
        # We change the convolution of the Focus of the CSP to fit with input shape.
        self.backbone.backbone.stem.conv.conv = nn.Conv2d(inChannels*4, 64, kernel_size=(3, 3), stride=(1, 1), padding=(1, 1), bias=False)
        for i in range(inChannels*4):
            self.backbone.backbone.stem.conv.conv.weight.data[:,i,:,:]=weights_conv1

    def forward(self, x, targets=None):
        # fpn output content features of [dark3, dark4, dark5]
        fpn_outs = self.backbone(x)

        if self.training:
            assert targets is not None
            loss, iou_loss, conf_loss, cls_loss, l1_loss, num_fg = self.head(
                fpn_outs, targets
            )
            outputs = {
                "total_loss": loss,
                "iou_loss": iou_loss,
                "l1_loss": l1_loss,
                "conf_loss": conf_loss,
                "cls_loss": cls_loss,
                "num_fg": num_fg,
            }
        else:
            outputs = self.head.forward_inference(fpn_outs)
        return outputs
    