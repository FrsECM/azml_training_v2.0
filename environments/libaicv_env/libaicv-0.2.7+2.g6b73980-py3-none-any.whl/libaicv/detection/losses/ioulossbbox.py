#!/usr/bin/env python
# -*- encoding: utf-8 -*-
# Copyright (c) Megvii Inc. All rights reserved.

import torch
import torch.nn as nn
from ...core.factory import IOU_TYPE

class IoUlossBBox(nn.Module):
    def __init__(self, reduction="none", iou_type:IOU_TYPE=IOU_TYPE.COMPLETE,eps:float = 1e-16):
        super().__init__()
        self.reduction = reduction
        self.iou_type=iou_type
        self.eps = eps

    def forward(self, pred:torch.Tensor, target:torch.Tensor):
        """Compute the IoU Loss between a target and a prediction.
        Prediction and target are xc,yc,w,h (relative) like.

        Args:
            pred (torch.Tensor): [n_predictions,4]
            target (torch.Tensor): [n_bboxes,4]

        Returns:
            1 - IoU² - between bbox and target.
        """
        assert pred.shape[0] == target.shape[0]

        pred = pred.view(-1, 4)
        target = target.view(-1, 4)
        tl_intersection = torch.max(
            (pred[:, :2] - pred[:, 2:] / 2), (target[:, :2] - target[:, 2:] / 2)
        )
        br_intersection = torch.min(
            (pred[:, :2] + pred[:, 2:] / 2), (target[:, :2] + target[:, 2:] / 2)
        )
        area_p = torch.prod(pred[:, 2:], 1)
        area_g = torch.prod(target[:, 2:], 1)

        en = (tl_intersection < br_intersection).type(tl_intersection.type()).prod(dim=1)
        area_i = torch.prod(br_intersection - tl_intersection, 1) * en
        area_u = area_p + area_g - area_i
        iou = (area_i) / (area_u + self.eps)

        if self.iou_type == IOU_TYPE.STANDARD:
            loss = 1-iou
        elif self.iou_type == IOU_TYPE.SQUARED:
            loss = 1 - iou ** 2
        elif self.iou_type == IOU_TYPE.COMPLETE:
            # Like in paper :
            # https://arxiv.org/abs/1911.08287
            # We'll compute d and c (Figure 5) as dist_centers and dist_edges
            # We'll compute v
            dist_centers_squared = torch.sum((pred[:,:2]-target[:,:2])**2,dim=1)
            tl_global = torch.min(
                (pred[:, :2] - pred[:, 2:] / 2), (target[:, :2] - target[:, 2:] / 2)
            )
            br_global = torch.max(
                (pred[:, :2] + pred[:, 2:] / 2), (target[:, :2] + target[:, 2:] / 2)
            )
            dist_edges_squared = torch.sum((tl_global-br_global)**2,dim=1)
            v1 = torch.arctan(target[:,2]/(target[:,3]+self.eps))
            v2 = torch.arctan(pred[:,2]/(pred[:,3]+self.eps))
            v = (4/(torch.pi**2))*(v1 - v2)
            alpha = v/(1-iou+v)
            d_iou_loss = 1-iou + dist_centers_squared/dist_edges_squared
            # We compute the CIoU Loss
            loss = torch.where(iou<0.5,d_iou_loss,d_iou_loss+alpha*v)
        elif self.iou_type == IOU_TYPE.GLOBAL:
            c_tl = torch.min(
                (pred[:, :2] - pred[:, 2:] / 2), (target[:, :2] - target[:, 2:] / 2)
            )
            c_br = torch.max(
                (pred[:, :2] + pred[:, 2:] / 2), (target[:, :2] + target[:, 2:] / 2)
            )
            area_c = torch.prod(c_br - c_tl, 1)
            giou = iou - (area_c - area_u) / area_c.clamp(1e-16)
            loss = 1 - giou.clamp(min=-1.0, max=1.0)
        if self.reduction == "mean":
            loss = loss.mean()
        elif self.reduction == "sum":
            loss = loss.sum()
        return loss