import torch
import torch.nn as nn
from torch.nn.functional import binary_cross_entropy_with_logits

class FocalBCEWithLogitsLoss(nn.Module):
    # Inspired from paper :
    # https://arxiv.org/pdf/1708.02002.pdf
    def __init__(self,reduction='none',alpha:float=0.5,gamma:float=0,eps:float=1e-10):
        """Compute the focal cross entropy loss...

        Args:
            reduction (str, optional): _description_. Defaults to 'none'.
            alpha (float, optional): _description_. Defaults to 0.
            gamma (float, optional): _description_. Defaults to 0.
            eps (float, optional): _description_. Defaults to 1e-6.
        """
        super().__init__()
        assert reduction in  ['none','mean','sum'],f"reduction {reduction} should be in ['none','mean','sum']"
        assert alpha>=0,"Alpha should be in [0-1]"
        assert alpha<=1,"Alpha should be in [0-1]"
        self.reduction = reduction
        self.alpha = alpha
        self.gamma = gamma
        self.eps = eps
    
    def forward(self,prediction:torch.Tensor, target:torch.Tensor):
        # We clamp the prediction for stability
        p = prediction.sigmoid().clamp(self.eps,1-self.eps)
        # y=1, term :
        pos_term = target*torch.log(p)
        neg_term = (1-target)*torch.log(1-p)
        # we compute the focal BCE...
        # - We add gamma (Focal term)
        pos_focal = self.alpha*torch.pow(1-p,self.gamma)*pos_term
        neg_focal = (1-self.alpha)*torch.pow(p,self.gamma)*neg_term
        # - We add alpha (balancing term)
        # We compute the final loss
        # We add a 2 factor in order to have FCE = BCE if alpha = 0.5 and gamma = 0
        focal_bce = -2*(pos_focal+neg_focal)
        if self.reduction =='none':
            return focal_bce
        elif self.reduction=='mean':
            return focal_bce.mean()
        elif self.reduction=='sum':
            return focal_bce.sum()

if __name__=='__main__':
    target = torch.tensor([0,0.8,1])
    prediction = torch.tensor([-50,0.9,0.9])
    bce = binary_cross_entropy_with_logits(prediction,target,reduction='none')
    focal = FocalBCEWithLogitsLoss(alpha=0,gamma=0)(prediction,target)
    print('terminé !')