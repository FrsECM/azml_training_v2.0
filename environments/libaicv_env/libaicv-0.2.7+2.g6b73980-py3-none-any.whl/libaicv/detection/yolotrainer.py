import torch
from ..core.factory import REDUCTION,SCHEDULER_TYPE
from ..core.base.basetrainer import BaseTrainer,BaseHyperParams,BaseLoggingParams
from .losses import IoUlossBBox
import torch.nn as nn
from ..core.loggers import AMLTensorboardLogger
from ..core.figures import GradFlowFigure,grad_norm
import torch.distributed as dist
from . import YoloDataset
from .models import YOLOXModel
from torch.optim import SGD,Adam,RMSprop
from torchmetrics.detection.mean_ap import MeanAveragePrecision
from .utils.yolo_utils import get_yolo_losses,update_mAP,decode_outputs,non_max_suppression
from .utils.yolo_utils import YoloLossParams
import os
import json
import enum
import math



#################################################
### Arguments (pydantic for serialization)
#################################################
class YoloHyperParams(BaseHyperParams):
    grad_clip_norm=1
    grad_clip_value=10
    optim_momentum:float = 0.9
    optim_weight_decay:float = 5e-4
    nms_conf_threshold=0.05
    nms_iou_threshold=0.5
    nms_classwise=False
    lambda_l1:float = 0
    lambda_obj:float = 1.0
    lambda_negobj:float = 1.0
    lambda_iou:float = 5.0
    lambda_cls:float=1.0
    gamma_iou:float=1.0
    focalbce_alpha:float=0.5
    focalbce_gamma:float=0
    is_clsIoU:bool=True
    is_objIoU:bool=False
    multiscale_range:int=0
    multiscale_freq:int=10
    mosaic_shutdown:int=None

class YoloLoggingParams(BaseLoggingParams):
    gradflow_frequency:int = 500
    weighthist_enabled:bool = False
    weighthist_frequency:int=500
    imagefig_backgclassid:int = 0
    imagefig_maxcount:int=4

#################################################
### Trainer
#################################################
class YoloTrainer(BaseTrainer):
    attr_hparams:YoloHyperParams = None
    attr_logging:YoloLoggingParams = None
    logger = None
    def __init__(self,model:YOLOXModel,root_logdir:str='tb_logdir',sub_logdir_suffix:str=''):
        self.model_strides = model.strides
        super().__init__(model)
        assert isinstance(model,YOLOXModel),"For Detection, the model should be a detection model."
        self._current_dataset:YoloDataset
        self.attr_hparams:YoloHyperParams = YoloHyperParams()
        self.attr_logging:YoloLoggingParams = YoloLoggingParams()
        self.attr_logging.logger_rootlogdir=root_logdir
        self.attr_logging.logger_sublogdir_suffix = sub_logdir_suffix
        self._multiscale_scale=0
        self._lossparams:YoloLossParams = YoloLossParams()

    def set_AdamOptimizer(self):
        self.freeze('set_optimizer','attr_hparams')
        self._optimizer_config={'cls':Adam,'params':
                                {'lr':self.attr_hparams.Lr0,
                                 'betas':(self.attr_hparams.optim_momentum,math.sqrt(self.attr_hparams.optim_momentum)),
                                 'weight_decay':self.attr_hparams.optim_weight_decay
                                 }}
    
    def set_RMSOptimizer(self):
        self.freeze('set_optimizer','attr_hparams')
        self._optimizer_config={'cls':RMSprop,'params':{'lr':self.attr_hparams.Lr0,
                                 'momentum':self.attr_hparams.optim_momentum,
                                 'weight_decay':self.attr_hparams.optim_weight_decay
                                 }}

    def set_SGDOptimizer(self):
        self.freeze('set_optimizer','attr_hparams')
        self._optimizer_config={'cls':SGD,'params':{'lr':self.attr_hparams.Lr0,
                                 'momentum':self.attr_hparams.optim_momentum,
                                 'weight_decay':self.attr_hparams.optim_weight_decay
                                 }}

    def configure_training(self):
        """
            This methods allows to configure object that will be use during training.
        """
        # We freeze parameters since it is necessary to initialize many things
        self.freeze('configure_training','attr_hparams','attr_logging')
        self.set_optimizer()
        # We set the logger with it's parameters
        self.logger = AMLTensorboardLogger(
            rootLogDir=self.attr_logging.logger_rootlogdir,
            LogDir_suffix=self.attr_logging.logger_sublogdir_suffix,
            logbatch=self.attr_logging.logger_logbatch,
            log_freq=self.attr_logging.logger_freq)
        # This line is only here for unit test to test that logger is working correctly
        self.logger.enable_traces(hasattr(self,'traces'))
        # We set losses
        self.l1_loss = nn.L1Loss(reduction="none")
        self.bcewithlog_loss = nn.BCEWithLogitsLoss(reduction="none")
        self.iou_loss = IoUlossBBox(reduction="none")
        self.mAP = MeanAveragePrecision(box_format='cxcywh',class_metrics=True)
        training_config = {
            'hparams':self.attr_hparams.__dict__,
            'lparams':self.attr_logging.__dict__,
            'clsNames':self._current_dataset.clsNames,
            'clsCount':self._current_dataset.clsCount
        }
        if not self._distributed or not self._rank:
            with open(os.path.join(self.logger.logdir,'config.json'),'w') as jsf:
                json.dump(training_config,jsf,indent=4)
        # We set figures with their paramters
        self.gradflow = GradFlowFigure()
        self._model:YOLOXModel
        # We set losses parameters
        self._lossparams.lambda_cls  = self.attr_hparams.lambda_cls
        self._lossparams.lambda_iou  = self.attr_hparams.lambda_iou
        self._lossparams.lambda_l1   = self.attr_hparams.lambda_l1
        self._lossparams.lambda_obj  = self.attr_hparams.lambda_obj
        self._lossparams.lambda_negobj = self.attr_hparams.lambda_negobj
        self._lossparams.gamma_iou = self.attr_hparams.gamma_iou
        self._lossparams.focalBCE_alpha = self.attr_hparams.focalbce_alpha
        self._lossparams.focalBCE_gamma = self.attr_hparams.focalbce_gamma
        self._lossparams.is_clsIoU = self.attr_hparams.is_clsIoU
        self._lossparams.is_objIoU = self.attr_hparams.is_objIoU
    @torch.enable_grad()
    def train_step(self,batch, device = 'cpu')->dict:
        self._model:YOLOXModel
        self._optimizer.zero_grad()
        X,labels,_ = batch
        X = X.to(device).float()
        labels = labels.to(device)
        ###################################
        # MultiScale training management
        # https://github.com/Megvii-BaseDetection/YOLOX/blob/main/docs/manipulate_training_image_size.md
        ###################################
        # In this part, we resize the input in order to perform a multiscale training...
        if self.attr_hparams.multiscale_range:
            org_size = X.shape[2:]
            # Every freq steps, we change the scale...
            if not self._current_batch_id%self.attr_hparams.multiscale_freq:
                scale_factor=torch.randint(-self.attr_hparams.multiscale_range,self.attr_hparams.multiscale_range,(1,)).type_as(X)
                if self._distributed:
                    # We change the scale to be the same on all ranks.
                    dist.barrier()
                    dist.broadcast(scale_factor,0)
                self._multiscale_scale = int(scale_factor.item())
            # We create a new size for the tensor...
            new_size = (org_size[0]+self._multiscale_scale*32,org_size[1]+self._multiscale_scale*32)
            X=nn.Upsample(new_size)(X)
        ###################################
        with torch.cuda.amp.autocast(enabled=self._isAMP):
            # We compute Losses
            outputs = self._model.forward(X)
            (
                total_loss,
                loss_iou,
                loss_obj,
                loss_obj_pos,
                loss_obj_neg,
                loss_cls,
                loss_l1,
                fg_rate
            ) = get_yolo_losses(
                    outputs,
                    self.model_strides,
                    labels,
                    params=self._lossparams
            )
            self.backward_step(total_loss)
            gradnorm = grad_norm(self._model)
            #############################################################
            #### Logging
            #############################################################
            # We log losses
            if self._distributed:
                # We reduce our CE loss by it's mean
                total_loss = self.dist_reduce(total_loss,REDUCTION.MEAN)
                loss_iou = self.dist_reduce(loss_iou,REDUCTION.MEAN)
                loss_obj = self.dist_reduce(loss_obj,REDUCTION.MEAN)
                loss_obj_pos = self.dist_reduce(loss_obj_pos,REDUCTION.MEAN)
                loss_obj_neg = self.dist_reduce(loss_obj_neg,REDUCTION.MEAN)
                loss_cls = self.dist_reduce(loss_cls,REDUCTION.MEAN)
                gradnorm = self.dist_reduce(gradnorm,REDUCTION.MEAN)
                loss_l1 = self.dist_reduce(loss_l1,REDUCTION.MEAN)
                fg_rate = self.dist_reduce(fg_rate,REDUCTION.MEAN)

            # We plot images if needed
            if not self._current_batch_id%self.attr_logging.gradflow_frequency:
                self.logger.log_figure("Train/GradFlow",self.gradflow(self._model),self._current_batch_id)
            if not self._current_batch_id%self.attr_logging.weighthist_frequency and self.attr_logging.weighthist_enabled:
                self.train_plot_weights()
            self.logger.log_scalar_acc("Train/GradNorm",gradnorm.item(),global_step=self._current_batch_id,reduction=REDUCTION.MEAN)
            self.logger.log_scalar_acc("Train/TotalLoss",total_loss.item(),global_step=self._current_batch_id,reduction=REDUCTION.MEAN)
            self.logger.log_scalar_acc("Train/cIoULoss",loss_iou.item(),global_step=self._current_batch_id,reduction=REDUCTION.MEAN)
            self.logger.log_scalar_acc("Train/ObjLoss",loss_obj.item(),global_step=self._current_batch_id,reduction=REDUCTION.MEAN)
            self.logger.log_scalar_acc("Train/ObjLoss_Pos",loss_obj_pos.item(),global_step=self._current_batch_id,reduction=REDUCTION.MEAN)
            self.logger.log_scalar_acc("Train/ObjLoss_Neg",loss_obj_neg.item(),global_step=self._current_batch_id,reduction=REDUCTION.MEAN)
            self.logger.log_scalar_acc("Train/ClsLoss",loss_cls.item(),global_step=self._current_batch_id,reduction=REDUCTION.MEAN)
            self.logger.log_scalar_acc("Train/Ratio_nPred_vs_nGT",fg_rate.item(),global_step=self._current_batch_id,reduction=REDUCTION.MEAN)
            self.logger.log_scalar_acc("Train/L1Loss",loss_l1.item(),global_step=self._current_batch_id,reduction=REDUCTION.MEAN)
            if self._scheduler_type==SCHEDULER_TYPE.BATCH:
                self.logger.log_scalar('Train/Lr_batch',self.getLr(),global_step=self._current_batch_id)

            outputs = {
                'grad_norm':gradnorm.item(),
                'total_loss':total_loss.item(),
                'loss_l1':loss_l1.item(),
                'loss_iou':loss_iou.item(),
                'loss_obj':loss_obj.item(),
                'loss_cls':loss_cls.item(),
                'ratio_p_gt':fg_rate.item()}
        return outputs

    def train_plot_weights(self):
        """ Method in order to plot weight of yolo head...
        """
        model = self._model
        if self._distributed:
            model = self._model.module
        model:YOLOXModel
        heads = ['cls_preds','obj_preds','reg_preds']
        for head_name in heads:
            head_layers = getattr(model.head,head_name)
            for i,conv_layer in enumerate(head_layers):
                conv_layer:nn.Conv2d
                self.logger.log_hist(f"{head_name}/weights_{i}",conv_layer.weight.data,self._current_batch_id)
                self.logger.log_hist(f"{head_name}/bias_{i}",conv_layer.bias.data,self._current_batch_id)

    def train_loop_end(self):
        # We logg the learning rate.
        if self._scheduler_type==SCHEDULER_TYPE.EPOCH:
            self.logger.log_scalar('Train/Lr_epoch',self.getLr(),self._current_epoch_id,ignore_freq=True)
        # We logg what have been aggregated...
        self.logger.log_aggregate(self._current_epoch_id)
        # We disable Mosaic after some epochs.
        if self.attr_hparams.mosaic_shutdown is not None:
            if self._current_epoch_id>=self.attr_hparams.mosaic_shutdown:
                self._current_dataset.mosaic_enabled=False
        return

    @torch.no_grad()
    def val_step(self,batch,device = 'cpu')->dict:
        self._model:YOLOXModel
        X,labels,_ = batch
        X = X.to(device).float()
        labels = labels.to(device)
        with torch.cuda.amp.autocast(enabled=self._isAMP):
            # We compute Losses - Idem Training...
            outputs = self._model.forward(X)
            decoded_outputs,_,_,_ = decode_outputs(outputs,self.model_strides)
            nms_outputs = non_max_suppression(
                decoded_outputs,
                self.attr_hparams.nms_conf_threshold,
                self.attr_hparams.nms_iou_threshold,
                self.attr_hparams.nms_classwise)
            #############################################################
            #### Logging
            #############################################################
            # And we compute the mAP
            size = self._current_dataset.size
            update_mAP(self.mAP,nms_outputs,labels,size[0],size[1])
        return {}

    def val_loop_end(self):
        mAP = self.mAP.compute()
        self.logger.log_scalar('Val/mAP',mAP['map'],global_step=self._current_epoch_id,ignore_freq=True)
        self.logger.log_scalar('Val/mAP_50',mAP['map_50'],global_step=self._current_epoch_id,ignore_freq=True)
        self.logger.log_scalar('Val/mAP_75',mAP['map_75'],global_step=self._current_epoch_id,ignore_freq=True)
        self.logger.log_scalar('Val/map_small',mAP['map_small'],global_step=self._current_epoch_id,ignore_freq=True)
        self.logger.log_scalar('Val/map_medium',mAP['map_medium'],global_step=self._current_epoch_id,ignore_freq=True)
        self.logger.log_scalar('Val/map_large',mAP['map_large'],global_step=self._current_epoch_id,ignore_freq=True)
        self.logger.log_scalar('Val/mar_small',mAP['mar_small'],global_step=self._current_epoch_id,ignore_freq=True)
        self.logger.log_scalar('Val/mar_medium',mAP['mar_medium'],global_step=self._current_epoch_id,ignore_freq=True)
        self.logger.log_scalar('Val/mar_large',mAP['mar_large'],global_step=self._current_epoch_id,ignore_freq=True)

        for i,cls_id in enumerate(self.mAP._get_classes()):
            # We log mAP for every classes...
            cls_name = self._current_dataset.clsNames[int(cls_id)]
            self.logger.log_scalar(f'Val/mAP_{cls_name}',mAP['map_per_class'][i],global_step=self._current_epoch_id,ignore_freq=True,ignore_aml=True)
        # We keep the model if it's the best mAP
        self.logger.checkpoint(self._model,mAP['map'],iteration=self._current_epoch_id,strategy='max')
        self.mAP.reset()
        return

    @torch.no_grad()
    def test_step(self,batch,device = 'cpu',iteration_id:int=0)->dict:
        raise NotImplementedError()
    def test_loop_end(self,test_id:int=0):
        raise NotImplementedError()