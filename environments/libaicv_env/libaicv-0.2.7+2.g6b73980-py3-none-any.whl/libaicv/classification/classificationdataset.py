from ..core.base import BaseDataset,BaseImage
from ..core.factory import PPROCESS
from ..utils.os import Directory
from PIL import Image as PILImage
import os
import numpy as np
from typing import List
from yarrow import YarrowDataset
import cv2
from tqdm import tqdm
import torch

class ClassificationDataset(BaseDataset):
    clsNames = None
    def __init__(self,pprocess:PPROCESS=PPROCESS.NORMALIZE,size:tuple=(128,128)):
        BaseDataset.__init__(self,pprocess,size)
        self.clsNames = []

    def dict(self):
        config = super().dict()
        config['clsNames']=self.clsNames
        return config
    
    @property
    def clsCount(self):
        return len(self.clsNames)

    def __getitem__(self,idx):
        indice = idx%self.__len__()
        ImageInstance = self.data[indice]
        ImageInstance:BaseImage
        X = ImageInstance.get_data()
        y = ImageInstance.get_target()
        if self.transform:
            output = self.transform(image=X)
            X = output['image']
        X:torch.Tensor
        y:torch.Tensor
        return X.float(),y,ImageInstance.name

    def fromFolder(rootFolder:str,pprocess:PPROCESS=PPROCESS.NORMALIZE,size:tuple=(128,128),nmax:int = None,clsNames:List[str]=None)->'ClassificationDataset':
        """Create a Classification Dataset from a rootFolder
        with structure like that :
            |RootFolder
            ---| ClassName_1
            ------| Image 0
            ------| Image 1
            ------| Image 2
            ------| ....            
            ---| ClassName_2
            ------| ....
            

        Args:
            rootFolder (str): _description_
            pprocess (PPROCESS): Preprocessing normalization
            size (Image sizes): Preprocessing size
            clsNames (clsNames): clsNames in case they are already known
        Returns:
            ClassificationDataset : Dataset
        """
        dataset = ClassificationDataset(pprocess,size)
        root_dir = Directory(rootFolder)
        if clsNames is None:
            dataset.clsNames = root_dir.get_foldernames()
        else:
            dataset.clsNames = clsNames
        dataset.data = []
        assert len(dataset.clsNames)>1,"The dataset should contain at least 2 classes"
        n = 0
        for clsPath in root_dir.get_folderpaths():
            clsDirectory = Directory(clsPath)
            if clsDirectory.name not in dataset.clsNames:
                print(f'Classe : {clsDirectory.name} not in provided clsNames will be ignored')
                continue
            clsId = dataset.clsNames.index(clsDirectory.name)
            tbar = tqdm(clsDirectory.get_filepaths(),desc = f"Classe : {clsDirectory.name}")
            for img_path in tbar:
                item = ClassificationFolderImage(img_path,clsId,clsDirectory.name)
                dataset.data.append(item)
                # We compute nmax                
                if nmax is not None:
                    n+=1
                    if n>=nmax:
                        return dataset
        return dataset



class ClassificationFolderImage(BaseImage):
    def __init__(self,img_path:str,clsID:int,clsName:str):
        if not os.path.exists(img_path):
             raise OSError(f"Image Path do not exists \n{img_path}")
        # We get the name from image name.
        self.name = os.path.splitext(os.path.basename(img_path))[0]
        self.img_path = img_path
        self.clsName = clsName
        self.clsID = clsID
    def get_target(self,**kwargs):
        return self.clsID