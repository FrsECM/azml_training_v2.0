from ..core.base import BaseModel
from typing import List

class ClassificationModel(BaseModel):
    name="ClassificationModel"
