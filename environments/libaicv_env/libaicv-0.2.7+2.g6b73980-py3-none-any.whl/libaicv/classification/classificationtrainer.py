from torch.optim import Adam
import torch
from ..core.factory import IBaseModel,REDUCTION
from ..core.base.basetrainer import BaseTrainer,BaseHyperParams,BaseLoggingParams
from ..core.factory import PPROCESS
from ..core.base import BaseModel
from torch.nn import CrossEntropyLoss
from ..core.loggers import AMLTensorboardLogger
from ..core.accumulator import VerdictsAccumulator,ConfusionMatrixAccumulator,VMODE
from ..core.figures import GradFlowFigure,grad_norm
from .figures import ImageClassificationFigure as ImageFigure
from .import ClassificationDataset,ClassificationModel

import os

#################################################
### Arguments (pydantic for serialization)
#################################################
class ClassificationHyperParams(BaseHyperParams):pass

class ClassificationLoggingParams(BaseLoggingParams):
    curve_nThresholds:int=25
    gradflow_frequency:int = 100
    imagefig_frequency_train:int=50
    imagefig_frequency_val:int=50
    imagefig_frequency_test:int=10
    imagefig_border:float = 0.1
    imagefig_displaydim:int = 0
    imagefig_backgclassid:int = 0
    imagefig_maxcount:int=4

#################################################
### Trainer
#################################################
class ClassificationTrainer(BaseTrainer):
    attr_hparams:ClassificationHyperParams = None
    attr_logging:ClassificationLoggingParams = None
    logger = None
    def __init__(self,model:IBaseModel,root_logdir:str='tb_logdir',sub_logdir_suffix:str=''):
        super().__init__(model)
        assert isinstance(model,ClassificationModel),"For classification, the model should be a classification model."
        self._current_dataset:ClassificationDataset
        self.attr_hparams:ClassificationHyperParams = ClassificationHyperParams()
        self.attr_logging:ClassificationLoggingParams = ClassificationLoggingParams()
        self.attr_logging.logger_rootlogdir=root_logdir
        self.attr_logging.logger_sublogdir_suffix = sub_logdir_suffix

    def configure_training(self):
        """
            This methods allows to configure object that will be use during training.
        """
        # We freeze parameters since it is necessary to initialize many things
        self.freeze('configure_training','attr_hparams','attr_logging')
        self.set_optimizer()
        # We set the logger with it's parameters
        self.logger = AMLTensorboardLogger(
            rootLogDir=self.attr_logging.logger_rootlogdir,
            LogDir_suffix=self.attr_logging.logger_sublogdir_suffix,
            logbatch=self.attr_logging.logger_logbatch,
            log_freq=self.attr_logging.logger_freq,
            log_azure=self.attr_logging.logger_azureml)
        # This line is only here for unit test to test that logger is working correctly
        self.logger.enable_traces(hasattr(self,'traces'))
        # We set losses
        self.celoss = CrossEntropyLoss()
        # We set figures with their paramters
        self.gradflow = GradFlowFigure()
        self.imageplot = ImageFigure(
            pprocess=self._current_dataset.pprocess,
            display_dim=self.attr_logging.imagefig_displaydim,
            bg_class=self.attr_logging.imagefig_backgclassid,
            clsNames=self._current_dataset.clsNames,
            max_count=self.attr_logging.imagefig_maxcount,
            border=self.attr_logging.imagefig_border)
        self.verdicts = VerdictsAccumulator(
            clsIDs=range(self._current_dataset.clsCount),
            clsNames=self._current_dataset.clsNames,
            n_thresholds=self.attr_logging.curve_nThresholds
        )
        self.confmatrix = ConfusionMatrixAccumulator(
            clsIDs=range(self._current_dataset.clsCount),
            clsNames=self._current_dataset.clsNames
        )

    @torch.enable_grad()
    def train_step(self,batch, device = 'cpu')->dict:
        self._optimizer.zero_grad()
        X,y,_ = batch
        X = X.to(device).float()
        y = y.to(device)
        nBatch = X.shape[0]
        with torch.cuda.amp.autocast(enabled=self._isAMP):
            # We compute Losses
            pred = self._model.forward(X)
            ce_loss = self.celoss(pred,y.long())
            self.backward_step(ce_loss)
            gradnorm = grad_norm(self._model)
            #############################################################
            #### Logging
            #############################################################
            # We log losses
            if self._distributed:
                # We reduce our CE loss by it's mean
                ce_loss = self.dist_reduce(ce_loss,REDUCTION.MEAN)
                gradnorm = self.dist_reduce(gradnorm,REDUCTION.MEAN)

            self.logger.log_scalar_acc("Train/CELoss",ce_loss.item(),global_step=self._current_batch_id,reduction=REDUCTION.MEAN)
            self.logger.log_scalar_acc("Train/GradNorm",gradnorm.item(),global_step=self._current_batch_id,reduction=REDUCTION.MEAN)
            # We plot images if needed
            if not self._current_batch_id%self.attr_logging.gradflow_frequency:
                self.logger.log_figure("Train/GradFlow",self.gradflow(self._model),self._current_batch_id)
            if not self._current_batch_id%self.attr_logging.imagefig_frequency_train:
                self.logger.log_figure("Train/Images",self.imageplot(X,y,pred),global_step=self._current_batch_id)
        return {'ce_loss':ce_loss.item(),'grad_norm':gradnorm.item()}
    
    def train_loop_end(self):
        # We logg the learning rate.
        self.logger.log_scalar('Train/Lr',self.getLr(),self._current_epoch_id,ignore_freq=True)
        # We logg what have been aggregated...
        self.logger.log_aggregate(self._current_epoch_id)
        return

    @torch.no_grad()
    def val_step(self,batch,device = 'cpu')->dict:
        self.current_dataset:ClassificationDataset
        X,y,_ = batch
        nBatch=X.shape[0]
        X=X.to(device)
        y=y.to(device)
        with torch.cuda.amp.autocast(enabled=self._isAMP):
            pred=self._model.forward(X)
            # We compute Losses
            ce_loss = self.celoss(pred,y.long())
                # First, we need to compute softmax on prediction...
            pred_softmaxed=torch.softmax(pred,dim=1) # We softmax on the first dim and put it in the end for further masking
            # We plots images...
            if not self._current_batch_id%self.attr_logging.imagefig_frequency_val:
                self.logger.log_figure("Val/Images",self.imageplot(X,y,pred),global_step=self._current_batch_id)
            #############################################################
            ### MultiGPU aggregation...
            #############################################################
            if self._distributed:
                # In distributed mode, we'll process our results
                ce_loss = self.dist_reduce(ce_loss,REDUCTION.MEAN)
                pred_softmaxed = self.dist_concat(pred_softmaxed,dim=0)
                y = self.dist_concat(y,dim=0)
            #############################################################
            #### We accumulate Metrics
            #############################################################
            self.verdicts(pred_softmaxed,y,apply_softmax=False)
            self.confmatrix(pred_softmaxed,y,apply_softmax=False)
            #############################################################
            #### Logging
            #############################################################
            # We log losses
            self.logger.log_scalar_acc("Val/CELoss",ce_loss.item(),global_step=self._current_batch_id,reduction=REDUCTION.MEAN)

        return {'ce_loss':ce_loss.item()}
    
    def val_loop_end(self):
        # We log figures...
        self.verdicts:VerdictsAccumulator
        for fig_name,figure in self.verdicts.get_all_figure(mode=VMODE.PRCURVE).items():
            self.logger.log_figure(f"Val/{fig_name}",figure,self._current_epoch_id)
        for fig_name,figure in self.verdicts.get_all_figure(mode=VMODE.VIDICURVE).items():
            self.logger.log_figure(f"Val/{fig_name}",figure,self._current_epoch_id)
        self.logger.log_figure(f"Val/ConfusionMatrix",self.confmatrix.get(),self._current_epoch_id)        
        # We reset our accumulators
        self.verdicts.reset()
        self.confmatrix.reset()
        # We log losses/metrics
        self.logger.checkpoint_acc(self._model,key='Val/CELoss_mean',iteration=self._current_epoch_id,strategy='min')
        self.logger.log_aggregate(self._current_epoch_id)

        return

    @torch.no_grad()
    def test_step(self,batch,device = 'cpu',iteration_id:int=0)->dict:
        self.current_dataset:ClassificationDataset
        X,y,_ = batch
        nBatch=X.shape[0]
        X=X.to(device)
        y=y.to(device)
        with torch.cuda.amp.autocast(enabled=self._isAMP):
            pred=self._model.forward(X)
            # We compute Losses
            ce_loss = self.celoss(pred,y.long())
                # First, we need to compute softmax on prediction...
            pred_softmaxed=torch.softmax(pred,dim=1) # We softmax on the first dim and put it in the end for further masking
            if self._distributed:
                # In distributed mode, we'll process our results
                ce_loss = self.dist_reduce(ce_loss,REDUCTION.MEAN)
                pred_softmaxed = self.dist_concat(pred_softmaxed,dim=0)
                y = self.dist_concat(y,dim=0)
            #############################################################
            #### We accumulate Metrics
            #############################################################
            self.verdicts(pred_softmaxed,y,apply_softmax=False)
            self.confmatrix(pred_softmaxed,y,apply_softmax=False)
            #############################################################
            #### Logging
            #############################################################
            # We log losses
            self.logger.log_scalar_acc("Test/CELoss",ce_loss.item(),global_step=iteration_id,reduction=REDUCTION.MEAN)
            # We plots images...
            if not iteration_id%self.attr_logging.imagefig_frequency_test:
                self.logger.log_figure("Test/Images",self.imageplot(X,y,pred),global_step=iteration_id)
        return {'ce_loss':ce_loss.item()}
    
    def test_loop_end(self,test_id:int=0):
        # We log figures...
        self.verdicts:VerdictsAccumulator
        for fig_name,figure in self.verdicts.get_all_figure(mode=VMODE.PRCURVE).items():
            self.logger.log_figure(f"Test/{fig_name}",figure,test_id)
        for fig_name,figure in self.verdicts.get_all_figure(mode=VMODE.VIDICURVE).items():
            self.logger.log_figure(f"Test/{fig_name}",figure,test_id)
        self.logger.log_figure(f"Test/ConfusionMatrix",self.confmatrix.get(),test_id)        
        # We reset our accumulators
        self.verdicts.reset()
        self.confmatrix.reset()
        self.logger.log_aggregate(test_id)